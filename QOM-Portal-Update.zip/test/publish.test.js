// Tests: Entwurf/Veröffentlichen und die Content-API.
// "Speichern" ändert nur den Entwurf; erst "Veröffentlichen" macht ihn öffentlich.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, anmelden, ajaxPost } from './helfer.js';

umgebungVorbereiten('qom-test-publish-');

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');

const PASSWORT = 'sicheres-test-passwort-1';
const API_TOKEN = 'api-token-fuer-tests-0123456789';
const PREVIEW_TOKEN = 'preview-token-fuer-tests-0123456789';

const hash = await passwortHashen(PASSWORT);
const editorId = db.prepare(
  `INSERT INTO users (email, pw_hash, name, is_admin) VALUES (?, ?, ?, 0)`
).run('kunde@example.com', hash, 'Kunde').lastInsertRowid;

// deploy_webhook_url bleibt leer → das Veröffentlichen ruft kein Netzwerk auf.
const projektId = db.prepare(
  `INSERT INTO projects (slug, name, api_token, preview_token) VALUES ('kunde', 'Kunde AG', ?, ?)`
).run(API_TOKEN, PREVIEW_TOKEN).lastInsertRowid;
db.prepare(
  `INSERT INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`
).run(editorId, projektId);

db.prepare(
  `INSERT INTO fields (project_id, key, group_label, field_label, type, value_draft, value_published, editable_by_editor, sort)
   VALUES (?, 'titel', 'Startseite', 'Titel', 'text', 'Alter Titel', 'Alter Titel', 1, 1)`
).run(projektId);
db.prepare(
  `INSERT INTO collections (project_id, key, label, item_schema, editable_by_editor, sort)
   VALUES (?, 'team', 'Team', ?, 1, 1)`
).run(projektId, JSON.stringify([{ key: 'name', label: 'Name', type: 'text' }]));

const app = appErstellen();
after(async () => { await app.close(); });

const sitzung = await anmelden(app, 'kunde@example.com', PASSWORT);
assert.ok(sitzung.sid, 'Login muss klappen');

async function contentHolen(query) {
  const antwort = await app.inject({
    method: 'GET',
    url: `/api/v1/projects/kunde/content?${query}`,
  });
  return antwort;
}

function veroeffentlichen() {
  return ajaxPost(app, sitzung, '/projekt/kunde/veroeffentlichen', {});
}

test('Feld speichern: published behält den alten Wert, draft zeigt den neuen', async () => {
  const speichern = await ajaxPost(app, sitzung, '/projekt/kunde/feld', {
    key: 'titel', wert: 'Neuer Titel',
  });
  assert.equal(speichern.statusCode, 200);

  const publiziert = await contentHolen(`token=${API_TOKEN}`);
  assert.equal(publiziert.statusCode, 200);
  const publiziertJson = publiziert.json();
  assert.equal(publiziertJson.stand, 'published');
  assert.equal(publiziertJson.felder.titel, 'Alter Titel');
  assert.equal(publiziertJson.projekt.slug, 'kunde');
  assert.ok(publiziertJson.generiert_am);

  const entwurf = await contentHolen(`version=draft&token=${PREVIEW_TOKEN}`);
  assert.equal(entwurf.statusCode, 200);
  const entwurfJson = entwurf.json();
  assert.equal(entwurfJson.stand, 'draft');
  assert.equal(entwurfJson.felder.titel, 'Neuer Titel');
});

test('Veröffentlichen übernimmt den Entwurf in den öffentlichen Stand', async () => {
  const antwort = await veroeffentlichen();
  assert.equal(antwort.statusCode, 200);
  assert.equal(antwort.json().ok, true);

  const publiziert = await contentHolen(`token=${API_TOKEN}`);
  assert.equal(publiziert.json().felder.titel, 'Neuer Titel');
});

let eintragId;

test('Sammlung: neuer Eintrag erscheint erst nach dem Veröffentlichen', async () => {
  const neu = await ajaxPost(app, sitzung, '/projekt/kunde/sammlung/team/neu', {});
  assert.equal(neu.statusCode, 200);
  eintragId = neu.json().id;
  assert.ok(eintragId);

  const speichern = await ajaxPost(app, sitzung, `/projekt/kunde/sammlung/team/${eintragId}`, {
    daten: { name: 'Anna Muster' },
  });
  assert.equal(speichern.statusCode, 200);

  const publiziert = (await contentHolen(`token=${API_TOKEN}`)).json();
  assert.deepEqual(publiziert.sammlungen.team.eintraege, [], 'Vor dem Veröffentlichen bleibt die Liste leer');

  const entwurf = (await contentHolen(`version=draft&token=${PREVIEW_TOKEN}`)).json();
  assert.deepEqual(entwurf.sammlungen.team.eintraege, [{ name: 'Anna Muster' }]);

  await veroeffentlichen();

  const nachher = (await contentHolen(`token=${API_TOKEN}`)).json();
  assert.deepEqual(nachher.sammlungen.team.eintraege, [{ name: 'Anna Muster' }]);
});

test('Gelöschter, bereits veröffentlichter Eintrag bleibt bis zum nächsten Veröffentlichen online', async () => {
  const loeschen = await ajaxPost(app, sitzung, `/projekt/kunde/sammlung/team/${eintragId}/loeschen`, {});
  assert.equal(loeschen.statusCode, 200);

  const publiziert = (await contentHolen(`token=${API_TOKEN}`)).json();
  assert.deepEqual(publiziert.sammlungen.team.eintraege, [{ name: 'Anna Muster' }],
    'Bis zum nächsten Veröffentlichen bleibt der Eintrag öffentlich');

  const entwurf = (await contentHolen(`version=draft&token=${PREVIEW_TOKEN}`)).json();
  assert.deepEqual(entwurf.sammlungen.team.eintraege, [], 'Im Entwurf ist der Eintrag schon weg');

  await veroeffentlichen();

  const nachher = (await contentHolen(`token=${API_TOKEN}`)).json();
  assert.deepEqual(nachher.sammlungen.team.eintraege, [], 'Nach dem Veröffentlichen ist der Eintrag entfernt');
});

test('Falsches oder fehlendes Token: 401', async () => {
  assert.equal((await contentHolen('token=voellig-falsch')).statusCode, 401);
  assert.equal((await contentHolen('')).statusCode, 401);

  const posts = await app.inject({
    method: 'GET',
    url: '/api/v1/projects/kunde/posts?token=voellig-falsch',
  });
  assert.equal(posts.statusCode, 401);
});

test('api_token gilt nicht für die Entwurfs-Ansicht: 401', async () => {
  const antwort = await contentHolen(`version=draft&token=${API_TOKEN}`);
  assert.equal(antwort.statusCode, 401);
});
