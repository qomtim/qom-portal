// Tests: Anmeldung, CSRF-Schutz und Zugriffsschutz ohne Login.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, cookieAuslesen, anmelden } from './helfer.js';

umgebungVorbereiten('qom-test-auth-');

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');

const PASSWORT = 'sicheres-test-passwort-1';
const hash = await passwortHashen(PASSWORT);
db.prepare(
  `INSERT INTO users (email, pw_hash, name, is_admin) VALUES (?, ?, ?, 0)`
).run('tim@example.com', hash, 'Tim Test');

const app = appErstellen();
after(async () => { await app.close(); });

test('Gesundheitscheck: /health antwortet mit ok', async () => {
  const antwort = await app.inject({ method: 'GET', url: '/health' });
  assert.equal(antwort.statusCode, 200);
  assert.equal(antwort.json().status, 'ok');
});

test('falsches Passwort: Login-Seite mit Fehlermeldung, kein Session-Cookie', async () => {
  const { antwort, sid } = await anmelden(app, 'tim@example.com', 'voellig-falsch');
  assert.equal(antwort.statusCode, 200);
  assert.match(antwort.body, /E-Mail oder Passwort stimmt nicht\./);
  assert.equal(sid, null);
  assert.equal(cookieAuslesen(antwort, 'qom_sid'), null);
});

test('richtiges Passwort: Weiterleitung nach /projekte mit Session-Cookie', async () => {
  const { antwort, sid } = await anmelden(app, 'tim@example.com', PASSWORT);
  assert.equal(antwort.statusCode, 302);
  assert.equal(antwort.headers.location, '/projekte');
  assert.ok(sid, 'Session-Cookie qom_sid muss gesetzt sein');
});

test('POST /login ganz ohne CSRF-Token wird abgelehnt (403)', async () => {
  const antwort = await app.inject({
    method: 'POST',
    url: '/login',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    payload: 'email=tim%40example.com&passwort=egal',
  });
  assert.equal(antwort.statusCode, 403);
  assert.equal(cookieAuslesen(antwort, 'qom_sid'), null);
});

test('POST /login mit falschem CSRF-Token wird abgelehnt (403)', async () => {
  const seite = await app.inject({ method: 'GET', url: '/login' });
  const csrf = cookieAuslesen(seite, 'qom_csrf');
  const antwort = await app.inject({
    method: 'POST',
    url: '/login',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      cookie: `qom_csrf=${csrf}`,
    },
    payload: `email=tim%40example.com&passwort=${encodeURIComponent(PASSWORT)}&_csrf=falscher-wert`,
  });
  assert.equal(antwort.statusCode, 403);
  assert.equal(cookieAuslesen(antwort, 'qom_sid'), null);
});

test('/admin ohne Login leitet zum Login um', async () => {
  const antwort = await app.inject({ method: 'GET', url: '/admin' });
  assert.equal(antwort.statusCode, 302);
  assert.equal(antwort.headers.location, '/login');
});

test('/projekte und /projekt/... ohne Login leiten zum Login um', async () => {
  const projekte = await app.inject({ method: 'GET', url: '/projekte' });
  assert.equal(projekte.statusCode, 302);
  assert.equal(projekte.headers.location, '/login');

  const projekt = await app.inject({ method: 'GET', url: '/projekt/irgendwas' });
  assert.equal(projekt.statusCode, 302);
  assert.equal(projekt.headers.location, '/login');
});
