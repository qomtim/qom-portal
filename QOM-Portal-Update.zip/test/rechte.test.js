// Tests: Multi-Tenant und Rechte (Primer Phase 3).
// Ein Editor sieht nur freigegebene Inhalte seines Projekts und erreicht
// gesperrte oder fremde Inhalte auch per direkter URL nicht.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, anmelden, ajaxPost } from './helfer.js';

umgebungVorbereiten('qom-test-rechte-');

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');

const PASSWORT = 'sicheres-test-passwort-1';
const hash = await passwortHashen(PASSWORT);

const editorId = db.prepare(
  `INSERT INTO users (email, pw_hash, name, is_admin) VALUES (?, ?, ?, 0)`
).run('editor-a@example.com', hash, 'Editor A').lastInsertRowid;
db.prepare(
  `INSERT INTO users (email, pw_hash, name, is_admin) VALUES (?, ?, ?, 1)`
).run('admin@example.com', hash, 'QOM Admin').lastInsertRowid;

function projektAnlegen(slug, name) {
  return db.prepare(
    `INSERT INTO projects (slug, name, api_token, preview_token) VALUES (?, ?, ?, ?)`
  ).run(slug, name, `api-${slug}-token-0123456789`, `preview-${slug}-token-0123456789`).lastInsertRowid;
}
const projektA = projektAnlegen('projekt-a', 'Projekt A');
const projektB = projektAnlegen('projekt-b', 'Projekt B');

db.prepare(
  `INSERT INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`
).run(editorId, projektA);

const feldAnlegen = db.prepare(
  `INSERT INTO fields (project_id, key, group_label, field_label, type, value_draft, value_published, editable_by_editor, sort)
   VALUES (?, ?, ?, ?, 'text', ?, ?, ?, ?)`
);
feldAnlegen.run(projektA, 'freier_text', 'Startseite', 'Freier Titel', 'Hallo', 'Hallo', 1, 1);
feldAnlegen.run(projektA, 'gesperrtes_feld', 'Startseite', 'Geheimer Untertitel', 'Intern', 'Intern', 0, 2);
feldAnlegen.run(projektB, 'b_feld', 'Startseite', 'Titel B', 'B', 'B', 1, 1);

const sammlungAnlegen = db.prepare(
  `INSERT INTO collections (project_id, key, label, item_schema, editable_by_editor, sort)
   VALUES (?, ?, ?, ?, ?, ?)`
);
const schema = JSON.stringify([{ key: 'name', label: 'Name', type: 'text' }]);
sammlungAnlegen.run(projektA, 'offene_liste', 'Offene Liste', schema, 1, 1);
sammlungAnlegen.run(projektA, 'gesperrte_liste', 'Gesperrte Liste', schema, 0, 2);

const app = appErstellen();
after(async () => { await app.close(); });

const editor = await anmelden(app, 'editor-a@example.com', PASSWORT);
const admin = await anmelden(app, 'admin@example.com', PASSWORT);
assert.ok(editor.sid, 'Editor-Login muss klappen');
assert.ok(admin.sid, 'Admin-Login muss klappen');

test('(a) Editor sieht gesperrte Felder und Sammlungen im Editor-HTML nicht', async () => {
  const antwort = await app.inject({
    method: 'GET',
    url: '/projekt/projekt-a',
    headers: { cookie: editor.cookie },
  });
  assert.equal(antwort.statusCode, 200);
  assert.match(antwort.body, /data-feld="freier_text"/);
  assert.match(antwort.body, /Freier Titel/);
  assert.ok(!antwort.body.includes('gesperrtes_feld'), 'Gesperrter Feld-Key darf nicht im HTML stehen');
  assert.ok(!antwort.body.includes('Geheimer Untertitel'), 'Gesperrtes Feld-Label darf nicht im HTML stehen');
  assert.ok(!antwort.body.includes('gesperrte_liste'), 'Gesperrte Sammlung darf nicht im HTML stehen');
});

test('(b) Editor darf gesperrtes Feld nicht speichern (403), freies Feld schon', async () => {
  const gesperrt = await ajaxPost(app, editor, '/projekt/projekt-a/feld', {
    key: 'gesperrtes_feld', wert: 'Hack',
  });
  assert.equal(gesperrt.statusCode, 403);

  const frei = await ajaxPost(app, editor, '/projekt/projekt-a/feld', {
    key: 'freier_text', wert: 'Neuer Text',
  });
  assert.equal(frei.statusCode, 200);
  assert.equal(frei.json().ok, true);

  const gesperrteSammlung = await ajaxPost(app, editor, '/projekt/projekt-a/sammlung/gesperrte_liste/neu', {});
  assert.equal(gesperrteSammlung.statusCode, 403);

  // Der gesperrte Wert darf sich nicht geändert haben
  const zeile = db.prepare(
    `SELECT value_draft FROM fields WHERE project_id = ? AND key = 'gesperrtes_feld'`
  ).get(projektA);
  assert.equal(zeile.value_draft, 'Intern');
});

test('(c) Projekt ohne Mitgliedschaft: GET und POST antworten mit 404', async () => {
  const seite = await app.inject({
    method: 'GET',
    url: '/projekt/projekt-b',
    headers: { cookie: editor.cookie },
  });
  assert.equal(seite.statusCode, 404);

  const speichern = await ajaxPost(app, editor, '/projekt/projekt-b/feld', {
    key: 'b_feld', wert: 'Hack',
  });
  assert.equal(speichern.statusCode, 404);

  const blog = await app.inject({
    method: 'GET',
    url: '/projekt/projekt-b/blog',
    headers: { cookie: editor.cookie },
  });
  assert.equal(blog.statusCode, 404);
});

test('(d) Alle /admin-Routen antworten für Editoren mit 404', async () => {
  const urls = [
    '/admin',
    '/admin/projekt/projekt-a',
    '/admin/projekt/projekt-a/felder',
    '/admin/projekt/projekt-a/sammlungen',
    '/admin/projekt/projekt-a/nutzer',
    '/admin/projekt/projekt-a/audit',
  ];
  for (const url of urls) {
    const antwort = await app.inject({ method: 'GET', url, headers: { cookie: editor.cookie } });
    assert.equal(antwort.statusCode, 404, `${url} muss für Editoren 404 liefern`);
  }
  // Auch schreibende Admin-Routen sind tabu
  const schreibend = await ajaxPost(app, editor, '/admin/projekte/neu', { name: 'Hack' });
  assert.equal(schreibend.statusCode, 404);
});

test('(e) QOM-Admin sieht alles: beide Projekte, gesperrte Felder, Adminbereich', async () => {
  const seiteA = await app.inject({
    method: 'GET', url: '/projekt/projekt-a', headers: { cookie: admin.cookie },
  });
  assert.equal(seiteA.statusCode, 200);
  assert.match(seiteA.body, /data-feld="gesperrtes_feld"/);
  assert.match(seiteA.body, /Geheimer Untertitel/);
  assert.match(seiteA.body, /gesperrte_liste/);

  const seiteB = await app.inject({
    method: 'GET', url: '/projekt/projekt-b', headers: { cookie: admin.cookie },
  });
  assert.equal(seiteB.statusCode, 200);

  const adminSeite = await app.inject({
    method: 'GET', url: '/admin', headers: { cookie: admin.cookie },
  });
  assert.equal(adminSeite.statusCode, 200);
  assert.match(adminSeite.body, /Projekt A/);
  assert.match(adminSeite.body, /Projekt B/);

  // Admin darf auch das gesperrte Feld speichern
  const speichern = await ajaxPost(app, admin, '/projekt/projekt-a/feld', {
    key: 'gesperrtes_feld', wert: 'Vom Admin geändert',
  });
  assert.equal(speichern.statusCode, 200);
  assert.equal(speichern.json().ok, true);
});
