// Tests: Sicherheits-Fixes aus dem Produktionsreife-Audit.
// Schwerpunkt: Einladungs-Flow darf ein bestehendes Konto NICHT ohne
// Passwort-Nachweis übernehmen/einloggen.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, cookieAuslesen } from './helfer.js';

umgebungVorbereiten('qom-test-sicherheit-');

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen, sqliteZeitStempel, tokenHash } = await import('../src/security.js');

const PW = 'bestehendes-passwort-1';
const hash = await passwortHashen(PW);
const userId = db.prepare(`INSERT INTO users (email, pw_hash, name, role) VALUES (?, ?, ?, 'customer')`)
  .run('bestehend@example.com', hash, 'Bestehend').lastInsertRowid;
const projektId = db.prepare(`INSERT INTO projects (slug, name, api_token, preview_token) VALUES ('inv','inv','a-inv-token','p-inv-token')`).run().lastInsertRowid;
const TOKEN = 'einladungs-token-fuer-test-123456';
db.prepare(
  `INSERT INTO invites (token, project_id, email, role, neue_rolle, expires_at) VALUES (?, ?, 'bestehend@example.com', 'editor', 'customer', ?)`
).run(tokenHash(TOKEN), projektId, sqliteZeitStempel(3600 * 1000));

const app = appErstellen();
after(async () => { await app.close(); });

async function csrfHolen() {
  const seite = await app.inject({ method: 'GET', url: `/einladung/${TOKEN}` });
  return cookieAuslesen(seite, 'qom_csrf');
}

async function einladungPost(passwort, csrf) {
  return app.inject({
    method: 'POST',
    url: `/einladung/${TOKEN}`,
    headers: { 'content-type': 'application/x-www-form-urlencoded', cookie: `qom_csrf=${csrf}` },
    payload: `passwort=${encodeURIComponent(passwort)}&_csrf=${encodeURIComponent(csrf)}`,
  });
}

test('Einladung: bestehendes Konto ohne Passwort wird NICHT eingeloggt/freigeschaltet', async () => {
  const csrf = await csrfHolen();
  const antwort = await einladungPost('', csrf);
  assert.equal(antwort.statusCode, 200); // bleibt auf der Seite
  assert.ok(!cookieAuslesen(antwort, 'qom_sid'), 'Es darf keine Session gesetzt werden');
  const mitglied = db.prepare(`SELECT 1 FROM memberships WHERE user_id = ? AND project_id = ?`).get(userId, projektId);
  assert.ok(!mitglied, 'Ohne Passwort darf keine Mitgliedschaft entstehen');
});

test('Einladung: falsches Passwort wird abgewiesen', async () => {
  const csrf = await csrfHolen();
  const antwort = await einladungPost('falsch-falsch-1', csrf);
  assert.equal(antwort.statusCode, 200);
  assert.ok(!cookieAuslesen(antwort, 'qom_sid'));
  const mitglied = db.prepare(`SELECT 1 FROM memberships WHERE user_id = ? AND project_id = ?`).get(userId, projektId);
  assert.ok(!mitglied);
});

test('Einladung: mit korrektem Passwort klappt es (Session + Mitgliedschaft)', async () => {
  const csrf = await csrfHolen();
  const antwort = await einladungPost(PW, csrf);
  assert.equal(antwort.statusCode, 302);
  assert.ok(cookieAuslesen(antwort, 'qom_sid'), 'Jetzt darf eine Session entstehen');
  const mitglied = db.prepare(`SELECT 1 FROM memberships WHERE user_id = ? AND project_id = ?`).get(userId, projektId);
  assert.ok(mitglied, 'Mitgliedschaft muss jetzt existieren');
});

test('Sicherheits-Header sind gesetzt (CSP, nosniff, Clickjacking-Schutz)', async () => {
  const r = await app.inject({ method: 'GET', url: '/login' });
  assert.equal(r.headers['x-content-type-options'], 'nosniff');
  assert.equal(r.headers['x-frame-options'], 'SAMEORIGIN');
  assert.match(String(r.headers['content-security-policy']), /object-src 'none'/);
  assert.match(String(r.headers['content-security-policy']), /frame-ancestors 'self'/);
});
