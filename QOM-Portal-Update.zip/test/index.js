// Einstiegspunkt für "npm test" (= node --test test/).
//
// Hintergrund: Seit Node 21 werden die Argumente von "node --test" als
// Glob-Muster interpretiert – ein Ordnerpfad wie "test/" wird nicht mehr
// rekursiv durchsucht, sondern als Modul geladen. Node löst "test/" dabei
// auf diese Datei (test/index.js) auf.
//
// Diese Datei startet deshalb jede *.test.js-Datei als eigenen
// node-Prozess. Das ist gleichzeitig die gewünschte Test-Isolation:
// jede Datei bekommt ihre eigene Datenbank und ihren eigenen
// Uploads-Ordner (DB_PATH/UPLOADS_DIR werden dort ganz oben gesetzt,
// bevor src/ importiert wird).
import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const hier = path.dirname(fileURLToPath(import.meta.url));
const dateien = fs.readdirSync(hier)
  .filter((name) => name.endsWith('.test.js'))
  .sort();

// Der Test-Runner markiert Kindprozesse über NODE_TEST_CONTEXT –
// ohne diese Bereinigung würden die gestarteten Prozesse ihr Ergebnis
// im internen Serialisierungsformat statt als lesbaren Text ausgeben.
const kindUmgebung = { ...process.env };
delete kindUmgebung.NODE_TEST_CONTEXT;

for (const datei of dateien) {
  test(datei, () => {
    const ergebnis = spawnSync(process.execPath, [path.join(hier, datei)], {
      encoding: 'utf8',
      timeout: 240000,
      env: kindUmgebung,
    });
    const ausgabe = `${ergebnis.stdout || ''}\n${ergebnis.stderr || ''}`.trim();
    if (ergebnis.error) {
      assert.fail(`Testdatei ${datei} konnte nicht gestartet werden: ${ergebnis.error.message}`);
    }
    assert.equal(ergebnis.status, 0, `Testdatei ${datei} schlug fehl:\n${ausgabe}`);
  });
}
