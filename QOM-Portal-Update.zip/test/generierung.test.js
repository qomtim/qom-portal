// Tests: Generierungs-Warteschlange (Läufer-API) – nur mit Läufer-Token,
// strikt getrennt vom Kunden-/Projekt-Token.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten } from './helfer.js';

umgebungVorbereiten('qom-test-gen-');
process.env.RUNNER_TOKEN = 'laeufer-geheim-token-0123456789';

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');

const RUNNER = 'laeufer-geheim-token-0123456789';
db.prepare(`INSERT INTO projects (slug, name, api_token, preview_token, metrics_token, projekt_typ, generierung_status)
            VALUES ('genkunde','Gen Kunde','api-x','prev-x','met-x','website','bereit')`).run();

const app = appErstellen();
after(async () => { await app.close(); });

test('Jobs-Liste: ohne/falsches Läufer-Token -> 401', async () => {
  assert.equal((await app.inject({ method: 'GET', url: '/api/v1/jobs' })).statusCode, 401);
  assert.equal((await app.inject({ method: 'GET', url: '/api/v1/jobs?token=falsch' })).statusCode, 401);
});

test('Jobs-Liste: mit Läufer-Token -> offener Auftrag erscheint', async () => {
  const r = await app.inject({ method: 'GET', url: `/api/v1/jobs?token=${RUNNER}` });
  assert.equal(r.statusCode, 200);
  const jobs = r.json().jobs;
  assert.ok(jobs.some((j) => j.slug === 'genkunde'), 'genkunde muss als Auftrag gelistet sein');
});

test('Status melden aktualisiert den Auftrag', async () => {
  const r = await app.inject({
    method: 'POST', url: `/api/v1/jobs/genkunde/status?token=${RUNNER}`,
    headers: { 'content-type': 'application/json' }, payload: { status: 'fertig', meldung: 'Website da' },
  });
  assert.equal(r.statusCode, 200);
  const p = db.prepare(`SELECT generierung_status FROM projects WHERE slug='genkunde'`).get();
  assert.match(p.generierung_status, /^fertig/);
});

test('Inhalt schreiben legt Felder im Portal an', async () => {
  const r = await app.inject({
    method: 'POST', url: `/api/v1/jobs/genkunde/content?token=${RUNNER}`,
    headers: { 'content-type': 'application/json' },
    payload: { felder: [{ key: 'Startseite Titel', label: 'Titel', group: 'Startseite', type: 'text', value: 'Hallo Welt' }] },
  });
  assert.equal(r.statusCode, 200);
  const f = db.prepare(`SELECT * FROM fields f JOIN projects p ON p.id=f.project_id WHERE p.slug='genkunde' AND f.key='startseite_titel'`).get();
  assert.ok(f, 'Feld muss angelegt sein');
  assert.equal(f.value_published, 'Hallo Welt');
  assert.equal(f.editable_by_editor, 1);
});

test('Läufer-Endpunkte ohne Token strikt gesperrt (401)', async () => {
  assert.equal((await app.inject({ method: 'POST', url: '/api/v1/jobs/genkunde/status', headers: { 'content-type': 'application/json' }, payload: { status: 'fertig' } })).statusCode, 401);
  assert.equal((await app.inject({ method: 'POST', url: '/api/v1/jobs/genkunde/content', headers: { 'content-type': 'application/json' }, payload: {} })).statusCode, 401);
});
