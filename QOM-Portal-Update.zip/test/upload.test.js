// Tests: Bild-Upload (multipart) – gültiges Bild, falscher Dateityp, CSRF.
import fs from 'node:fs';
import path from 'node:path';
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, anmelden, multipartBauen } from './helfer.js';

umgebungVorbereiten('qom-test-upload-');
const uploadsVerzeichnis = process.env.UPLOADS_DIR;

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');
const sharp = (await import('sharp')).default;

const PASSWORT = 'sicheres-test-passwort-1';
const hash = await passwortHashen(PASSWORT);
const editorId = db.prepare(
  `INSERT INTO users (email, pw_hash, name, is_admin) VALUES (?, ?, ?, 0)`
).run('uploader@example.com', hash, 'Uploader').lastInsertRowid;
const projektId = db.prepare(
  `INSERT INTO projects (slug, name, api_token, preview_token)
   VALUES ('upload-projekt', 'Upload Projekt', 'api-upload-0123456789', 'preview-upload-0123456789')`
).run().lastInsertRowid;
db.prepare(
  `INSERT INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`
).run(editorId, projektId);

const app = appErstellen();
after(async () => { await app.close(); });

const sitzung = await anmelden(app, 'uploader@example.com', PASSWORT);
assert.ok(sitzung.sid, 'Login muss klappen');

// Kleines Test-PNG (8×8, rot) direkt im Speicher erzeugen
const testPng = await sharp({
  create: { width: 8, height: 8, channels: 3, background: { r: 220, g: 30, b: 30 } },
}).png().toBuffer();

test('Gültiger PNG-Upload: liefert url und webp, Dateien existieren', async () => {
  const { body, contentType } = multipartBauen('datei', 'test.png', 'image/png', testPng);
  const antwort = await app.inject({
    method: 'POST',
    url: '/projekt/upload-projekt/upload',
    headers: {
      cookie: sitzung.cookie,
      'x-csrf-token': sitzung.csrf,
      'content-type': contentType,
    },
    payload: body,
  });
  assert.equal(antwort.statusCode, 200);
  const json = antwort.json();
  assert.equal(json.ok, true);
  assert.match(json.url, /^\/uploads\/upload-projekt\/[a-z0-9-]+\.png$/);
  assert.match(json.webp, /^\/uploads\/upload-projekt\/[a-z0-9-]+\.webp$/);

  const hauptDatei = path.join(uploadsVerzeichnis, 'upload-projekt', path.basename(json.url));
  const webpDatei = path.join(uploadsVerzeichnis, 'upload-projekt', path.basename(json.webp));
  assert.ok(fs.existsSync(hauptDatei), 'Hauptdatei liegt im Uploads-Ordner');
  assert.ok(fs.existsSync(webpDatei), 'WebP-Variante liegt im Uploads-Ordner');

  // Wird das Bild auch wieder ausgeliefert?
  const auslieferung = await app.inject({ method: 'GET', url: json.url });
  assert.equal(auslieferung.statusCode, 200);
  assert.match(String(auslieferung.headers['content-type']), /image\/png/);
});

test('Textdatei wird abgelehnt (415)', async () => {
  const { body, contentType } = multipartBauen(
    'datei', 'notizen.txt', 'text/plain', Buffer.from('Das ist kein Bild.')
  );
  const antwort = await app.inject({
    method: 'POST',
    url: '/projekt/upload-projekt/upload',
    headers: {
      cookie: sitzung.cookie,
      'x-csrf-token': sitzung.csrf,
      'content-type': contentType,
    },
    payload: body,
  });
  assert.equal(antwort.statusCode, 415);
});

test('Upload ohne CSRF-Header wird abgelehnt (403)', async () => {
  const { body, contentType } = multipartBauen('datei', 'test.png', 'image/png', testPng);
  const antwort = await app.inject({
    method: 'POST',
    url: '/projekt/upload-projekt/upload',
    headers: {
      cookie: sitzung.cookie, // angemeldet, aber ohne x-csrf-token
      'content-type': contentType,
    },
    payload: body,
  });
  assert.equal(antwort.statusCode, 403);
});

test('Upload ohne Login (aber mit gültigem CSRF): Weiterleitung zum Login', async () => {
  // Gültiges CSRF, aber KEINE Session – prüft die Auth-Grenze der Upload-Route.
  const { body, contentType } = multipartBauen('datei', 'test.png', 'image/png', testPng);
  const antwort = await app.inject({
    method: 'POST',
    url: '/projekt/upload-projekt/upload',
    headers: {
      cookie: `qom_csrf=${sitzung.csrf}`,
      'x-csrf-token': sitzung.csrf,
      'content-type': contentType,
    },
    payload: body,
  });
  assert.equal(antwort.statusCode, 302);
  assert.equal(antwort.headers.location, '/login');
});

test('Upload ohne Login und ohne CSRF: abgewiesen (403)', async () => {
  const { body, contentType } = multipartBauen('datei', 'test.png', 'image/png', testPng);
  const antwort = await app.inject({
    method: 'POST',
    url: '/projekt/upload-projekt/upload',
    headers: { 'content-type': contentType },
    payload: body,
  });
  assert.equal(antwort.statusCode, 403);
});
