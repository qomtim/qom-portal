// Tests: Blog – anlegen, HTML-Bereinigung, veröffentlichen, zurückziehen,
// und Blog-Sperre für Projekte ohne Blog.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, anmelden, ajaxPost } from './helfer.js';

umgebungVorbereiten('qom-test-blog-');

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');

const PASSWORT = 'sicheres-test-passwort-1';
const API_TOKEN = 'api-token-fuer-blogtests-0123456789';

const hash = await passwortHashen(PASSWORT);
const editorId = db.prepare(
  `INSERT INTO users (email, pw_hash, name, is_admin) VALUES (?, ?, ?, 0)`
).run('blogger@example.com', hash, 'Blogger').lastInsertRowid;

const mitBlogId = db.prepare(
  `INSERT INTO projects (slug, name, api_token, preview_token, blog_aktiv)
   VALUES ('blog-projekt', 'Mit Blog', ?, 'preview-blog-0123456789', 1)`
).run(API_TOKEN).lastInsertRowid;
const ohneBlogId = db.prepare(
  `INSERT INTO projects (slug, name, api_token, preview_token, blog_aktiv)
   VALUES ('ohne-blog', 'Ohne Blog', 'api-ohneblog-0123456789', 'preview-ohneblog-0123456789', 0)`
).run().lastInsertRowid;

const mitgliedschaft = db.prepare(
  `INSERT INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`
);
mitgliedschaft.run(editorId, mitBlogId);
mitgliedschaft.run(editorId, ohneBlogId);

const app = appErstellen();
after(async () => { await app.close(); });

const sitzung = await anmelden(app, 'blogger@example.com', PASSWORT);
assert.ok(sitzung.sid, 'Login muss klappen');

let beitragId;

test('Beitrag anlegen: <script> wird entfernt, erlaubte Formatierung bleibt', async () => {
  const antwort = await ajaxPost(app, sitzung, '/projekt/blog-projekt/blog/neu', {
    titel: 'Mein erster Beitrag',
    teaser: 'Kurzer Teaser',
    body_html: '<p>Hallo <b>fett</b> und <em>kursiv</em></p><script>alert(1)</script>',
  });
  assert.equal(antwort.statusCode, 200);
  const json = antwort.json();
  assert.equal(json.ok, true);
  beitragId = json.id;
  assert.ok(beitragId);

  const beitrag = db.prepare(`SELECT * FROM posts WHERE id = ?`).get(beitragId);
  assert.equal(beitrag.status, 'draft');
  assert.equal(beitrag.slug, 'mein-erster-beitrag');
  assert.ok(!beitrag.body_html.includes('<script'), 'Kein <script> im gespeicherten HTML');
  assert.ok(!beitrag.body_html.includes('alert(1)'), 'Auch der Script-Inhalt ist entfernt');
  assert.ok(beitrag.body_html.includes('<b>fett</b>'), 'Erlaubte Formatierung bleibt erhalten');
  assert.ok(beitrag.body_html.includes('<em>kursiv</em>'));
});

test('Entwurf erscheint noch nicht in der öffentlichen Posts-API', async () => {
  const antwort = await app.inject({
    method: 'GET',
    url: `/api/v1/projects/blog-projekt/posts?token=${API_TOKEN}`,
  });
  assert.equal(antwort.statusCode, 200);
  assert.deepEqual(antwort.json().beitraege, []);
});

test('Veröffentlichen: Beitrag erscheint in der Posts-API', async () => {
  const antwort = await ajaxPost(app, sitzung, `/projekt/blog-projekt/blog/${beitragId}/veroeffentlichen`, {});
  assert.equal(antwort.statusCode, 200);
  assert.equal(antwort.json().ok, true);

  const liste = await app.inject({
    method: 'GET',
    url: `/api/v1/projects/blog-projekt/posts?token=${API_TOKEN}`,
  });
  const beitraege = liste.json().beitraege;
  assert.equal(beitraege.length, 1);
  assert.equal(beitraege[0].titel, 'Mein erster Beitrag');
  assert.equal(beitraege[0].slug, 'mein-erster-beitrag');
  assert.equal(beitraege[0].status, 'published');
  assert.ok(beitraege[0].veroeffentlicht_am, 'Veröffentlichungsdatum ist gesetzt');
  assert.ok(beitraege[0].inhalt_html.includes('<b>fett</b>'));
  assert.ok(!beitraege[0].inhalt_html.includes('<script'));

  const einzeln = await app.inject({
    method: 'GET',
    url: `/api/v1/projects/blog-projekt/posts/mein-erster-beitrag?token=${API_TOKEN}`,
  });
  assert.equal(einzeln.statusCode, 200);
  assert.equal(einzeln.json().titel, 'Mein erster Beitrag');
});

test('Zurückziehen: Beitrag verschwindet aus der Posts-API', async () => {
  const antwort = await ajaxPost(app, sitzung, `/projekt/blog-projekt/blog/${beitragId}/zurueckziehen`, {});
  assert.equal(antwort.statusCode, 200);
  assert.equal(antwort.json().ok, true);

  const liste = await app.inject({
    method: 'GET',
    url: `/api/v1/projects/blog-projekt/posts?token=${API_TOKEN}`,
  });
  assert.deepEqual(liste.json().beitraege, []);

  const einzeln = await app.inject({
    method: 'GET',
    url: `/api/v1/projects/blog-projekt/posts/mein-erster-beitrag?token=${API_TOKEN}`,
  });
  assert.equal(einzeln.statusCode, 404);
});

test('Projekt ohne Blog: Editor erhält auf allen Blog-Routen 404', async () => {
  const liste = await app.inject({
    method: 'GET', url: '/projekt/ohne-blog/blog', headers: { cookie: sitzung.cookie },
  });
  assert.equal(liste.statusCode, 404);

  const neuSeite = await app.inject({
    method: 'GET', url: '/projekt/ohne-blog/blog/neu', headers: { cookie: sitzung.cookie },
  });
  assert.equal(neuSeite.statusCode, 404);

  const neuPost = await ajaxPost(app, sitzung, '/projekt/ohne-blog/blog/neu', {
    titel: 'Darf nicht existieren',
  });
  assert.equal(neuPost.statusCode, 404);

  const anzahl = db.prepare(`SELECT COUNT(*) AS n FROM posts WHERE project_id = ?`).get(ohneBlogId).n;
  assert.equal(anzahl, 0, 'Es darf kein Beitrag angelegt worden sein');
});
