// Gemeinsame Hilfsfunktionen für die Tests.
// WICHTIG: Diese Datei importiert bewusst NICHTS aus src/ –
// die Testdateien müssen zuerst DB_PATH/UPLOADS_DIR setzen und
// src/ erst danach dynamisch importieren.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';

// Frische, isolierte Umgebung für eine Testdatei anlegen.
// MUSS vor jedem Import aus src/ aufgerufen werden.
export function umgebungVorbereiten(praefix) {
  const wurzel = fs.mkdtempSync(path.join(os.tmpdir(), praefix));
  process.env.DB_PATH = path.join(wurzel, 'test.db');
  process.env.UPLOADS_DIR = path.join(wurzel, 'uploads');
  process.env.NODE_ENV = 'test';
  return wurzel;
}

// Einen Cookie-Wert aus einer inject-Antwort lesen (oder null).
export function cookieAuslesen(antwort, name) {
  const roh = antwort.headers['set-cookie'];
  const liste = Array.isArray(roh) ? roh : roh ? [roh] : [];
  for (const eintrag of liste) {
    if (eintrag.startsWith(`${name}=`)) {
      return eintrag.split(';')[0].slice(name.length + 1);
    }
  }
  return null;
}

// Login per Formular: erst GET /login (holt das CSRF-Cookie),
// dann POST /login mit Formular-Body inkl. _csrf.
// Achtung: /login ist auf 10 Versuche pro Minute begrenzt –
// pro Testdatei sparsam einsetzen.
export async function anmelden(app, email, passwort) {
  const loginSeite = await app.inject({ method: 'GET', url: '/login' });
  const csrf = cookieAuslesen(loginSeite, 'qom_csrf');
  const antwort = await app.inject({
    method: 'POST',
    url: '/login',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      cookie: `qom_csrf=${csrf}`,
    },
    payload:
      `email=${encodeURIComponent(email)}` +
      `&passwort=${encodeURIComponent(passwort)}` +
      `&_csrf=${encodeURIComponent(csrf)}`,
  });
  const sid = cookieAuslesen(antwort, 'qom_sid');
  return {
    antwort,
    csrf,
    sid,
    // Fertiger Cookie-Header für Folge-Requests
    cookie: sid ? `qom_sid=${sid}; qom_csrf=${csrf}` : `qom_csrf=${csrf}`,
  };
}

// AJAX-POST wie ihn das Editor-Frontend schickt (JSON + CSRF-Header).
export function ajaxPost(app, sitzung, url, daten = {}) {
  return app.inject({
    method: 'POST',
    url,
    headers: {
      cookie: sitzung.cookie,
      'x-csrf-token': sitzung.csrf,
      'x-requested-with': 'fetch',
      'content-type': 'application/json',
    },
    payload: daten,
  });
}

// Einen multipart/form-data-Body von Hand bauen (keine Zusatzpakete).
export function multipartBauen(feldName, dateiName, contentType, inhalt) {
  const grenze = `----qomTestGrenze${crypto.randomBytes(8).toString('hex')}`;
  const kopf = Buffer.from(
    `--${grenze}\r\n` +
    `Content-Disposition: form-data; name="${feldName}"; filename="${dateiName}"\r\n` +
    `Content-Type: ${contentType}\r\n\r\n`
  );
  const ende = Buffer.from(`\r\n--${grenze}--\r\n`);
  return {
    body: Buffer.concat([kopf, inhalt, ende]),
    contentType: `multipart/form-data; boundary=${grenze}`,
  };
}
