# QOM Editor

Das eigene CMS von **QOM – Quit Ordinary Marketing** (Bösingen FR). Der QOM Editor ersetzt Storyblok: Kunden ändern Texte und Bilder ihrer Website selbst, drücken «Veröffentlichen» – und die Änderung ist wenige Minuten später online. Eine Installation verwaltet alle Kundenseiten (Multi-Tenant), komplett QOM-gebrandet (White-Label).

## Architektur in 5 Sätzen

1. Der QOM Editor ist eine einzelne Node.js-Anwendung (Fastify 5), die als die im Infomaniak-Hosting inkludierte Node.js-Site unter `editor.quitordinarymarketing.ch` läuft.
2. Alle Daten liegen in einer SQLite-Datei (`better-sqlite3`, Standard: `data/qom-cms.db`); hochgeladene Bilder werden mit sharp optimiert (max. 2400 px, zusätzlich WebP-Variante) und unter `data/uploads/<projektslug>/` abgelegt.
3. Die Oberfläche wird serverseitig mit Nunjucks gerendert und nur mit wenig Vanilla-JS ergänzt – bewusst kein SPA-Framework, damit sie langfristig wartbar bleibt.
4. Inhalte haben immer zwei Stände: Tippen speichert automatisch in den Entwurf (`value_draft`/`data_draft`), «Veröffentlichen» kopiert den Entwurf in den veröffentlichten Stand und ruft den hinterlegten Deploy-Webhook des Projekts auf (HTTP POST, siehe `src/webhook.js`).
5. Die Kundenwebsites (Astro) holen die Inhalte beim Build über die nur lesende, Token-geschützte Content-API (`/api/v1/projects/:slug/content` bzw. `/posts`); mit `?version=draft&token=<preview_token>` liefert dieselbe API den Entwurfs-Stand für die Live-Vorschau.

## Ordnerstruktur

```
qom-editor/
├── data/                     # Laufzeitdaten (nicht im Git)
│   ├── qom-cms.db            # SQLite-Datenbank
│   └── uploads/<projekt>/    # optimierte Bilder pro Projekt
├── scripts/
│   ├── create-admin.mjs      # QOM-Admin anlegen / Passwort neu setzen
│   ├── seed-demo.mjs         # Demo-Projekt "QOM Website" mit Beispielinhalten
│   ├── backup.mjs            # nächtliches Backup (ZIP, 14 Tage) – siehe docs/betrieb-backup-monitoring.md
│   ├── restore.mjs           # Wiederherstellung aus einem Backup-ZIP
│   └── import-storyblok.mjs  # einmaliger Storyblok-Import (Migration, Phase 4)
├── src/
│   ├── server.js             # Einstiegspunkt: Fastify-App, Hooks (CSRF, Fehlerseiten), /health
│   ├── config.js             # zentrale Konfiguration aus Umgebungsvariablen
│   ├── db.js                 # SQLite-Schema + Audit-Log-Helfer
│   ├── auth.js               # Sessions, CSRF, Rollenprüfung
│   ├── security.js           # argon2, Tokens, Slugs, HTML-Bereinigung für den Blog
│   ├── mailer.js             # SMTP-Versand (ohne Konfiguration: nur Log-Ausgabe)
│   ├── webhook.js            # Deploy-Webhook nach dem Veröffentlichen
│   ├── routes/
│   │   ├── auth-routen.js    # Login, Logout, Einladung, Passwort-Reset, /projekte
│   │   ├── editor.js         # Editor: Felder, Sammlungen, Veröffentlichen
│   │   ├── blog.js           # Blog-Verwaltung (Beiträge, Entwurf/Veröffentlicht)
│   │   ├── uploads.js        # Bild-Upload + Auslieferung unter /uploads/
│   │   ├── admin.js          # QOM-Verwaltung: Projekte, Felder, Sammlungen, Nutzer, Audit
│   │   └── api.js            # Content-API für den Website-Build (nur GET, Token)
│   ├── views/                # Nunjucks-Vorlagen (Editor, Blog, Login, admin/…)
│   └── public/               # styles.css, editor.js, blog-editor.js (statisch)
├── docs/                     # Anleitungen (siehe unten)
├── .env.example              # Vorlage für die Konfiguration
└── package.json
```

## Lokale Entwicklung

Voraussetzung: Node.js 22 oder neuer.

```bash
npm install

# Ersten QOM-Admin anlegen (oder Passwort neu setzen)
npm run create-admin -- tim@qom.ch "Tim" "ein-sicheres-passwort"

# Demo-Projekt "QOM Website" mit Standardvorlage und Beispielinhalten
npm run seed-demo

# Server mit automatischem Neustart bei Codeänderungen
npm run dev
```

Danach im Browser `http://127.0.0.1:3000` öffnen und mit den oben angelegten Zugangsdaten anmelden. Passwörter müssen mindestens 10 Zeichen lang sein. Ohne SMTP-Konfiguration werden E-Mails (Einladungen, Passwort-Reset) nur ins Terminal-Log geschrieben; Einladungs-Links stehen zusätzlich in der Admin-Oberfläche zum Kopieren bereit.

Produktions-Start (so auch auf Infomaniak hinterlegt):

```bash
node --env-file=.env src/server.js
```

## Umgebungsvariablen

Vorlage: `.env.example` → als `.env` kopieren und ausfüllen. Gelesen werden sie in `src/config.js` (bzw. `scripts/backup.mjs`).

| Variable      | Pflicht    | Standard                         | Bedeutung |
|---------------|------------|----------------------------------|-----------|
| `NODE_ENV`    | produktiv  | `development`                    | `production` aktiviert sichere Cookies (`secure`), Info-Logging und Cache-Header |
| `HOST`        | nein       | `127.0.0.1`                      | Adresse, auf der der Server lauscht |
| `PORT`        | nein       | `3000`                           | Port des Servers (muss zur Port-Weiterleitung bei Infomaniak passen) |
| `BASE_URL`    | produktiv  | `http://127.0.0.1:<PORT>`        | Öffentliche Adresse des CMS – wird für Links in E-Mails (Einladung, Passwort-Reset) und die API-Adressen in der Verwaltung verwendet |
| `DATA_DIR`    | nein       | `<Projekt>/data`                 | Ordner für Datenbank und Uploads |
| `DB_PATH`     | nein       | `<DATA_DIR>/qom-cms.db`          | Pfad zur SQLite-Datei (übersteuert `DATA_DIR`) |
| `UPLOADS_DIR` | nein       | `<DATA_DIR>/uploads`             | Ordner für Bild-Uploads (übersteuert `DATA_DIR`) |
| `SMTP_HOST`   | produktiv  | *(leer)*                         | SMTP-Server, z.B. `mail.infomaniak.com` – leer = Mails nur ins Log |
| `SMTP_PORT`   | nein       | `465`                            | SMTP-Port |
| `SMTP_SECURE` | nein       | `true`                           | `false` nur für STARTTLS-Ports (587) |
| `SMTP_USER`   | produktiv  | *(leer)*                         | Postfach, z.B. `editor@quitordinarymarketing.ch` |
| `SMTP_PASS`   | produktiv  | *(leer)*                         | Passwort des Postfachs |
| `SMTP_FROM`   | nein       | `QOM Editor <editor@quitordinarymarketing.ch>` | Absender der E-Mails |
| `BACKUP_DIR`  | nein       | `<DATA_DIR>/backups`             | Zielordner für die nächtlichen Backup-ZIPs (`scripts/backup.mjs`) |

## Sicherheit (Kurzfassung)

argon2id-Passwort-Hashing · Sessions als httpOnly-Cookie (`qom_sid`, 14 Tage), Ablage in der Datenbank · CSRF-Schutz per Double-Submit-Cookie (`qom_csrf`) auf allen schreibenden Routen · Rate-Limiting auf Login und API · Upload-Prüfung anhand des Dateiinhalts (nur JPG/PNG/WebP/AVIF, max. 15 MB, Dateinamen werden neu vergeben) · API- und Preview-Tokens mit 32 Byte Entropie, pro Projekt rotierbar · Rechte werden ausschliesslich serverseitig geprüft; gesperrte oder fremde Inhalte antworten mit «Seite nicht gefunden» · Fehlerseiten ohne Stacktraces.

## Weitere Dokumentation

| Dokument | Für wen | Inhalt |
|----------|---------|--------|
| [docs/klick-testanleitung.md](docs/klick-testanleitung.md) | Tim | Klick-Testanleitungen für alle 5 Projektphasen, mit Abnahme-Checklisten |
| [docs/infomaniak-einrichtung.md](docs/infomaniak-einrichtung.md) | Tim + QOM-Technik | Subdomain, Node.js-Site, Upload, `.env`, Backup-Cron, SMTP-Postfach – Schritt für Schritt |
| [docs/neue-kundenseite-in-10-schritten.md](docs/neue-kundenseite-in-10-schritten.md) | QOM | Neue Kundenseite anlegen, vom Projekt bis zur Kunden-Einladung |
| [docs/betrieb-backup-monitoring.md](docs/betrieb-backup-monitoring.md) | QOM | Backup-Konzept, Restore-Prozedur (inkl. Pflicht-Restore-Test), Monitoring mit n8n |
