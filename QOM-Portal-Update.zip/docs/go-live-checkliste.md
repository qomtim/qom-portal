# Go-Live-Checkliste – bevor echte Kunden ins QOM-Portal dürfen

Ein unabhängiger Sicherheits-Audit hat bestätigt: **Die Mandanten-Trennung im Code ist solide** – ein Kunde kann technisch nicht die Daten anderer Kunden sehen. Was noch fehlt, ist nicht der Code, sondern der **saubere Produktionsstart**. Diese Punkte MÜSSEN erledigt sein, bevor der erste echte Kunde einen Zugang bekommt. Das Meiste macht die QOM-Technik (Claude/du gemeinsam) beim Aufsetzen auf Infomaniak.

## Zwingend vor dem ersten Kunden (Blocker)

- [ ] **Frische Produktions-Datenbank auf dem Server.** Niemals die aktuelle Test-Datenbank aus dem Google-Drive-Ordner verwenden. Auf Infomaniak eine leere DB erzeugen; in der `.env` `DATA_DIR` auf einen Serverpfad **ausserhalb** jeder Cloud-Synchronisation setzen. (Ein eingebauter Schutz verweigert im Produktionsmodus den Start, falls die DB doch in einem Sync-Ordner liegt.)
- [ ] **Alle Test-/Demo-Konten entfernen** (`tim@qom.ch`, `kunde@testkunde.ch`, `mitarbeiter@qom.ch`, `glace@kunde.ch`) und die Demo-Projekte (`testkunde`, `ads-demo`) löschen. In der frischen Produktions-DB entstehen diese gar nicht erst (die Demo-Skripte sind im Produktionsmodus gesperrt).
- [ ] **Echtes Geschäftsführer-Konto mit starkem Passwort** anlegen – nur über `npm run create-admin` (nicht über die Demo-Skripte). Passwort NICHT im Code/Chat, sondern in einem Passwort-Manager.
- [ ] **Proxy-Einstellung setzen.** Auf Infomaniak läuft die App hinter einem Webserver. In der `.env` `TRUST_PROXY` passend setzen (Anzahl Proxy-Schritte, meist `1`), damit der Login-Schutz die echte Kunden-IP sieht und nicht fälschbar ist.
- [ ] **SMTP hinterlegen** (`.env`), damit Einladungen, Passwort-Reset und Video-Benachrichtigungen wirklich per Mail rausgehen.
- [ ] **HTTPS erzwingen** (Infomaniak-Zertifikat). Die Cookies werden im Produktionsmodus automatisch als „secure" gesetzt – funktioniert nur über HTTPS.
- [ ] **Nächtliches Backup einrichten** (Cron: `node scripts/backup.mjs`, 03:30) und **einmal einen Restore testen** (siehe `betrieb-backup-monitoring.md`).

## Bereits erledigt (im Code abgesichert)

- ✅ Mandanten-Trennung serverseitig auf jeder Route (Kunde erreicht fremde Projekte nicht – 404).
- ✅ Passwörter mit argon2id gehasht; SQL nur über Prepared Statements.
- ✅ Blog-Editor XSS-fest (schädlicher Code wird entfernt).
- ✅ Login-Schutz: IP-Ratenlimit **plus** Konto-Sperre nach zu vielen Fehlversuchen.
- ✅ Einladungs-Link kann kein bestehendes Konto ohne Passwort übernehmen.
- ✅ Session-Ablauf beim Bearbeiten zeigt eine klare Meldung (kein stiller Datenverlust).
- ✅ Upload-Schutz gegen überdimensionierte Bilder („Bild-Bomben").
- ✅ Sauberes Herunterfahren + Fehler-Logging; Blog warnt vor dem Verlassen mit ungespeicherten Änderungen.
- ✅ Kennzahlen-Ingest (Ads) über ein eigenes Schreib-Token, getrennt vom Lese-Token.

## Empfohlen bald danach

- [ ] Auto-Neustart des Servers absichern (Infomaniak Passenger/systemd) statt manuellem Neustart.
- [ ] Optimistische Sperre, damit sich zwei gleichzeitige Bearbeiter (Kunde + Mitarbeiter) nicht lautlos überschreiben.
- [ ] Backups verschlüsselt ablegen (die ZIPs enthalten alle Kundendaten).
- [ ] Datenschutz-Prozess vervollständigen: Löschkonzept inkl. Audit-Log, Datenexport, Auftragsverarbeitungsvertrag (nDSG/DSGVO).

## Wo liegen die Kundendaten? (Kurzantwort)

Alle Kundendaten stecken in **einer Datenbankdatei** plus dem Bilder-Ordner – im Betrieb auf dem **Schweizer Infomaniak-Server**, ausserhalb jeder Cloud-Synchronisation. Weitergeben nur über einen sauberen Backup-Schnappschuss (`npm run backup`), **nie** durch Kopieren der laufenden Datei. Ein Backup enthält **alle** Kunden – also vertraulich behandeln. Das grösste reale Leck-Risiko ist nicht der Code, sondern ein zu weit verteilter **Geschäftsführer-Zugang** – deshalb die Punkte oben.
