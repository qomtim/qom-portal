# Das laufende Portal aktualisieren (neue Version einspielen)

Wenn es eine neue Version gibt (z.B. `QOM-Portal-Update.zip`), so spielst du sie ein.
**Deine Daten (Kunden, Inhalte, Bilder) und die `.env` bleiben dabei erhalten** – die stecken in
`data/`, `backups/` und `.env`, und die sind im Update-Paket NICHT enthalten.

## Schritt 1: Neue ZIP auf GitHub legen
Lade `QOM-Portal-Update.zip` ins GitHub-Repo `qomtim/qom-portal` (wie beim ersten Mal:
„Add file → Upload files" → Datei reinziehen → „Commit changes"). Der Roh-Link ist dann:
`https://raw.githubusercontent.com/qomtim/qom-portal/main/QOM-Portal-Update.zip`

## Schritt 2: In der SSH-Konsole einspielen
```bash
cd ~/sites/portal.quitordinarymarketing.ch && cp .env .env.sicherung && curl -L "https://raw.githubusercontent.com/qomtim/qom-portal/main/QOM-Portal-Update.zip" -o update.zip && unzip -oq update.zip && rm update.zip && echo "Update eingespielt"
```
Das überschreibt nur die Programmdateien (`src/`, `scripts/`, …). `data/`, `backups/` und `.env`
bleiben unangetastet. Neue Datenbank-Spalten werden beim nächsten Start automatisch ergänzt.

## Schritt 3: Neu starten
Im Manager beim Node-Bereich **„Neu starten"** klicken. Im Ausführungs-Log sollte wieder
`QOM Editor läuft …` erscheinen. Fertig.

> Tipp: Danach kurz `node --env-file-if-exists=.env scripts/pruefe-produktion.mjs` laufen lassen –
> der Bereitschaftscheck bestätigt, dass alles sauber ist.

## Sicherheit nach dem ersten echten Kunden
Sobald der Code sicher läuft, kannst du das öffentliche GitHub-Repo `qom-portal` wieder **löschen
oder auf privat** stellen (es dient nur als Transportweg).
