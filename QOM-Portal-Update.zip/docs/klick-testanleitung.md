# Klick-Testanleitung für Tim

Diese Anleitung führt dich durch alle 5 Projektphasen. Du brauchst dafür **nur deinen Browser** – keine Technik-Kenntnisse, kein Terminal. Alles, was am Computer im Hintergrund passieren muss, ist mit **«macht Claude/QOM-Technik»** markiert; das erledigst nicht du.

Die Adresse des QOM Editors:

- **Lokal (zum Testen auf deinem Computer):** `http://127.0.0.1:3000`
- **Produktiv (später, öffentlich):** `https://editor.quitordinarymarketing.ch`

Deine Zugangsdaten (E-Mail + Passwort) hat dir Claude/QOM-Technik eingerichtet. Falls du sie nicht hast: zuerst danach fragen.

---

## Phase 1 – Text ändern und veröffentlichen (MVP)

**Vorbereitung (macht Claude/QOM-Technik):** Server läuft, dein Admin-Konto existiert, das Projekt «QOM Website» ist angelegt und der Deploy-Webhook ist hinterlegt.

### So testest du

1. Öffne im Browser `http://127.0.0.1:3000` (lokal) bzw. `https://editor.quitordinarymarketing.ch` (produktiv).
2. Du siehst die Anmeldeseite: Überschrift **«Willkommen»**, darunter «Melde dich an, um deine Website zu bearbeiten.» Gib deine **E-Mail-Adresse** und dein **Passwort** ein und klicke auf **«Anmelden»**.
3. Nach der Anmeldung siehst du **«Hallo Tim»** und deine Projekte als Kacheln. Klicke auf **«QOM Website»**.
   *(Hinweis: Kunden mit nur einer Website landen direkt in ihrem Projekt und sehen diese Übersicht gar nicht.)*
4. Jetzt bist du im Editor. Oben links steht der Projektname, darunter der Hinweis **«Alle Änderungen werden automatisch gespeichert.»** Oben rechts ist der grosse blaue Knopf **«Veröffentlichen»**. Die Inhalte sind als Karten nach Website-Bereichen gruppiert, z.B. **«Startseite – Titelbereich»**, **«Kontakt»**, **«Team»**.
5. Klicke in ein Textfeld, z.B. **«Titel»** im Bereich «Startseite – Titelbereich», und ändere den Text.
6. Es gibt **keinen Speichern-Knopf** – kurz nach dem Tippen erscheint oben **«Gespeichert ✓»**, und rechts oben taucht die Markierung **«Unveröffentlichte Änderungen»** auf. Deine Änderung ist jetzt als Entwurf gesichert, aber noch nicht online.
7. Klicke auf **«Veröffentlichen»**. Der Knopf zeigt kurz **«Wird veröffentlicht …»**, dann erscheint eine grüne Meldung: **«Deine Änderungen sind in ca. 2 Minuten online.»** Die Markierung «Unveröffentlichte Änderungen» verschwindet.
8. Warte ca. 2 Minuten und öffne `https://www.quitordinarymarketing.ch` in einem neuen Tab (allenfalls Seite neu laden).

### Das solltest du sehen (Abnahme Phase 1)

- [ ] Anmeldeseite mit «Willkommen» erscheint, Anmeldung mit E-Mail + Passwort klappt.
- [ ] Falsches Passwort ergibt die Meldung «E-Mail oder Passwort stimmt nicht.» (und nach 10 schnellen Versuchen wird kurz blockiert).
- [ ] Im Editor sind die Inhalte nach Bereichen mit verständlichen Namen gruppiert – nirgends Fachbegriffe wie «Slug» oder «Story».
- [ ] Beim Tippen erscheint von selbst «Gespeichert ✓» und die Markierung «Unveröffentlichte Änderungen».
- [ ] Nach dem Klick auf «Veröffentlichen» erscheint die grüne Erfolgsmeldung.
- [ ] Nach ca. 2 Minuten ist der geänderte Text auf quitordinarymarketing.ch sichtbar – **ohne dass Storyblok im Spiel war**.
- [ ] In der Verwaltung unter **Verwaltung → QOM Website → Audit-Log** steht, wer wann was geändert hat (z.B. `feld_gespeichert`, `veroeffentlicht`, `deploy_webhook`).

---

## Phase 2 – Bilder und Blog (am Handy)

**Vorbereitung (macht Claude/QOM-Technik):** Blog ist für das Projekt aktiviert, die Blog-Seiten sind auf der Website eingebaut.

### So testest du

1. Öffne den QOM Editor **auf deinem Handy** und melde dich an.
2. **Bild testen:** Tippe im Editor auf ein Bild-Feld (gestrichelte Fläche mit «Bild hierhin ziehen oder auswählen»). Wähle ein Foto aus deiner Galerie. Nach kurzem Moment erscheint das Bild als Vorschau im Feld. (Am Computer kannst du Bilder auch einfach auf die Fläche ziehen. Erlaubt: JPG, PNG oder WebP, bis 15 MB – der Editor verkleinert und optimiert alles automatisch.)
3. **Blog testen:** Oben im Editor gibt es die Karte **«Blog»** – tippe auf **«Blog öffnen»**, dann auf **«+ Neuer Beitrag»**.
4. Fülle aus:
   - **Titel** (z.B. «Unser erster Blogbeitrag»)
   - **Titelbild**: antippen und Foto wählen
   - **Kurzbeschreibung** (erscheint in der Blog-Übersicht)
   - **Text**: einfach drauflosschreiben. Über dem Textfeld gibt es Knöpfe für **Fett (F)**, **Kursiv (K)**, **Titel**, **Untertitel**, **Liste**, **nummerierte Liste** und **Link** – mehr braucht es nicht.
5. Tippe auf **«Speichern»** – der Beitrag ist jetzt ein **Entwurf** (graue Markierung «Entwurf»), noch nicht öffentlich.
6. Tippe auf **«Veröffentlichen»**. Es erscheint: **«Dein Beitrag ist unterwegs – in ca. 2 Minuten ist er online.»** Die Markierung wechselt auf grün **«Veröffentlicht»**.
7. Prüfe nach ca. 2 Minuten die Blog-Übersicht auf der Website.
8. Teste auch **«Beitrag offline nehmen»** (macht aus dem Beitrag wieder einen Entwurf) und – bei einem Testbeitrag – **«Beitrag löschen»** (fragt vorher nach).

### Das solltest du sehen (Abnahme Phase 2)

- [ ] Bild-Upload klappt am Handy aus der Galerie; das Bild erscheint sofort als Vorschau.
- [ ] Ein am Handy erstellter Blogbeitrag mit Titelbild erscheint nach dem Veröffentlichen auf der Website (Blog-Übersicht + eigene Beitragsseite).
- [ ] Entwürfe sind auf der Website **nicht** sichtbar, nur veröffentlichte Beiträge.
- [ ] Die Bedienung am Handy ist gut möglich (nichts abgeschnitten, Knöpfe gut tippbar).

---

## Phase 3 – Rechte pro Kunde (Multi-Tenant)

### So testest du

1. Melde dich als Admin an und gehe auf **«Verwaltung»** (oben im Menü).
2. Lege testweise ein zweites Projekt an (Karte «Neue Kundenseite anlegen») oder verwende ein bestehendes Testprojekt.
3. Gehe im Projekt auf **Einstellungen → Felder** und entferne bei einem Feld (z.B. «Text in der Fusszeile») das Häkchen **«Kunde darf bearbeiten»**, dann «Speichern». Als Admin siehst du dieses Feld im Editor nun mit einem **Schloss-Symbol**.
4. Gehe auf den Reiter **«Nutzer»** und lade dich selbst mit einer **zweiten E-Mail-Adresse** ein (Feld `kunde@firma.ch`, Knopf **«Einladen»**). Falls SMTP noch nicht eingerichtet ist, zeigt die Seite den Einladungs-Link direkt an – kopiere ihn.
5. Öffne den Einladungs-Link in einem **privaten Browserfenster** (damit du nicht als Admin angemeldet bist). Gib Name und ein Passwort (mind. 10 Zeichen) ein. Du landest direkt im Projekt – als «Kunde».
6. Prüfe als dieser Testkunde:
   - Das gesperrte Feld ist **nirgends** zu sehen.
   - Der Menüpunkt «Verwaltung» fehlt.
   - Tippe von Hand Adressen ein: `/admin` sowie die Adresse eines **anderen** Projekts (z.B. `/projekt/qom-website`, wenn der Testkunde nur im Testprojekt ist). Beides muss **«Seite nicht gefunden»** zeigen – gesperrte Inhalte sind also auch per direkter Adresse nicht erreichbar.

### Das solltest du sehen (Abnahme Phase 3)

- [ ] Der Testkunde sieht nur die für ihn freigegebenen Felder und Bereiche.
- [ ] Gesperrte Felder und fremde Projekte sind auch per direkt eingetippter Adresse nicht erreichbar («Seite nicht gefunden»).
- [ ] Der Einladungs-Link funktioniert genau einmal und läuft nach 7 Tagen ab (ein zweites Öffnen nach Kontoerstellung zeigt «Einladung nicht mehr gültig»).
- [ ] Die Anmeldeseite und der Editor zeigen nirgends einen Fremdanbieter – alles ist QOM-gebrandet (mit Projekt-Logo, falls hinterlegt).

---

## Phase 4 – Migration und Live-Vorschau

**Vorbereitung (macht Claude/QOM-Technik):** Storyblok-Inhalte samt allen Bildern wurden importiert; der Website-Build holt die Inhalte jetzt vom QOM CMS (ohne Storyblok-Token); das Vorschau-Skript ist auf der Website eingebaut.

### So testest du

1. Öffne das Projekt «QOM Website» im Editor. Rechts neben den Feldern (am Handy darunter) siehst du die Spalte **«Vorschau deiner Website»** mit deiner Website darin.
2. Ändere einen Text, z.B. den Titel der Startseite. **Noch während du tippst** aktualisiert sich der Text in der Vorschau.
3. Wichtig: Öffne parallel die echte Website in einem anderen Tab – dort ist **noch der alte Text** zu sehen. Die Vorschau zeigt den Entwurf, die Website den veröffentlichten Stand.
4. Vergleiche stichprobenartig die importierten Inhalte (Team, Referenzen, Kundenstimmen, FAQ, Bilder) mit dem alten Stand: Ist alles da? Sehen die Bilder gut aus?
5. Erst wenn du zufrieden bist, klickst du «Veröffentlichen» – und Claude/QOM-Technik bestätigt dir, dass der Website-Build komplett ohne Storyblok läuft und Storyblok gekündigt werden kann.

### Das solltest du sehen (Abnahme Phase 4)

- [ ] Die Vorschau im Editor aktualisiert sich live beim Tippen, ohne zu veröffentlichen.
- [ ] Die echte Website zeigt bis zum Veröffentlichen weiterhin den alten Stand.
- [ ] Alle bisherigen Inhalte und Bilder sind vollständig im QOM Editor angekommen (Stichproben).
- [ ] Bestätigung von Claude/QOM-Technik: Der Website-Build läuft ohne Storyblok-Token vollständig über das QOM CMS – Storyblok ist kündbar.

---

## Phase 5 – Betrieb: Backup und Alarm

Details stehen in [betrieb-backup-monitoring.md](betrieb-backup-monitoring.md). Dein Teil ist das Abnehmen der zwei Pflicht-Tests:

### Test 1: Wiederherstellung (Restore)

1. Claude/QOM-Technik spielt ein echtes nächtliches Backup auf einer Testumgebung zurück (das ist der **einmalige Pflicht-Restore-Test**).
2. Du meldest dich danach an und prüfst: Sind alle Projekte, Inhalte, Blogbeiträge und Bilder da? Funktioniert das Anmelden?

### Test 2: Ausfall-Alarm

1. Claude/QOM-Technik stoppt den QOM Editor kurz absichtlich (oder simuliert einen Ausfall).
2. Innerhalb von ca. 30 Minuten musst **du** eine Alarm-Nachricht erhalten («QOM Editor ist nicht erreichbar»).
3. Nach dem Neustart bleibt es wieder still (kein Dauer-Alarm).

### Das solltest du sehen (Abnahme Phase 5)

- [ ] Der Restore-Test wurde real durchgeführt und du hast die wiederhergestellten Inhalte selbst gesehen.
- [ ] Du hast die Ausfall-Alarmnachricht tatsächlich auf deinem Gerät empfangen.
- [ ] Es liegen tägliche Backups der letzten 14 Tage vor (Claude/QOM-Technik zeigt dir die Liste).
- [ ] Die Anleitung «Neue Kundenseite in 10 Schritten» liegt vor und du hast sie einmal selbst durchgespielt.

Wenn alle Kästchen in allen 5 Phasen abgehakt sind, ist das Projekt im Sinn des Projektauftrags fertig.
