# Neue Kundenseite in 10 Schritten anlegen

Diese Anleitung führt vom leeren Projekt bis zum eingeladenen Kunden mit ersten veröffentlichten Inhalten. Du brauchst: ein QOM-Admin-Konto im QOM Editor. Nur Schritt 7 enthält Technik-Arbeit – die ist markiert mit **«macht Claude/QOM-Technik»**.

---

**1. Anmelden und Verwaltung öffnen.**
Melde dich unter `https://editor.quitordinarymarketing.ch` an und klicke oben im Menü auf **«Verwaltung»**. Du siehst die Karte «Neue Kundenseite anlegen» und darunter die Tabelle aller Projekte.

**2. Projekt anlegen.**
Fülle die Karte **«Neue Kundenseite anlegen»** aus:
- **Name des Kunden / der Website** – z.B. «Sporthalle Bösingen» (Pflichtfeld).
- **Adresse der Website (für die Vorschau)** – z.B. `https://www.sporthalle-boesingen.ch`. Ohne diese Adresse gibt es im Editor keine Vorschau-Spalte.
- **Deploy-Webhook (löst den Website-Neubau aus)** – kannst du vorerst leer lassen; kommt in Schritt 7.
- Häkchen **«Blog für den Kunden aktivieren»** – nur setzen, wenn der Kunde bloggen soll.
- Häkchen **«Mit QOM-Standardvorlage starten»** – angehakt lassen. Das legt automatisch die typischen Bereiche an: Titelbereich, Einleitung, Kontakt, Logo/Fusszeile sowie die Listen Team, Referenzen, Kundenstimmen, Kennzahlen und Häufige Fragen.

Klicke auf **«Projekt anlegen»** – du landest direkt in den Einstellungen des neuen Projekts.

**3. Einstellungen vervollständigen.**
Auf der Einstellungs-Seite kannst du Name, Website-Adresse und Webhook jederzeit ändern. Für den White-Label-Auftritt: Lade zuerst das Kundenlogo im Editor in das Bild-Feld **«Logo»** hoch (siehe Schritt 6), kopiere danach die Bild-Adresse (Rechtsklick auf die Vorschau → «Bildadresse kopieren», sie sieht so aus: `/uploads/<projekt>/xxxx.png`) und trage sie hier unter **«Logo-Adresse»** ein. Ab dann sieht der Kunde oben links sein Logo statt «QOM Editor».

**4. Felder prüfen und anpassen.**
Wechsle auf den Reiter **«Felder»**. Hier bestimmst du, welche einzelnen Inhalte es gibt und was der Kunde davon anfassen darf:
- Neues Feld: **Bereich** (Gruppe, z.B. «Startseite – Titelbereich»), **Beschriftung für den Kunden** (z.B. «Titel»), **Art** («Kurzer Text», «Langer Text» oder «Bild»), Technischer Name kann leer bleiben.
- Pro Feld der Schalter **«Kunde darf bearbeiten»**: Häkchen weg = der Kunde sieht das Feld gar nicht; nur QOM kann es ändern. Im Editor erscheint es für Admins mit einem Schloss-Symbol.
- Die **Reihenfolge**-Zahl steuert die Sortierung im Editor.

**5. Sammlungen prüfen und anpassen.**
Reiter **«Sammlungen»**: Eine Sammlung ist eine Liste gleichartiger Einträge (Team, Referenzen, FAQ …). Die Spalten definierst du als eine Zeile pro Spalte im Format `name | Beschriftung | text` (Arten: `text`, `textarea`, `image`). Auch hier gibt es pro Sammlung den Schalter **«Kunde darf bearbeiten»**. Für die Standardfälle musst du meist nichts ändern.

**6. Erste Inhalte einpflegen.**
Klicke oben rechts auf **«Als Editor öffnen»**. Trage die Startinhalte des Kunden ein (Texte tippen – gespeichert wird automatisch, «Gespeichert ✓» erscheint oben) und lade die Bilder hoch (in die gestrichelten Bild-Flächen ziehen oder anklicken und auswählen). Bei Sammlungen: **«+ Eintrag hinzufügen»**, Felder ausfüllen, mit den Pfeil-Knöpfen sortieren. So übergibst du dem Kunden keine leere Hülle.

**7. Website mit dem CMS verbinden (macht Claude/QOM-Technik).**
In den Projekt-Einstellungen zeigt die Karte **«Zugriff für den Website-Build»** die drei fertigen API-Adressen (veröffentlichte Inhalte, Entwurf/Vorschau, Blogbeiträge). Damit wird eingerichtet:
- Im Website-Repository des Kunden die GitHub-Secrets `QOM_CMS_URL` und `QOM_CMS_TOKEN` setzen, damit der Build die Inhalte vom QOM Editor holt.
- Den Auslöser für den Neubau bereitstellen (n8n-Webhook, der ein `repository_dispatch` an GitHub schickt) und dessen Adresse im Projekt als **Deploy-Webhook** eintragen.
- Falls Live-Vorschau gewünscht: das Vorschau-Skript auf der Kundenwebsite einbauen.
Die Tokens lassen sich in derselben Karte jederzeit neu erzeugen («API-Token neu erzeugen» / «Preview-Token neu erzeugen») – danach müssen die GitHub-Secrets nachgeführt werden.

**8. Probeveröffentlichung.**
Öffne das Projekt als Editor und klicke auf **«Veröffentlichen»**. Es muss die grüne Meldung **«Deine Änderungen sind in ca. 2 Minuten online.»** erscheinen. Prüfe nach ca. 2 Minuten die Kundenwebsite. Kommt stattdessen eine Fehlermeldung zum Webhook, stimmt etwas in Schritt 7 nicht – im Reiter **«Audit-Log»** steht unter `deploy_webhook`, was der Webhook geantwortet hat.

**9. Kunde einladen.**
Reiter **«Nutzer»** → E-Mail-Adresse des Kunden eintragen → **«Einladen»**. Der Kunde erhält eine E-Mail mit einem Link (7 Tage gültig), setzt Name und Passwort (mind. 10 Zeichen) und landet direkt in seinem Projekt. Er sieht ausschliesslich dieses Projekt und nur die freigegebenen Inhalte. Falls SMTP (noch) nicht eingerichtet ist, zeigt die Seite den Einladungs-Link unter «Offene Einladungen» an – kopiere ihn und schicke ihn dem Kunden selbst. Weitere Personen der Kundenfirma lädst du genauso ein.

**10. Übergabe und Kontrolle.**
Lass den Kunden (am besten gleich am Telefon oder vor Ort) eine erste eigene Änderung machen: Text anpassen, «Veröffentlichen» drücken, Erfolgsmeldung sehen, Website prüfen. Kontrolliere danach im Reiter **«Audit-Log»**, dass seine Aktionen sauber protokolliert sind (`feld_gespeichert`, `veroeffentlicht` …). Damit ist die Kundenseite live: Kunde eingeladen, erste Inhalte veröffentlicht – fertig.

---

**Kleines Nachschlagewerk**

| Wo | Was |
|----|-----|
| Verwaltung → Projekt → Einstellungen | Name, Website-Adresse, Deploy-Webhook, Logo, Blog an/aus, Tokens, Projekt löschen |
| Verwaltung → Projekt → Felder | Einzelne Inhalte + Schalter «Kunde darf bearbeiten» |
| Verwaltung → Projekt → Sammlungen | Listen (Team, FAQ …) + Spalten + Schalter «Kunde darf bearbeiten» |
| Verwaltung → Projekt → Nutzer | Einladen, Zugriff entziehen, offene Einladungen |
| Verwaltung → Projekt → Audit-Log | Die letzten 200 Aktionen: wer hat wann was geändert |
