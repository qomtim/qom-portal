# QOM Editor – Überblick & Neuerungen (für Tim)

Kurz und ohne Fachchinesisch: Was der QOM Editor jetzt kann und wie du es zum Ausprobieren startest.

## Zum Ausprobieren starten (lokal auf deinem Mac)

Diese Schritte macht die QOM-Technik (Claude), du musst nichts tippen. Zum Nachvollziehen:

1. Der Server läuft unter **http://127.0.0.1:3000**
2. Melde dich mit einem der Testkonten an (siehe unten).

### Testkonten

| Rolle | Anmeldung | Passwort | Sieht |
|---|---|---|---|
| **Geschäftsführer** (du) | `waebert.business@gmail.com` | `qom-test-2026` | alles |
| Geschäftsführer (2.) | `tim@qom.ch` | `test-passwort-123` | alles |
| **Mitarbeiter** | `mitarbeiter@qom.ch` | `mitarbeiter-2026` | nur „QOM Website" |
| **Kunde** | `kunde@testkunde.ch` | `kunden-passwort-99` | nur „Testkunde AG" |

> Diese Passwörter sind nur zum Testen. Für den echten Betrieb legst du eigene Konten mit eigenen Passwörtern an (unter „Konten").

## Die drei Rollen (wie „intra" und „extra")

- **Geschäftsführer** (ihr Partner): sehen und verwalten **alle** Projekte, legen Konten an, bestimmen pro Kunde, was er darf.
- **Mitarbeiter** (intern): bekommen **einzelne Seiten zugewiesen** und dürfen dort **alles** bearbeiten – auch Felder, die für Kunden gesperrt sind. Kein Zugriff auf die Verwaltung.
- **Kunde** (extern): sieht **nur seine eigene Seite** und darf genau das, was du für ihn freischaltest. Möglichst einfach, damit auch ein Laie klarkommt.

Konten anlegen: oben im Menü **„Konten" → „Neues Konto anlegen"**. Rolle wählen, bei Mitarbeiter/Kunde die Projekte ankreuzen. Passwort selbst setzen **oder** leer lassen – dann bekommt die Person einen Link, um es selbst zu setzen (per E-Mail, sobald SMTP eingerichtet ist).

## Wie viel ein Kunde bearbeiten darf (abstufbar)

Pro Projekt wählst du unter **Einstellungen → „Was darf der Kunde bearbeiten?"** eine von drei Vorlagen:

- **Nur Texte** – der Kunde ändert ausschliesslich Texte. Am einfachsten, nichts lenkt ab.
- **Texte & Bilder** – für die meisten Kunden ideal.
- **Alles** – Texte, Bilder, Listen (Team, FAQ …), Blog und Bereiche ein-/ausblenden.

Zusätzlich kannst du **feiner justieren**: unter „Felder" gibt es für **jedes einzelne Feld** einen Schalter „Kunde darf bearbeiten". So sieht ein Kunde, der nur ab und zu einen Text ändert, wirklich nur diesen einen – nicht überladen.

## Bereiche (Seiten) ein- und ausblenden

Unter **„Bereiche"** legst du Abschnitte der Website an (z.B. Team, Referenzen, Blog). Wenn im Umfang „Bereiche ein-/ausblenden" aktiv ist, kann der Kunde diese Abschnitte im Editor per Schalter **an- und ausschalten** – die Website blendet sie beim Veröffentlichen entsprechend ein oder aus. (Auf der Website müssen die Abschnitte dazu das Attribut `data-qom-bereich="team"` tragen – das erledigt Claude beim Bauen der Seite.)

## Neue Kundenseite anlegen + von Claude generieren lassen

Unter **„Projekte" → „Neue Kundenseite anlegen"** trägst du ein:

- **Name** des Kunden
- **Adresse der alten Seite** (falls es eine gibt)
- **Google-Drive-Ordner** (Bilder, Dokumente, Kick-off, Meetings)
- **Bemerkungen für Claude** (Stil, Besonderheiten, was die Seite können soll)

Mit **„Direkt an Claude schicken"** (oder später dem Knopf „An Claude senden" in den Einstellungen) geht ein Auftrag mit all diesen Angaben an euren **n8n-Workflow**, der auf dem Server Claude anstösst und die Website baut. Das läuft **im Hintergrund auf dem Server** – nicht auf deinem Computer. Damit das aktiv ist, muss einmalig der Generierungs-Webhook hinterlegt werden (`GENERIERUNG_WEBHOOK_URL` bzw. pro Projekt in den Einstellungen).

> Den n8n-Workflow selbst (der Claude auf dem Server startet) richten wir separat ein – das CMS liefert ihm alles Nötige (Kundenname, Drive-Link, Bemerkungen, API-Token der Seite).

## Was sonst noch drin steckt

- **Veröffentlichen = live**: „Veröffentlichen" macht aus dem Entwurf den echten Stand und stösst den Website-Neubau an („in ca. 2 Minuten online").
- **Bilder**: einfach reinziehen; werden automatisch verkleinert und optimiert.
- **Blog**: einfacher Editor (fett, kursiv, Zwischentitel, Listen, Links) – am Handy bedienbar. Schädlicher Code wird serverseitig entfernt.
- **Backups**: nächtliches Backup (14 Tage), getesteter Restore. Siehe `docs/betrieb-backup-monitoring.md`.
- **White-Label**: hinterlegst du beim Projekt ein Kundenlogo, sieht der Kunde im Editor **sein** Logo statt QOM.

## Weiterführende Anleitungen

- `docs/klick-testanleitung.md` – Schritt für Schritt durchklicken
- `docs/neue-kundenseite-in-10-schritten.md` – neue Seite anlegen
- `docs/infomaniak-einrichtung.md` – auf dem Server einrichten
- `docs/betrieb-backup-monitoring.md` – Backup, Restore, Überwachung
- `website-integration/ANLEITUNG.md` – das CMS mit einer Astro-Website verbinden
