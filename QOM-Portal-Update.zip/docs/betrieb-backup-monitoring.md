# Betrieb: Backup, Wiederherstellung und Überwachung

Ohne getestetes Backup und funktionierenden Ausfall-Alarm gilt das Projekt als **nicht fertig** (Projektauftrag, Phase 5). Diese Seite beschreibt beides. Terminal-Schritte sind mit **«macht Claude/QOM-Technik»** markiert – Tim muss nie ins Terminal.

---

## 1. Backup-Konzept

**Was wird gesichert?** Alles, was der QOM Editor an Daten hält, liegt an genau zwei Orten:

1. die SQLite-Datenbank (`data/qom-cms.db`) – Projekte, Inhalte, Blogbeiträge, Nutzer, Rechte, Audit-Log
2. der Upload-Ordner (`data/uploads/`) – alle Bilder

**Wie?** Ein Infomaniak-Cron (geplante Aufgabe, eingerichtet gemäss [infomaniak-einrichtung.md](infomaniak-einrichtung.md), Schritt 6) ruft **jede Nacht um 03:30** das Backup-Skript auf:

```
node --env-file=.env scripts/backup.mjs
```

Das Skript macht Folgendes:

- Es erstellt eine **datierte ZIP-Datei** (z.B. `qom-backup-2026-08-09.zip`) mit einer konsistenten Kopie der Datenbank (über die SQLite-Backup-Funktion, damit auch bei laufendem Server nichts Halbes gesichert wird) und dem kompletten Upload-Ordner.
- Ablageort ist der Ordner aus der Umgebungsvariable **`BACKUP_DIR`** (Standard: `data/backups` – produktiv bitte einen Ordner **ausserhalb** des Website-Ordners setzen, damit ein versehentliches Löschen des Projektordners nicht auch die Backups trifft).
- Es **löscht Backups, die älter als 14 Tage sind**. Es liegen also immer die letzten 14 Nächte bereit.

**Kontrolle:** Einmal im Monat kurz prüfen (per FTP oder durch Claude/QOM-Technik), dass im Backup-Ordner aktuelle ZIPs liegen und die Dateigrösse plausibel wächst. Ein Backup, das niemand anschaut, ist keines.

**Zusätzliche Sicherheitsstufe:** Infomaniak sichert das Hosting seinerseits; die nächtlichen ZIPs sind aber unser eigenes, schnell zugreifbares Backup mit klarer Aufbewahrung.

---

## 2. Wiederherstellung (Restore)

**Wann?** Datenbank kaputt, versehentlich Projekt gelöscht, Server-Umzug – oder für den Pflicht-Test unten.

**Prozedur (macht Claude/QOM-Technik):**

1. **Passendes Backup wählen:** ZIP mit dem letzten guten Stand aus dem Backup-Ordner (`BACKUP_DIR`) heraussuchen. Bei «versehentlich gelöscht» das Datum **vor** dem Malheur nehmen.
2. **Node.js-Site stoppen** (im Infomaniak-Manager die Site anhalten), damit während der Wiederherstellung niemand schreibt.
3. **Restore-Skript ausführen** – es verlangt zur Sicherheit die ausdrückliche Bestätigung `--ja`:
   ```
   node --env-file=.env scripts/restore.mjs <pfad-zum-backup.zip> --ja
   ```
   Das Skript legt vor dem Überschreiben eine Sicherheitskopie des aktuellen Stands an, ersetzt dann Datenbank und Upload-Ordner durch den Inhalt des ZIPs. Ohne `--ja` zeigt es nur an, was es tun würde.
4. **Node.js-Site wieder starten.**
5. **Prüfen:** Anmelden, Projekte öffnen, Stichproben bei Inhalten und Bildern, ein Blick ins Audit-Log. Erst dann ist der Restore abgeschlossen.

**Wichtig:** Alles, was zwischen dem Backup-Zeitpunkt und dem Restore geändert wurde, ist danach weg (maximal ~24 Stunden). Kunden gegebenenfalls informieren.

### Der einmalige Pflicht-Restore-Test (Phase 5)

Bevor der QOM Editor als «fertig» gilt, wird **einmal real** wiederhergestellt – nicht auf dem Papier:

1. Claude/QOM-Technik nimmt ein **echtes nächtliches Backup-ZIP** (kein extra angefertigtes).
2. Wiederherstellung auf einer **Testumgebung** (z.B. lokal oder ein zweiter Ordner auf dem Server mit eigenem Port) nach der Prozedur oben – so bleibt der Live-Betrieb unberührt.
3. **Tim prüft selbst** (per Klick, siehe [klick-testanleitung.md](klick-testanleitung.md), Phase 5): anmelden, Inhalte, Blogbeiträge und Bilder vollständig vorhanden.
4. Ergebnis mit Datum kurz festhalten (z.B. als Notiz im Projektordner): «Restore-Test bestanden am …».

- [ ] Restore-Test durchgeführt am: ____________ mit Backup vom: ____________

---

## 3. Überwachung (Monitoring) mit n8n

Der QOM Editor hat die Prüfadresse `GET /health`: Antwortet der Server, liefert er `{"status":"ok","zeit":"…"}` und prüft dabei auch gleich die Datenbank. Der bestehende n8n-Server (n8n.renuvia-care.com) ruft diese Adresse **alle 30 Minuten** auf und alarmiert Tim bei Ausfall.

### Der Workflow in n8n, Knoten für Knoten

Neuen Workflow anlegen, Name z.B. **«QOM Editor – Health-Check»**, mit 4 Knoten in dieser Kette:

**Knoten 1: Schedule Trigger** (Zeitauslöser – nicht Webhook: der Check soll von selbst laufen)
- Trigger Interval: «Minutes», Wert: `30`.

**Knoten 2: HTTP Request**
- Methode: `GET`
- URL: `https://editor.quitordinarymarketing.ch/health`
- Timeout: `10000` ms (10 Sekunden)
- **Wichtig – Fehlerverhalten:** In den Knoten-Einstellungen «On Error» auf **«Continue (using error output)»** stellen (bzw. «Continue On Fail» aktivieren). Sonst bricht der Workflow bei einem Ausfall einfach ab, statt den Alarm auszulösen – genau der Fall, den wir erwischen wollen.

**Knoten 3: IF** («Ist etwas faul?»)
- Bedingung (Oder-Verknüpfung, beide Fälle abdecken):
  1. Die Antwort enthält einen Fehler (Ausdruck z.B. `{{ $json.error !== undefined }}`), **oder**
  2. das Feld `status` der Antwort ist **nicht** `ok` (Ausdruck: `{{ $json.status }}`, Operation «not equals», Wert `ok`).
- **true-Ausgang** = Alarmfall, **false-Ausgang** = alles gut (bleibt unverbunden, der Workflow endet dort einfach).

**Knoten 4: Benachrichtigung** (am true-Ausgang des IF)
- Einfachste Variante: **Send Email**-Knoten über das Infomaniak-SMTP (Credentials: `mail.infomaniak.com`, Port 465, SSL, Benutzer `editor@quitordinarymarketing.ch`).
  - An: Tims Adresse
  - Betreff: `ALARM: QOM Editor ist nicht erreichbar`
  - Text: `Der Health-Check von https://editor.quitordinarymarketing.ch/health ist fehlgeschlagen ({{ $now }}). Bitte im Infomaniak-Manager die Node.js-Site prüfen und ggf. neu starten.`
- Damit die Mail sicher auffällt: In Tims Mail-App eine Regel anlegen, die Nachrichten mit Betreff «ALARM: QOM Editor» laut/als wichtig meldet. (Alternativ oder zusätzlich: ein Telegram- oder Pushover-Knoten für echte Push-Nachrichten aufs Handy – gleicher Anschlusspunkt.)
- Workflow **aktivieren** (Schalter «Active» oben rechts).

Optional, gegen Alarm-Spam bei längeren Ausfällen: Vor dem Benachrichtigungs-Knoten die «Fortsetzung nur, wenn der letzte Alarm länger als 2 Stunden her ist»-Logik ergänzen (n8n-Static-Data oder ein zweiter IF mit Zeitstempel-Vergleich). Für den Start reicht die einfache Kette – alle 30 Minuten eine Mail während eines Ausfalls ist verkraftbar und sogar nützlich.

### Alarm-Test (Pflicht, Phase 5)

1. Claude/QOM-Technik stoppt die Node.js-Site im Infomaniak-Manager kurz (oder trägt im HTTP-Request-Knoten testweise eine falsche Adresse ein, z.B. `/healt`).
2. In n8n den Workflow einmal manuell ausführen («Execute workflow») **oder** die nächste 30-Minuten-Runde abwarten.
3. **Tim muss die Alarm-Nachricht wirklich auf seinem Gerät erhalten** – das ist das Abnahmekriterium.
4. Site wieder starten bzw. die richtige Adresse eintragen, Workflow erneut ausführen: Es darf **kein** Alarm mehr kommen.

- [ ] Ausfall-Alarm ausgelöst und von Tim empfangen am: ____________

---

## 4. Kurzreferenz

| Was | Wert |
|-----|------|
| Backup-Zeitpunkt | täglich 03:30 (Infomaniak-Cron) |
| Backup-Befehl | `node --env-file=.env scripts/backup.mjs` |
| Backup-Inhalt | ZIP: SQLite-Datenbank + kompletter Upload-Ordner |
| Aufbewahrung | 14 Tage, ältere ZIPs löscht das Skript selbst |
| Backup-Zielordner | `BACKUP_DIR` aus der `.env` (Standard `data/backups`) |
| Restore-Befehl | `node --env-file=.env scripts/restore.mjs <datei.zip> --ja` |
| Health-Check | `GET https://editor.quitordinarymarketing.ch/health` → `{"status":"ok"}` |
| Prüf-Intervall | alle 30 Minuten (n8n Schedule Trigger) |
| Alarmweg | E-Mail an Tim (optional zusätzlich Telegram/Pushover) |
