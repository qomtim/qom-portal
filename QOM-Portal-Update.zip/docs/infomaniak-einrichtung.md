# Infomaniak einrichten – Schritt für Schritt

So kommt der QOM Editor auf das bestehende Infomaniak-Hosting unter `https://editor.quitordinarymarketing.ch`. Die Klick-Schritte im Infomaniak-Manager machst du (Tim); alle Terminal-Schritte sind mit **«macht Claude/QOM-Technik»** markiert.

*Hinweis: Infomaniak baut seinen Manager gelegentlich um – einzelne Menüpunkte können leicht anders heissen. Die Reihenfolge und die einzutragenden Werte bleiben gleich. Wenn etwas nicht auffindbar ist: Screenshot machen und Claude/QOM-Technik fragen.*

---

## Zuerst: Das musst du bereitstellen (Zugänge und Geheimnisse)

Bitte alles **gesammelt und auf sicherem Weg** (z.B. Passwort-Manager-Freigabe, nicht per unverschlüsselter Mail) an Claude/QOM-Technik übergeben. Trage Passwörter und Tokens **nie selbst in Chats oder Formulare ausserhalb der jeweiligen Anbieter-Seite** ein.

| Was | Wofür | Woher |
|-----|-------|-------|
| **Infomaniak-Zugang** (Login für manager.infomaniak.com, inkl. Zugriff auf das Hosting von quitordinarymarketing.ch) | Subdomain, Node.js-Site, Cron, Postfach einrichten; SSH/FTP-Zugangsdaten liegen dort | hast du bereits |
| **SMTP-Postfach-Passwort** für `editor@quitordinarymarketing.ch` | Damit der QOM Editor Einladungen und Passwort-Reset-Mails verschicken kann | legst du in Schritt 2 an – Passwort dabei notieren |
| **GitHub-Token** (Konto `qomtim`, Berechtigung nur für das Repository `qom-website`, Zweck: `repository_dispatch` auslösen) | Der Deploy-Webhook stösst darüber den Website-Neubau an | github.com → Settings → Developer settings → Fine-grained tokens. **Wichtig: Dieses Token wird monatlich rotiert** – jeden Monat neu erzeugen und Claude/QOM-Technik geben, das alte löschen. Am besten gleich eine monatliche Erinnerung im Kalender anlegen. |

---

## Schritt 1: Subdomain `editor.quitordinarymarketing.ch` anlegen

1. Melde dich auf `manager.infomaniak.com` an.
2. Öffne dein **Webhosting** von quitordinarymarketing.ch (Bereich «Hosting» bzw. «Web + Domains»).
3. Gehe zu **«Meine Websites»** und klicke auf **«Website hinzufügen»** (bzw. «Website installieren»).
4. Wähle als Domain **«Subdomain von quitordinarymarketing.ch»** und tippe `editor` ein → es entsteht `editor.quitordinarymarketing.ch`. Infomaniak legt den nötigen DNS-Eintrag selbst an.
5. Aktiviere das **SSL-Zertifikat** (Let's Encrypt), falls es nicht automatisch dabei ist – die Seite muss über `https://` laufen.

## Schritt 2: Postfach `editor@quitordinarymarketing.ch` anlegen

1. Im Manager: Bereich **«Mail-Service»** von quitordinarymarketing.ch öffnen.
2. **«E-Mail-Adresse hinzufügen»** klicken, Adresse: `editor`.
3. Ein starkes Passwort vergeben (Passwort-Manager!) und notieren – das ist später `SMTP_PASS` in der `.env`.
4. Die Versand-Einstellungen für die `.env` sind bei Infomaniak immer gleich: Server `mail.infomaniak.com`, Port `465`, Verschlüsselung SSL (in der `.env`: `SMTP_SECURE=true`).

## Schritt 3: Die Node.js-Site einrichten

Beim Anlegen der Website in Schritt 1 (oder danach in deren Einstellungen) fragt Infomaniak nach der Art der Website:

1. Wähle als Typ **«Node.js»** (im Hosting ist **eine** Node.js-Site inklusive – die nutzen wir hierfür).
2. **Node-Version:** `22` (oder die neuste angebotene 22er/24er-Version).
3. **Arbeitsverzeichnis / Ordner der Website:** der Ordner, in den das Projekt hochgeladen wird, z.B. `/sites/editor.quitordinarymarketing.ch/qom-editor` (den genauen Pfad bestimmt Claude/QOM-Technik beim Upload in Schritt 4 – wichtig ist nur: **derselbe Ordner**, in dem `package.json` liegt).
4. **Startbefehl:**
   ```
   node --env-file=.env src/server.js
   ```
5. **Port:** Infomaniak fragt, auf welchem Port die Anwendung lauscht («Port-Weiterleitung»). Trage denselben Port ein, der in der `.env` als `PORT` steht (Standard: `3000`). Infomaniak leitet dann `https://editor.quitordinarymarketing.ch` intern auf diesen Port weiter.
6. Speichern. Die Site startet noch nicht sauber, solange das Projekt nicht hochgeladen ist – das ist normal.

## Schritt 4: Projekt hochladen (macht Claude/QOM-Technik)

Das läuft über SSH oder FTP mit den Zugangsdaten aus dem Infomaniak-Manager (Hosting → SSH/FTP). Du musst hier nichts tun. Zur Nachvollziehbarkeit, was passiert:

- Hochgeladen wird der Projektordner **ohne** `node_modules` und **ohne** `data/` (die Pakete werden auf dem Server frisch installiert, damit sie zum Server-System passen).
- Auf dem Server wird im Projektordner `npm install --omit=dev` ausgeführt.
- Der Ordner `data/` (Datenbank + Bilder) wird beim ersten Start automatisch angelegt.
- Danach: erster Admin per `npm run create-admin -- <email> "<Name>" "<Passwort>"` – die Zugangsdaten bekommst du übergeben.

## Schritt 5: `.env` ausfüllen (macht Claude/QOM-Technik – mit deinen Werten)

Auf dem Server wird `.env.example` zu `.env` kopiert und so befüllt:

```
NODE_ENV=production
HOST=127.0.0.1
PORT=3000
BASE_URL=https://editor.quitordinarymarketing.ch
SMTP_HOST=mail.infomaniak.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=editor@quitordinarymarketing.ch
SMTP_PASS=<das Passwort aus Schritt 2>
SMTP_FROM="QOM Editor <editor@quitordinarymarketing.ch>"
```

Dazu kommt bei Bedarf `BACKUP_DIR=` (Zielordner der Backups, siehe [betrieb-backup-monitoring.md](betrieb-backup-monitoring.md)) – idealerweise ein Ordner **ausserhalb** des Website-Ordners.

Das GitHub-Token aus der Vorbereitungs-Tabelle landet **nicht** in dieser `.env`: Es wird im n8n-Workflow (bzw. als GitHub-Secret) hinterlegt, der den Website-Neubau auslöst. Auch das macht Claude/QOM-Technik – du lieferst nur monatlich das frische Token.

## Schritt 6: Nächtliches Backup als geplante Aufgabe (Cron)

1. Im Manager: dein Hosting öffnen → **«Erweiterte Werkzeuge» → «Geplante Aufgaben»** (Cron).
2. **«Aufgabe hinzufügen»** klicken.
3. Einstellungen:
   - **Häufigkeit:** täglich
   - **Uhrzeit:** `03:30`
   - **Auszuführender Befehl:** (den exakten Pfad setzt Claude/QOM-Technik ein)
     ```
     cd <Projektordner> && node --env-file=.env scripts/backup.mjs
     ```
4. Optional: E-Mail-Benachrichtigung **bei Fehlern** aktivieren, Empfänger deine Adresse.
5. Speichern. Was das Backup genau macht (ZIP mit Datenbank + Bildern, 14 Tage Aufbewahrung) steht in [betrieb-backup-monitoring.md](betrieb-backup-monitoring.md).

## Schritt 7: Kontrolle – läuft alles?

1. Öffne `https://editor.quitordinarymarketing.ch` → die Anmeldeseite **«Willkommen»** erscheint (mit Schloss-Symbol in der Adressleiste = SSL ok).
2. Öffne `https://editor.quitordinarymarketing.ch/health` → es erscheint eine kurze Textzeile mit `"status":"ok"`. Diese Adresse nutzt später auch die Überwachung.
3. Melde dich an und schicke dir testweise unter «Passwort vergessen» eine Mail – kommt sie an, stimmt die SMTP-Einrichtung.
4. Danach die Klick-Tests aus [klick-testanleitung.md](klick-testanleitung.md) durchgehen.

---

## Monatliche Routine (wichtig)

- **GitHub-Token rotieren:** neues Fine-grained-Token erzeugen, an Claude/QOM-Technik übergeben, altes Token auf GitHub löschen. Ohne gültiges Token werden Veröffentlichungen zwar gespeichert, aber die Website baut nicht mehr automatisch neu.
- Kurz kontrollieren, dass im Backup-Ordner aktuelle ZIP-Dateien der letzten 14 Tage liegen (zeigt dir Claude/QOM-Technik oder du siehst es im FTP-Ordner).
