// Legt Demo-Daten zum Ausprobieren an: das Projekt "QOM Website" mit der
// Standardvorlage und Beispielinhalten. Kann gefahrlos mehrfach laufen.
// NUR für die Entwicklung – im Produktionsbetrieb gesperrt.
if (process.env.NODE_ENV === 'production') {
  console.error('seed-demo ist im Produktionsmodus gesperrt.');
  process.exit(1);
}
const { db } = await import('../src/db.js');
const { neuesToken } = await import('../src/security.js');
const { vorlageAnwenden } = await import('../src/routes/admin.js');

let projekt = db.prepare(`SELECT * FROM projects WHERE slug = 'qom-website'`).get();
if (!projekt) {
  db.prepare(
    `INSERT INTO projects (slug, name, website_url, api_token, preview_token, blog_aktiv)
     VALUES ('qom-website', 'QOM Website', 'https://www.quitordinarymarketing.ch', ?, ?, 1)`
  ).run(neuesToken(), neuesToken());
  projekt = db.prepare(`SELECT * FROM projects WHERE slug = 'qom-website'`).get();
  vorlageAnwenden(projekt.id);
  console.log('Projekt "QOM Website" angelegt.');
} else {
  console.log('Projekt "QOM Website" existiert schon.');
}

const beispielWerte = {
  startseite_titel: 'Quit Ordinary Marketing',
  startseite_untertitel: 'Wir bauen Websites, die für lokale KMU wirklich arbeiten.',
  startseite_knopf_text: 'Projekt anfragen',
  einleitung_titel: 'Marketing, das ankommt',
  einleitung_text: 'Vier Partner aus Bösingen – eine Mission: Schluss mit gewöhnlichem Marketing.',
  kontakt_email: 'hallo@quitordinarymarketing.ch',
  kontakt_telefon: '+41 79 000 00 00',
  kontakt_adresse: 'QOM GmbH\nDorfstrasse 1\n3178 Bösingen',
  footer_text: '© QOM – Quit Ordinary Marketing',
};
const setzen = db.prepare(
  `UPDATE fields SET value_draft = ?, value_published = ?
    WHERE project_id = ? AND key = ? AND value_draft = ''`
);
for (const [key, wert] of Object.entries(beispielWerte)) {
  setzen.run(wert, wert, projekt.id, key);
}

const team = db.prepare(
  `SELECT * FROM collections WHERE project_id = ? AND key = 'team'`
).get(projekt.id);
if (team) {
  const anzahl = db.prepare(
    `SELECT COUNT(*) AS n FROM collection_items WHERE collection_id = ?`
  ).get(team.id).n;
  if (anzahl === 0) {
    const einfuegen = db.prepare(
      `INSERT INTO collection_items (collection_id, data_draft, data_published, sort) VALUES (?, ?, ?, ?)`
    );
    const mitglieder = [
      { name: 'Tim', funktion: 'Partner', beschreibung: 'Kümmert sich um Kunden und Projekte.' },
      { name: 'Partner 2', funktion: 'Partner', beschreibung: 'Design und Konzept.' },
    ];
    mitglieder.forEach((mitglied, index) => {
      const json = JSON.stringify(mitglied);
      einfuegen.run(team.id, json, json, index + 1);
    });
    console.log('Team-Beispiele angelegt.');
  }
}

console.log('Demo-Daten bereit.');
