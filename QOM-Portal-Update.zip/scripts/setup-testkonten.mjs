// Legt Testkonten und Bereiche für die lokale Demo an (mehrfach ausführbar).
// NUR für die Entwicklung – im Produktionsbetrieb gesperrt.
if (process.env.NODE_ENV === 'production') {
  console.error('setup-testkonten ist im Produktionsmodus gesperrt. Nutze scripts/create-admin.mjs.');
  process.exit(1);
}
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');

// Bereiche für bestehende Projekte nachtragen (matchen die Sammlungen + Blog)
const BEREICHE = [
  ['team', 'Team-Bereich'], ['referenzen', 'Referenzen'], ['kundenstimmen', 'Kundenstimmen'],
  ['kennzahlen', 'Kennzahlen'], ['faq', 'Häufige Fragen'], ['blog', 'Blog'],
];
for (const projekt of db.prepare(`SELECT id FROM projects`).all()) {
  const vorhanden = db.prepare(`SELECT COUNT(*) AS n FROM sections WHERE project_id = ?`).get(projekt.id).n;
  if (vorhanden === 0) {
    const einfuegen = db.prepare(`INSERT OR IGNORE INTO sections (project_id, key, label, sort) VALUES (?, ?, ?, ?)`);
    BEREICHE.forEach(([key, label], i) => einfuegen.run(projekt.id, key, label, i + 1));
  }
}

async function kontoAnlegen(email, name, rolle, passwort, projektSlugs = []) {
  let nutzer = db.prepare(`SELECT * FROM users WHERE email = ?`).get(email);
  const hash = await passwortHashen(passwort);
  if (nutzer) {
    db.prepare(`UPDATE users SET pw_hash = ?, name = ?, role = ?, is_admin = ? WHERE id = ?`)
      .run(hash, name, rolle, rolle === 'owner' ? 1 : 0, nutzer.id);
  } else {
    const r = db.prepare(`INSERT INTO users (email, pw_hash, name, role, is_admin) VALUES (?, ?, ?, ?, ?)`)
      .run(email, hash, name, rolle, rolle === 'owner' ? 1 : 0);
    nutzer = { id: r.lastInsertRowid };
  }
  if (rolle !== 'owner') {
    for (const slug of projektSlugs) {
      const p = db.prepare(`SELECT id FROM projects WHERE slug = ?`).get(slug);
      if (p) db.prepare(`INSERT OR IGNORE INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`).run(nutzer.id, p.id);
    }
  }
  console.log(`${rolle.padEnd(9)} ${email}  (Passwort: ${passwort})`);
}

// Ads-Demoprojekt (nur Meta-Ads, kein Website-Editor) + Beispiel-Videos
import { neuesToken } from '../src/security.js';
let ads = db.prepare(`SELECT * FROM projects WHERE slug='ads-demo'`).get();
if (!ads) {
  db.prepare(`INSERT INTO projects (slug,name,api_token,preview_token,metrics_token,projekt_typ) VALUES ('ads-demo','Glacé Boutique (Ads)',?,?,?,'ads')`)
    .run(neuesToken(), neuesToken(), neuesToken());
  ads = db.prepare(`SELECT * FROM projects WHERE slug='ads-demo'`).get();
  db.prepare(`INSERT INTO ad_videos (project_id,titel,drive_url,notiz,sort) VALUES (?,?,?,?,1)`)
    .run(ads.id, 'Sommer-Hook Variante A', 'https://drive.google.com/file/d/BEISPIEL/view', 'Bitte auf die Musik am Anfang achten');
  db.prepare(`INSERT INTO ad_videos (project_id,titel,drive_url,sort) VALUES (?,?,?,2)`)
    .run(ads.id, 'UGC Testimonial', 'https://drive.google.com/file/d/BEISPIEL2/view');
  console.log(`Ads-Demoprojekt angelegt. Kennzahlen-Ingest: /api/v1/projects/ads-demo/metrics?token=${ads.metrics_token}`);
}

// Geschäftsführer (Tim) + Test-Owner
await kontoAnlegen('waebert.business@gmail.com', 'Tim (QOM)', 'owner', 'qom-test-2026');
await kontoAnlegen('tim@qom.ch', 'Tim', 'owner', 'test-passwort-123');
// Mitarbeiter, dem die QOM-Website zugewiesen ist
await kontoAnlegen('mitarbeiter@qom.ch', 'Mitarbeiter Demo', 'staff', 'mitarbeiter-2026', ['qom-website']);
// Kunde, der nur "testkunde" bearbeiten darf
await kontoAnlegen('kunde@testkunde.ch', 'Kunde Test', 'customer', 'kunden-passwort-99', ['testkunde']);
// Ads-Kunde, der nur das Ads-Portal von "ads-demo" sieht
await kontoAnlegen('glace@kunde.ch', 'Glacé Kunde', 'customer', 'glace-portal-88', ['ads-demo']);

console.log('\nTestkonten & Bereiche bereit.');
