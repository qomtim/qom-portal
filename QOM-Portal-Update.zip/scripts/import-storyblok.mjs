// Einmalige Migration von Storyblok in den QOM Editor (Primer §6).
//
// Aufruf:
//   STORYBLOK_TOKEN=<token> ZIEL_PROJEKT=<projekt-slug> node scripts/import-storyblok.mjs
//
// Umgebungsvariablen:
//   STORYBLOK_TOKEN  Storyblok-Zugriffstoken (CDN-API, "public" reicht) – PFLICHT
//   ZIEL_PROJEKT     Projekt-Slug im QOM Editor (Standard: qom-website)
//
// Was das Skript macht:
//   1. Holt die Stories "site", "ueber-uns", "impressum", "datenschutz" von der
//      Storyblok-CDN-API (version=published).
//   2. Wandelt den Inhalt generisch in Felder und Sammlungen des QOM Editors um
//      und lädt alle Bilder in die eigene Upload-Ablage herunter.
//   3. Schreibt die Werte in value_draft UND value_published (bzw. data_draft und
//      data_published), damit der importierte Stand sofort "veröffentlicht" ist.
//
// ---------------------------------------------------------------------------
// GETROFFENE ANNAHMEN (das exakte Storyblok-Schema liegt hier nicht vor,
// darum ist das Mapping bewusst generisch):
//
// - Interne Storyblok-Schlüssel (_uid, _editable, component) werden übersprungen.
// - Skalare String-Werte werden zu Feldern:
//     * kurz (einzeilig, bis 120 Zeichen)            → Typ "text"
//     * lang oder mehrzeilig                          → Typ "textarea"
//     * Bild-URL (a.storyblok.com / framerusercontent.com) → Bild wird
//       heruntergeladen, Feldwert = lokaler /uploads/…-Pfad, Typ "image"
// - Zahlen und Wahrheitswerte werden als Text übernommen.
// - Storyblok-Asset-Objekte (Objekt mit "filename" auf a.storyblok.com) werden
//   wie Bild-URLs behandelt: herunterladen, Typ "image".
// - Storyblok-Link-Objekte (Objekt mit "linktype" oder "cached_url") werden zum
//   Text-Feld mit der Ziel-Adresse (cached_url bzw. url).
// - Storyblok-Richtext (Objekt mit type:"doc" und content-Array) wird zu reinem
//   Text zusammengefasst (Absätze mit Leerzeile getrennt) → Typ "textarea".
//   Formatierungen (fett usw.) gehen dabei verloren – für die einmalige
//   Migration ist das akzeptiert, Feinschliff macht QOM danach im Editor.
// - Verschachtelte Objekte werden flach gemacht, Schlüssel mit Unterstrich
//   verbunden: hero.title → hero_title.
// - Arrays von Objekten werden zu Sammlungen (collections). Das Schema wird aus
//   den Schlüsseln des ERSTEN Elements abgeleitet; die Einträge werden pro
//   Element flach gemacht (tiefere Arrays innerhalb eines Eintrags werden
//   übersprungen). Beim erneuten Import werden die Einträge der Sammlung
//   KOMPLETT ersetzt (Schema wird aktualisiert), damit nichts doppelt entsteht.
// - Arrays von Skalaren werden zu einem "textarea"-Feld (ein Wert pro Zeile).
// - Feld-Schlüssel der Story "site" bekommen KEINEN Präfix (das ist die
//   Haupt-Story). Die Seiten-Stories bekommen ihren Slug als Präfix, damit es
//   keine Kollisionen gibt: ueber-uns → ueber_uns_<key> usw.
// - Idempotenz: Existiert ein Feld mit gleichem key bereits, werden NUR die
//   Werte (value_draft, value_published) aktualisiert – Beschriftung, Gruppe,
//   Typ und der Schalter "Kunde darf bearbeiten" bleiben unangetastet.
//   Bild-Downloads sind ebenfalls idempotent: der Dateiname wird aus einem
//   Hash der Quell-URL gebildet; existiert die Datei schon, wird nicht erneut
//   heruntergeladen.
// ---------------------------------------------------------------------------

import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { db, audit } from '../src/db.js';
import { config } from '../src/config.js';

// ----------------------------- Vorbereitung --------------------------------

const token = process.env.STORYBLOK_TOKEN || '';
const zielProjektSlug = process.env.ZIEL_PROJEKT || 'qom-website';

if (!token) {
  console.error('FEHLER: Die Umgebungsvariable STORYBLOK_TOKEN fehlt.');
  console.error('');
  console.error('Aufruf:');
  console.error('  STORYBLOK_TOKEN=<storyblok-token> ZIEL_PROJEKT=<projekt-slug> node scripts/import-storyblok.mjs');
  console.error('');
  console.error('  STORYBLOK_TOKEN  Zugriffstoken aus Storyblok (Einstellungen → Access Tokens, "public")');
  console.error('  ZIEL_PROJEKT     Projekt-Slug im QOM Editor (Standard: qom-website)');
  process.exit(1);
}

const projekt = db.prepare(`SELECT * FROM projects WHERE slug = ?`).get(zielProjektSlug);
if (!projekt) {
  console.error(`FEHLER: Im QOM Editor gibt es kein Projekt mit dem Slug "${zielProjektSlug}".`);
  console.error('Zuerst das Projekt im Adminbereich anlegen (oder ZIEL_PROJEKT anpassen).');
  process.exit(1);
}

// Diese Stories werden importiert (siehe Primer §1: site + Seiten-Stories).
// Pro Story: Storyblok-Slug, Schlüssel-Präfix im CMS, Gruppen-Beschriftung.
const STORIES = [
  { slug: 'site', praefix: '', gruppe: 'Import Storyblok – Website' },
  { slug: 'ueber-uns', praefix: 'ueber_uns_', gruppe: 'Import Storyblok – Über uns' },
  { slug: 'impressum', praefix: 'impressum_', gruppe: 'Import Storyblok – Impressum' },
  { slug: 'datenschutz', praefix: 'datenschutz_', gruppe: 'Import Storyblok – Datenschutz' },
];

const uploadsOrdner = path.join(config.uploadsVerzeichnis, projekt.slug);
fs.mkdirSync(uploadsOrdner, { recursive: true });

// ------------------------------ Hilfsfunktionen ----------------------------

// Interne Storyblok-Schlüssel, die nie importiert werden
const IGNORIERTE_SCHLUESSEL = new Set(['_uid', '_editable', 'component']);

function istBildUrl(wert) {
  return typeof wert === 'string'
    && /^(https?:)?\/\//.test(wert)
    && /(a\.storyblok\.com|framerusercontent\.com)/.test(wert);
}

function istAssetObjekt(wert) {
  return wert && typeof wert === 'object' && !Array.isArray(wert)
    && typeof wert.filename === 'string' && wert.filename.includes('a.storyblok.com');
}

function istLinkObjekt(wert) {
  return wert && typeof wert === 'object' && !Array.isArray(wert)
    && ('linktype' in wert || 'cached_url' in wert);
}

function istRichtext(wert) {
  return wert && typeof wert === 'object' && !Array.isArray(wert)
    && wert.type === 'doc' && Array.isArray(wert.content);
}

// Richtext → reiner Text: alle "text"-Knoten einsammeln, Absätze mit
// Leerzeile trennen. (Annahme: Formatierung darf verloren gehen.)
function richtextZuText(knoten) {
  if (!knoten || typeof knoten !== 'object') return '';
  if (knoten.type === 'text') return knoten.text || '';
  const kinder = Array.isArray(knoten.content) ? knoten.content : [];
  const teile = kinder.map(richtextZuText).filter(Boolean);
  // Blöcke (Absätze, Überschriften, Listenpunkte) mit Leerzeile trennen,
  // alles andere direkt aneinanderhängen
  const istBlockEbene = knoten.type === 'doc';
  return teile.join(istBlockEbene ? '\n\n' : '');
}

// Kurzer Text → "text", langer/mehrzeiliger Text → "textarea"
function textTyp(wert) {
  return wert.includes('\n') || wert.length > 120 ? 'textarea' : 'text';
}

// "hero_title" → "Hero title" (lesbare Beschriftung für den Editor)
function beschriftungAusKey(key) {
  const roh = key.replace(/_/g, ' ').trim();
  return roh.charAt(0).toUpperCase() + roh.slice(1);
}

// Bild herunterladen → /uploads/<projekt>/sb-<hash>.<endung>
// Der Dateiname ist ein Hash der Quell-URL: gleicher Ursprung ⇒ gleiche Datei,
// darum lädt ein zweiter Lauf nichts doppelt herunter.
async function bildHerunterladen(url) {
  let voll = String(url);
  if (voll.startsWith('//')) voll = 'https:' + voll; // Storyblok liefert teils protokoll-relative URLs
  const hash = crypto.createHash('sha1').update(voll).digest('hex').slice(0, 16);
  const endungTreffer = /\.(jpe?g|png|webp|gif|svg|avif)(\?|$)/i.exec(voll);
  const endung = endungTreffer ? endungTreffer[1].toLowerCase().replace('jpeg', 'jpg') : 'jpg';
  const dateiName = `sb-${hash}.${endung}`;
  const zielPfad = path.join(uploadsOrdner, dateiName);
  const lokalerPfad = `/uploads/${projekt.slug}/${dateiName}`;

  if (fs.existsSync(zielPfad)) {
    return lokalerPfad; // schon vorhanden – nicht erneut laden (idempotent)
  }
  const antwort = await fetch(voll);
  if (!antwort.ok) {
    throw new Error(`Bild-Download fehlgeschlagen (${antwort.status}): ${voll}`);
  }
  const puffer = Buffer.from(await antwort.arrayBuffer());
  fs.writeFileSync(zielPfad, puffer);
  console.log(`    Bild heruntergeladen: ${dateiName} (${(puffer.length / 1024).toFixed(0)} KB)`);
  return lokalerPfad;
}

// Wandelt EINEN Wert in { wert, typ } um (oder null, wenn er nicht als
// einfaches Feld abbildbar ist). Lädt Bilder bei Bedarf herunter.
async function wertUmwandeln(wert) {
  if (typeof wert === 'string') {
    const getrimmt = wert.trim();
    if (getrimmt === '') return { wert: '', typ: 'text' };
    if (istBildUrl(getrimmt)) {
      return { wert: await bildHerunterladen(getrimmt), typ: 'image' };
    }
    return { wert: getrimmt, typ: textTyp(getrimmt) };
  }
  if (typeof wert === 'number' || typeof wert === 'boolean') {
    return { wert: String(wert), typ: 'text' };
  }
  if (istAssetObjekt(wert)) {
    if (!wert.filename) return null; // leeres Asset-Feld → überspringen
    return { wert: await bildHerunterladen(wert.filename), typ: 'image' };
  }
  if (istRichtext(wert)) {
    return { wert: richtextZuText(wert), typ: 'textarea' };
  }
  if (istLinkObjekt(wert)) {
    const ziel = wert.cached_url || wert.url || '';
    return { wert: String(ziel), typ: 'text' };
  }
  return null; // verschachtelte Objekte/Arrays behandelt der Aufrufer selbst
}

// ---------------------- Felder und Sammlungen schreiben --------------------

const feldSuchen = db.prepare(`SELECT id FROM fields WHERE project_id = ? AND key = ?`);
const feldAktualisieren = db.prepare(`UPDATE fields SET value_draft = ?, value_published = ? WHERE id = ?`);
const feldEinfuegen = db.prepare(
  `INSERT INTO fields (project_id, key, group_label, field_label, type, value_draft, value_published, sort)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
);
const naechsteSortNummer = db.prepare(`SELECT COALESCE(MAX(sort), 0) + 1 AS n FROM fields WHERE project_id = ?`);

let felderNeu = 0;
let felderAktualisiert = 0;

// Feld idempotent schreiben: existiert der key schon, nur die Werte setzen.
function feldSchreiben(key, gruppe, typ, wert) {
  const vorhanden = feldSuchen.get(projekt.id, key);
  if (vorhanden) {
    feldAktualisieren.run(wert, wert, vorhanden.id);
    felderAktualisiert += 1;
  } else {
    const sort = naechsteSortNummer.get(projekt.id).n;
    feldEinfuegen.run(projekt.id, key, gruppe, beschriftungAusKey(key), typ, wert, wert, sort);
    felderNeu += 1;
  }
}

const sammlungSuchen = db.prepare(`SELECT id FROM collections WHERE project_id = ? AND key = ?`);
const sammlungEinfuegen = db.prepare(
  `INSERT INTO collections (project_id, key, label, item_schema, sort) VALUES (?, ?, ?, ?, ?)`
);
const sammlungSchemaSetzen = db.prepare(`UPDATE collections SET item_schema = ? WHERE id = ?`);
const sammlungItemsLoeschen = db.prepare(`DELETE FROM collection_items WHERE collection_id = ?`);
const itemEinfuegen = db.prepare(
  `INSERT INTO collection_items (collection_id, data_draft, data_published, sort) VALUES (?, ?, ?, ?)`
);
const naechsteSammlungSort = db.prepare(`SELECT COALESCE(MAX(sort), 0) + 1 AS n FROM collections WHERE project_id = ?`);

let sammlungenGeschrieben = 0;

// Ein Array von Objekten → Sammlung. Schema aus dem ersten Element ableiten,
// jedes Element flach machen. Bestehende Einträge werden ersetzt (idempotent).
async function sammlungSchreiben(key, beschriftung, elemente) {
  // 1) Jedes Element flach in { key: wert }-Paare umwandeln (Bilder inklusive)
  const eintraege = [];
  const typen = new Map(); // key → Feldtyp (aus dem ersten Vorkommen)

  for (const element of elemente) {
    const flach = {};
    await elementFlachMachen(element, '', flach, typen);
    eintraege.push(flach);
  }

  // 2) Schema aus den Schlüsseln des ERSTEN Elements ableiten (Annahme:
  //    alle Elemente sind gleich aufgebaut)
  const schema = Object.keys(eintraege[0] || {}).map((spaltenKey) => ({
    key: spaltenKey,
    label: beschriftungAusKey(spaltenKey),
    type: typen.get(spaltenKey) || 'text',
  }));
  if (schema.length === 0) {
    console.log(`    Sammlung "${key}" übersprungen (keine verwertbaren Spalten).`);
    return;
  }

  // 3) Sammlung anlegen oder Schema aktualisieren, Einträge komplett ersetzen
  let sammlung = sammlungSuchen.get(projekt.id, key);
  if (!sammlung) {
    const sort = naechsteSammlungSort.get(projekt.id).n;
    sammlungEinfuegen.run(projekt.id, key, beschriftung, JSON.stringify(schema), sort);
    sammlung = sammlungSuchen.get(projekt.id, key);
  } else {
    sammlungSchemaSetzen.run(JSON.stringify(schema), sammlung.id);
  }
  sammlungItemsLoeschen.run(sammlung.id);
  eintraege.forEach((eintrag, index) => {
    const json = JSON.stringify(eintrag);
    itemEinfuegen.run(sammlung.id, json, json, index + 1);
  });
  console.log(`    Sammlung "${key}": ${eintraege.length} Eintrag/Einträge, ${schema.length} Spalte(n).`);
  sammlungenGeschrieben += 1;
}

// Ein Element einer Sammlung flach machen. Verschachtelte Objekte bekommen
// einen Präfix (hero.title → hero_title); Arrays INNERHALB eines Eintrags
// werden übersprungen (Annahme: zu tief verschachtelt für den Editor).
async function elementFlachMachen(objekt, praefix, ziel, typen) {
  if (!objekt || typeof objekt !== 'object' || Array.isArray(objekt)) return;
  for (const [key, wert] of Object.entries(objekt)) {
    if (IGNORIERTE_SCHLUESSEL.has(key)) continue;
    const vollerKey = praefix ? `${praefix}${key}` : key;
    const einfach = await wertUmwandeln(wert);
    if (einfach) {
      ziel[vollerKey] = einfach.wert;
      if (!typen.has(vollerKey)) typen.set(vollerKey, einfach.typ);
    } else if (wert && typeof wert === 'object' && !Array.isArray(wert)) {
      await elementFlachMachen(wert, `${vollerKey}_`, ziel, typen);
    }
    // Arrays innerhalb eines Eintrags: bewusst übersprungen (siehe Annahmen)
  }
}

// ------------------------- Story-Inhalt durchlaufen ------------------------

// Läuft rekursiv durch das content-Objekt einer Story und schreibt Felder
// bzw. Sammlungen. Verschachtelte Objekte werden mit Präfix flach gemacht.
async function inhaltVerarbeiten(objekt, praefix, gruppe) {
  for (const [key, wert] of Object.entries(objekt)) {
    if (IGNORIERTE_SCHLUESSEL.has(key)) continue;
    const vollerKey = praefix ? `${praefix}${key}` : key;

    const einfach = await wertUmwandeln(wert);
    if (einfach) {
      feldSchreiben(vollerKey, gruppe, einfach.typ, einfach.wert);
      continue;
    }

    if (Array.isArray(wert)) {
      if (wert.length === 0) continue; // leere Arrays: nichts zu importieren
      if (wert.every((element) => element && typeof element === 'object' && !Array.isArray(element))) {
        // Array von Objekten → Sammlung
        await sammlungSchreiben(vollerKey, beschriftungAusKey(vollerKey), wert);
      } else {
        // Array von Skalaren → ein textarea-Feld, ein Wert pro Zeile
        const zeilen = wert.filter((element) => typeof element !== 'object').map(String);
        if (zeilen.length > 0) feldSchreiben(vollerKey, gruppe, 'textarea', zeilen.join('\n'));
      }
      continue;
    }

    if (wert && typeof wert === 'object') {
      // Verschachteltes Objekt → mit Präfix flach machen (hero.title → hero_title)
      await inhaltVerarbeiten(wert, `${vollerKey}_`, gruppe);
    }
    // null/undefined: überspringen
  }
}

// --------------------------------- Ablauf ----------------------------------

async function storyHolen(slug) {
  const url = `https://api.storyblok.com/v2/cdn/stories/${encodeURIComponent(slug)}?token=${encodeURIComponent(token)}&version=published`;
  const antwort = await fetch(url);
  if (antwort.status === 404) return null;
  if (!antwort.ok) {
    throw new Error(`Storyblok-Antwort ${antwort.status} für Story "${slug}" – Token korrekt?`);
  }
  const daten = await antwort.json();
  return daten?.story ?? null;
}

try {
  console.log('QOM Editor – Import aus Storyblok');
  console.log(`  Ziel-Projekt: ${projekt.name} (${projekt.slug})`);
  console.log(`  Bild-Ablage:  ${uploadsOrdner}`);
  console.log('');

  let importierteStories = 0;
  for (const eintrag of STORIES) {
    console.log(`  Story "${eintrag.slug}" wird geholt …`);
    const story = await storyHolen(eintrag.slug);
    if (!story || !story.content) {
      console.log(`    Übersprungen: Story "${eintrag.slug}" existiert in Storyblok nicht (404).`);
      continue;
    }
    await inhaltVerarbeiten(story.content, eintrag.praefix, eintrag.gruppe);
    importierteStories += 1;
  }

  audit(null, projekt.id, 'storyblok_import',
    `${importierteStories} Stories, ${felderNeu} Felder neu, ${felderAktualisiert} aktualisiert, ${sammlungenGeschrieben} Sammlungen`);

  console.log('');
  console.log('Import abgeschlossen:');
  console.log(`  Stories importiert:   ${importierteStories} von ${STORIES.length}`);
  console.log(`  Felder neu angelegt:  ${felderNeu}`);
  console.log(`  Felder aktualisiert:  ${felderAktualisiert}`);
  console.log(`  Sammlungen:           ${sammlungenGeschrieben}`);
  console.log('');
  console.log('Hinweis: Die Werte stehen in Entwurf UND veröffentlichtem Stand.');
  console.log('Bitte im QOM Editor kontrollieren; Storyblok erst abklemmen, wenn der');
  console.log('Parallelbetrieb verifiziert ist (Primer §6).');
} catch (fehler) {
  console.error('FEHLER beim Import:', fehler?.message || fehler);
  process.exitCode = 1;
} finally {
  db.close();
}
