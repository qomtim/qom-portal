// Produktions-Bereitschaftscheck: prüft, ob eine Installation startklar für
// echte Kunden ist. Aufruf auf dem Server:  node scripts/pruefe-produktion.mjs
// Gibt eine Checkliste mit ✓/✗ aus und endet mit Code != 0, wenn ein Blocker offen ist.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from '../src/config.js';
import { db } from '../src/db.js';

const wurzel = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let blocker = 0;
let warnungen = 0;

function ok(text) { console.log(`  ✓ ${text}`); }
function fehler(text) { console.log(`  ✗ ${text}`); blocker++; }
function warnung(text) { console.log(`  ! ${text}`); warnungen++; }

console.log('\nQOM Editor – Produktions-Bereitschaftscheck\n');

// 1) Produktionsmodus
if (config.istProduktion) ok('NODE_ENV=production');
else warnung('NODE_ENV ist NICHT "production" – im echten Betrieb setzen (Cookies werden sonst nicht "secure").');

// 2) Datenbank nicht in einem Cloud-Sync-Ordner
if (/CloudStorage|Google ?Drive|Dropbox|OneDrive|com~apple~CloudDocs|iCloud/i.test(config.dbPfad)) {
  fehler(`Datenbank liegt in einem Cloud-Sync-Ordner: ${config.dbPfad}`);
} else {
  ok(`Datenbank-Ort ist ok (${config.dbPfad})`);
}

// 3) Basis-URL auf HTTPS
if (/^https:\/\//i.test(config.baseUrl)) ok(`BASE_URL ist HTTPS (${config.baseUrl})`);
else warnung(`BASE_URL ist nicht HTTPS (${config.baseUrl}) – für echten Betrieb HTTPS verwenden.`);

// 4) SMTP konfiguriert (fuer Einladungen / Passwort-Reset / Video-Meldungen)
if (config.smtp.host && config.smtp.user) ok('SMTP ist konfiguriert (E-Mails können versendet werden)');
else warnung('SMTP ist NICHT konfiguriert – Einladungen und Passwort-Reset gehen nicht per E-Mail.');

// 5) TRUST_PROXY bewusst gesetzt
if (process.env.TRUST_PROXY == null || process.env.TRUST_PROXY === '') {
  warnung('TRUST_PROXY nicht gesetzt – hinter dem Infomaniak-Webserver meist "1" setzen, damit der Login-Schutz die echte IP sieht.');
} else {
  ok(`TRUST_PROXY gesetzt (${process.env.TRUST_PROXY})`);
}

// 6) Mindestens ein Geschaeftsfuehrer
const anzahlOwner = db.prepare(`SELECT COUNT(*) AS n FROM users WHERE role = 'owner'`).get().n;
if (anzahlOwner >= 1) ok(`Geschäftsführer-Konto vorhanden (${anzahlOwner})`);
else fehler('Kein Geschäftsführer-Konto – mit "npm run create-admin" anlegen.');

// 7) Keine bekannten Test-/Demo-Konten
const testEmails = ['tim@qom.ch', 'kunde@testkunde.ch', 'mitarbeiter@qom.ch', 'glace@kunde.ch'];
const gefundenKonten = testEmails.filter((e) => db.prepare(`SELECT 1 FROM users WHERE email = ?`).get(e));
if (gefundenKonten.length === 0) ok('Keine Test-/Demo-Konten in der Datenbank');
else fehler(`Test-/Demo-Konten noch vorhanden: ${gefundenKonten.join(', ')} – löschen!`);

// 8) Keine Demo-Projekte
const testProjekte = ['testkunde', 'ads-demo', 'qom-website'].filter((s) => db.prepare(`SELECT 1 FROM projects WHERE slug = ?`).get(s));
if (testProjekte.length === 0) ok('Keine Demo-Projekte in der Datenbank');
else warnung(`Demo-Projekte noch vorhanden: ${testProjekte.join(', ')} – prüfen, ob echt oder Demo.`);

// 9) Jedes Projekt hat eigene Tokens
const schwacheTokens = db.prepare(`SELECT slug FROM projects WHERE length(api_token) < 20 OR length(metrics_token) < 20 OR api_token = preview_token`).all();
if (schwacheTokens.length === 0) ok('Alle Projekte haben eigene, ausreichend lange Tokens');
else fehler(`Projekte mit schwachen/fehlenden Tokens: ${schwacheTokens.map((p) => p.slug).join(', ')}`);

// 10) .env vorhanden
if (fs.existsSync(path.join(wurzel, '.env'))) ok('.env-Datei vorhanden');
else warnung('.env-Datei fehlt – aus .env.example erstellen und ausfüllen.');

// 11) Backup-Ordner beschreibbar
const backupDir = process.env.BACKUP_DIR || path.join(wurzel, 'backups');
try { fs.mkdirSync(backupDir, { recursive: true }); fs.accessSync(backupDir, fs.constants.W_OK); ok(`Backup-Ordner beschreibbar (${backupDir})`); }
catch { warnung(`Backup-Ordner nicht beschreibbar (${backupDir}).`); }

console.log('');
if (blocker > 0) {
  console.log(`Ergebnis: ${blocker} Blocker offen, ${warnungen} Warnung(en). NOCH NICHT startklar.\n`);
  process.exit(1);
} else {
  console.log(`Ergebnis: keine Blocker, ${warnungen} Warnung(en). Startklar – Warnungen prüfen.\n`);
  process.exit(0);
}
