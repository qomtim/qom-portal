// Stellt ein Backup wieder her, das mit scripts/backup.mjs erstellt wurde.
//
// Aufruf:
//   node scripts/restore.mjs <backup-datei>        → Probelauf: zeigt nur an, was passieren würde
//   node scripts/restore.mjs <backup-datei> --ja   → stellt wirklich wieder her
//
// Ablauf bei --ja:
//   1. Backup-Archiv (.zip oder .tar.gz) in einen Temp-Ordner entpacken
//   2. Sicherheitskopie des AKTUELLEN Stands anlegen (Datenbank + Uploads),
//      damit nichts unwiederbringlich verloren geht
//   3. Datenbank-Datei ersetzen (inklusive Entfernen alter -wal/-shm-Dateien,
//      die sonst nicht mehr zur neuen Datenbank passen würden)
//   4. Uploads-Ordner ersetzen
//
// WICHTIG: Der Server muss vorher gestoppt sein! Ein laufender Server hält die
// Datenbank offen und würde die wiederhergestellte Datei sofort überschreiben
// oder beschädigen.
//
// Dieses Skript importiert bewusst NUR die Konfiguration (../src/config.js),
// NICHT ../src/db.js – denn db.js würde die Datenbank öffnen, während wir sie
// gerade ersetzen wollen.

import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { config } from '../src/config.js';

const projektWurzel = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const backupOrdner = process.env.BACKUP_DIR || path.join(projektWurzel, 'backups');

function zeitstempel(datum = new Date()) {
  const z2 = (n) => String(n).padStart(2, '0');
  return `${datum.getFullYear()}-${z2(datum.getMonth() + 1)}-${z2(datum.getDate())}-${z2(datum.getHours())}${z2(datum.getMinutes())}`;
}

function mb(bytes) {
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Sucht rekursiv im entpackten Ordner nach der Datenbank-Datei und dem
// Uploads-Ordner – so funktioniert die Wiederherstellung auch, wenn das
// Archiv einen zusätzlichen Unterordner enthält.
function imBaumSuchen(wurzel) {
  let dbDatei = null;
  let uploadsOrdner = null;
  const stapel = [wurzel];
  while (stapel.length > 0) {
    const ordner = stapel.pop();
    for (const eintrag of fs.readdirSync(ordner, { withFileTypes: true })) {
      const voll = path.join(ordner, eintrag.name);
      if (eintrag.isDirectory()) {
        if (eintrag.name === 'uploads' && !uploadsOrdner) uploadsOrdner = voll;
        else stapel.push(voll);
      } else if (eintrag.isFile()) {
        if (eintrag.name === 'qom-cms.db') dbDatei = voll;
        else if (!dbDatei && eintrag.name.endsWith('.db')) dbDatei = voll;
      }
    }
  }
  return { dbDatei, uploadsOrdner };
}

function anzahlDateien(ordner) {
  let n = 0;
  const stapel = [ordner];
  while (stapel.length > 0) {
    const aktuell = stapel.pop();
    for (const eintrag of fs.readdirSync(aktuell, { withFileTypes: true })) {
      if (eintrag.isDirectory()) stapel.push(path.join(aktuell, eintrag.name));
      else n += 1;
    }
  }
  return n;
}

const argumente = process.argv.slice(2);
const wirklich = argumente.includes('--ja');
const backupDatei = argumente.find((argument) => !argument.startsWith('--'));

let tempOrdner = null;
try {
  if (!backupDatei) {
    console.error('Aufruf:  node scripts/restore.mjs <backup-datei> [--ja]');
    console.error('Ohne --ja wird nur angezeigt, was passieren würde (Probelauf).');
    process.exit(1);
  }
  const archivPfad = path.resolve(backupDatei);
  if (!fs.existsSync(archivPfad)) {
    console.error(`FEHLER: Die Backup-Datei wurde nicht gefunden: ${archivPfad}`);
    process.exit(1);
  }

  console.log('QOM Editor – Wiederherstellung');
  console.log('==============================');
  console.log('WICHTIG: Der Server muss gestoppt sein, bevor wiederhergestellt wird!');
  console.log('');
  console.log(`  Backup-Datei:   ${archivPfad} (${mb(fs.statSync(archivPfad).size)})`);

  // 1) Archiv in Temp-Ordner entpacken
  tempOrdner = fs.mkdtempSync(path.join(os.tmpdir(), 'qom-restore-'));
  const istZip = archivPfad.toLowerCase().endsWith('.zip');
  let ergebnis;
  if (istZip) {
    ergebnis = spawnSync('unzip', ['-o', '-q', archivPfad, '-d', tempOrdner], { encoding: 'utf8' });
    if (ergebnis.error && ergebnis.error.code === 'ENOENT') {
      // Kein "unzip" installiert – bsdtar (macOS-Standard) kann auch ZIP entpacken
      ergebnis = spawnSync('tar', ['-xf', archivPfad, '-C', tempOrdner], { encoding: 'utf8' });
    }
  } else {
    ergebnis = spawnSync('tar', ['-xzf', archivPfad, '-C', tempOrdner], { encoding: 'utf8' });
  }
  if (ergebnis.error) throw ergebnis.error;
  if (ergebnis.status !== 0) {
    throw new Error(`Entpacken fehlgeschlagen (Exit ${ergebnis.status}): ${ergebnis.stderr || ''}`.trim());
  }

  // 2) Inhalt prüfen
  const { dbDatei, uploadsOrdner } = imBaumSuchen(tempOrdner);
  if (!dbDatei) {
    throw new Error('Im Backup wurde keine Datenbank-Datei (qom-cms.db) gefunden – falsches Archiv?');
  }
  console.log(`  Im Backup gefunden:`);
  console.log(`    Datenbank: ${path.basename(dbDatei)} (${mb(fs.statSync(dbDatei).size)})`);
  if (uploadsOrdner) {
    console.log(`    Uploads:   ${anzahlDateien(uploadsOrdner)} Datei(en)`);
  } else {
    console.log('    Uploads:   KEIN Uploads-Ordner im Backup – die aktuellen Uploads würden unverändert bleiben.');
  }
  console.log('');
  console.log('  Das würde ersetzt:');
  console.log(`    Datenbank:      ${config.dbPfad}`);
  if (uploadsOrdner) console.log(`    Uploads-Ordner: ${config.uploadsVerzeichnis}`);
  console.log('');

  if (!wirklich) {
    // Probelauf: nur anzeigen, nichts verändern. Kein process.exit() hier,
    // damit der finally-Block den Temp-Ordner noch aufräumen kann.
    console.log('PROBELAUF – es wurde nichts verändert.');
    console.log(`Zum echten Wiederherstellen:  node scripts/restore.mjs "${backupDatei}" --ja`);
  } else {
    // 3) Sicherheitskopie des aktuellen Stands anlegen
    const sicherungsOrdner = path.join(backupOrdner, `sicherung-vor-restore-${zeitstempel()}`);
    fs.mkdirSync(sicherungsOrdner, { recursive: true });
    for (const endung of ['', '-wal', '-shm']) {
      const quelle = config.dbPfad + endung;
      if (fs.existsSync(quelle)) {
        fs.copyFileSync(quelle, path.join(sicherungsOrdner, path.basename(quelle)));
      }
    }
    if (fs.existsSync(config.uploadsVerzeichnis)) {
      fs.cpSync(config.uploadsVerzeichnis, path.join(sicherungsOrdner, 'uploads'), { recursive: true });
    }
    console.log(`  Sicherheitskopie des aktuellen Stands: ${sicherungsOrdner}`);

    // 4) Datenbank ersetzen. Die alten -wal/-shm-Dateien MÜSSEN weg, sie gehören
    //    zur alten Datenbank und würden die wiederhergestellte beschädigen.
    fs.mkdirSync(path.dirname(config.dbPfad), { recursive: true });
    fs.copyFileSync(dbDatei, config.dbPfad);
    for (const endung of ['-wal', '-shm']) {
      fs.rmSync(config.dbPfad + endung, { force: true });
    }
    console.log('  Datenbank wiederhergestellt.');

    // 5) Uploads-Ordner ersetzen (nur wenn im Backup vorhanden)
    if (uploadsOrdner) {
      fs.rmSync(config.uploadsVerzeichnis, { recursive: true, force: true });
      fs.cpSync(uploadsOrdner, config.uploadsVerzeichnis, { recursive: true });
      console.log('  Uploads-Ordner wiederhergestellt.');
    } else {
      console.log('  Hinweis: Kein Uploads-Ordner im Backup – aktuelle Uploads bleiben unverändert.');
    }

    console.log('');
    console.log('Wiederherstellung abgeschlossen. Der Server kann jetzt wieder gestartet werden.');
  }
} catch (fehler) {
  console.error('FEHLER bei der Wiederherstellung:', fehler?.message || fehler);
  process.exitCode = 1;
} finally {
  if (tempOrdner) {
    try { fs.rmSync(tempOrdner, { recursive: true, force: true }); } catch { /* egal */ }
  }
}
