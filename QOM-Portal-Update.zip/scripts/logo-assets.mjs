// Einmaliges Hilfsskript: erzeugt aus der Original-Logo-PNG die web-optimierten
// Marken-Assets in src/public/brand/. Aufruf: node scripts/logo-assets.mjs "<pfad-zur-logo.png>"
import sharp from 'sharp';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const src = process.argv[2];
if (!src || !fs.existsSync(src)) {
  console.error('Bitte Pfad zur Logo-PNG angeben.');
  process.exit(1);
}
const zielOrdner = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'src', 'public', 'brand');
fs.mkdirSync(zielOrdner, { recursive: true });

const meta = await sharp(src).metadata();
console.log('Original:', meta.width + 'x' + meta.height, 'alpha:', meta.hasAlpha);

// Ganzes Logo: Rand trimmen, auf 720 px Breite
const logoBuf = await sharp(src).trim({ threshold: 12 }).resize({ width: 720, withoutEnlargement: true }).png().toBuffer();
const lm = await sharp(logoBuf).metadata();
await sharp(logoBuf).png({ compressionLevel: 9 }).toFile(path.join(zielOrdner, 'qom-logo.png'));
await sharp(logoBuf).webp({ quality: 92 }).toFile(path.join(zielOrdner, 'qom-logo.webp'));
console.log('Logo:', lm.width + 'x' + lm.height);

// Marke (nur das Hexagon links): aus dem bereits getrimmten Logo die linke ~23,5 %
const markW = Math.max(1, Math.round(lm.width * 0.235));
const markBuf = await sharp(logoBuf)
  .extract({ left: 0, top: 0, width: markW, height: lm.height })
  .trim({ threshold: 12 })
  .resize({ height: 120, withoutEnlargement: true })
  .png().toBuffer();
const mm = await sharp(markBuf).metadata();
await sharp(markBuf).png({ compressionLevel: 9 }).toFile(path.join(zielOrdner, 'qom-mark.png'));
await sharp(markBuf).webp({ quality: 92 }).toFile(path.join(zielOrdner, 'qom-mark.webp'));
await sharp(markBuf).resize({ width: 64, height: 64, fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
  .png().toFile(path.join(zielOrdner, 'qom-icon.png'));
console.log('Marke:', mm.width + 'x' + mm.height);
console.log('Fertig.');
