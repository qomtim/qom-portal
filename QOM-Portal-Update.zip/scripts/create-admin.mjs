// Legt einen QOM-Admin an (oder setzt dessen Passwort neu).
// Aufruf: npm run create-admin -- tim@qom.ch "Tim" "geheimes-passwort"
import { db } from '../src/db.js';
import { passwortHashen } from '../src/security.js';

const [email, name, passwort] = process.argv.slice(2);
if (!email || !name || !passwort) {
  console.log('Aufruf: npm run create-admin -- <email> <name> <passwort>');
  process.exit(1);
}
if (passwort.length < 10) {
  console.error('Das Passwort muss mindestens 10 Zeichen lang sein.');
  process.exit(1);
}

const hash = await passwortHashen(passwort);
const bestehend = db.prepare(`SELECT id FROM users WHERE email = ?`).get(email);
if (bestehend) {
  db.prepare(`UPDATE users SET pw_hash = ?, name = ?, is_admin = 1, role = 'owner' WHERE id = ?`)
    .run(hash, name, bestehend.id);
  console.log(`Geschäftsführer aktualisiert: ${email}`);
} else {
  db.prepare(`INSERT INTO users (email, pw_hash, name, is_admin, role) VALUES (?, ?, ?, 1, 'owner')`)
    .run(email, hash, name);
  console.log(`Geschäftsführer angelegt: ${email}`);
}
