// Nächtliches Backup (Primer §3, Pflichtteil).
//
// Was dieses Skript macht:
//   1. Konsistenter Schnappschuss der SQLite-Datenbank über die backup()-API
//      von better-sqlite3. Die Live-Datei wird NICHT einfach kopiert, weil im
//      WAL-Modus (qom-cms.db-wal) sonst Änderungen fehlen oder die Kopie
//      kaputt sein könnte. Die backup()-API liefert immer einen sauberen Stand.
//   2. Schnappschuss + kompletter Uploads-Ordner werden als datiertes ZIP
//      (qom-backup-JJJJ-MM-TT-HHMM.zip) in den Backup-Ordner gepackt.
//      Falls das Programm "zip" fehlt, wird ersatzweise "tar -czf" (.tar.gz)
//      verwendet.
//   3. Backups, die älter als 14 Tage sind, werden gelöscht
//      (übersteuerbar per Umgebungsvariable RETENTION_TAGE).
//
// Umgebungsvariablen:
//   BACKUP_DIR      Zielordner für die Backups (Standard: <Projekt>/backups)
//   RETENTION_TAGE  Aufbewahrung in Tagen (Standard: 14)
//
// Aufruf (z.B. per Infomaniak-Cron):  node scripts/backup.mjs
// Exit-Code ist 0 bei Erfolg, sonst 1 – so kann der Cron Alarm schlagen.

import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { db } from '../src/db.js';
import { config } from '../src/config.js';

const projektWurzel = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const backupOrdner = process.env.BACKUP_DIR || path.join(projektWurzel, 'backups');
const aufbewahrungTage = Number(process.env.RETENTION_TAGE || 14);

// Dateiname: qom-backup-JJJJ-MM-TT-HHMM.zip (lokale Zeit)
function zeitstempel(datum = new Date()) {
  const z2 = (n) => String(n).padStart(2, '0');
  return `${datum.getFullYear()}-${z2(datum.getMonth() + 1)}-${z2(datum.getDate())}-${z2(datum.getHours())}${z2(datum.getMinutes())}`;
}

function mb(bytes) {
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Alte Backups löschen: Das Datum wird aus dem Dateinamen gelesen (nicht aus
// dem Datei-Datum, das kann sich z.B. beim Kopieren ändern).
const BACKUP_MUSTER = /^qom-backup-(\d{4})-(\d{2})-(\d{2})-(\d{2})(\d{2})\.(zip|tar\.gz)$/;
function alteBackupsLoeschen() {
  const grenze = Date.now() - aufbewahrungTage * 24 * 60 * 60 * 1000;
  let geloescht = 0;
  for (const name of fs.readdirSync(backupOrdner)) {
    const treffer = BACKUP_MUSTER.exec(name);
    if (!treffer) continue; // fremde Dateien nie anfassen
    const [, jahr, monat, tag, stunde, minute] = treffer;
    const datum = new Date(Number(jahr), Number(monat) - 1, Number(tag), Number(stunde), Number(minute));
    if (datum.getTime() < grenze) {
      fs.rmSync(path.join(backupOrdner, name));
      console.log(`  Altes Backup gelöscht: ${name}`);
      geloescht += 1;
    }
  }
  return geloescht;
}

let arbeitsOrdner = null;
try {
  console.log('QOM Editor – Backup gestartet.');
  console.log(`  Datenbank:      ${config.dbPfad}`);
  console.log(`  Uploads-Ordner: ${config.uploadsVerzeichnis}`);
  console.log(`  Backup-Ordner:  ${backupOrdner}`);

  fs.mkdirSync(backupOrdner, { recursive: true });

  // Arbeitsordner: hier wird alles gesammelt, bevor es ins Archiv wandert.
  arbeitsOrdner = fs.mkdtempSync(path.join(os.tmpdir(), 'qom-backup-'));

  // 1) Konsistenter Datenbank-Schnappschuss (WAL-sicher)
  const snapshotPfad = path.join(arbeitsOrdner, 'qom-cms.db');
  await db.backup(snapshotPfad);
  db.close();
  const dbGroesse = fs.statSync(snapshotPfad).size;
  console.log(`  Datenbank-Schnappschuss erstellt (${mb(dbGroesse)}).`);

  // 2) Uploads-Ordner dazulegen (falls er fehlt: leeren Ordner sichern)
  const uploadsZiel = path.join(arbeitsOrdner, 'uploads');
  if (fs.existsSync(config.uploadsVerzeichnis)) {
    fs.cpSync(config.uploadsVerzeichnis, uploadsZiel, { recursive: true });
  } else {
    fs.mkdirSync(uploadsZiel, { recursive: true });
    console.log('  Hinweis: Uploads-Ordner existiert nicht – leerer Ordner wird gesichert.');
  }

  // Kleine Info-Datei, damit man beim Wiederherstellen weiss, woher das Backup stammt
  fs.writeFileSync(
    path.join(arbeitsOrdner, 'backup-info.txt'),
    [
      'QOM Editor – Backup',
      `Erstellt am:    ${new Date().toISOString()}`,
      `Rechner:        ${os.hostname()}`,
      `Datenbank:      ${config.dbPfad}`,
      `Uploads-Ordner: ${config.uploadsVerzeichnis}`,
      '',
      'Wiederherstellen mit:  node scripts/restore.mjs <diese-datei> --ja',
      '',
    ].join('\n')
  );

  // 3) Archiv packen: zuerst mit "zip", sonst mit "tar -czf" (.tar.gz)
  const basisName = `qom-backup-${zeitstempel()}`;
  const inhalte = ['qom-cms.db', 'uploads', 'backup-info.txt'];
  let archivPfad = path.join(backupOrdner, `${basisName}.zip`);
  // Falls in derselben Minute schon ein Backup entstand: alte Datei entfernen,
  // sonst würde "zip" in das bestehende Archiv hineinschreiben statt es zu ersetzen.
  fs.rmSync(archivPfad, { force: true });
  let ergebnis = spawnSync('zip', ['-r', '-q', archivPfad, ...inhalte], {
    cwd: arbeitsOrdner,
    encoding: 'utf8',
  });
  if (ergebnis.error && ergebnis.error.code === 'ENOENT') {
    console.log('  Hinweis: "zip" ist nicht installiert – verwende "tar -czf" (.tar.gz).');
    archivPfad = path.join(backupOrdner, `${basisName}.tar.gz`);
    ergebnis = spawnSync('tar', ['-czf', archivPfad, '-C', arbeitsOrdner, ...inhalte], {
      encoding: 'utf8',
    });
  }
  if (ergebnis.error) throw ergebnis.error;
  if (ergebnis.status !== 0) {
    throw new Error(`Packen fehlgeschlagen (Exit ${ergebnis.status}): ${ergebnis.stderr || ''}`.trim());
  }
  const archivGroesse = fs.statSync(archivPfad).size;
  console.log(`  Backup geschrieben: ${archivPfad} (${mb(archivGroesse)})`);

  // 4) Alte Backups aufräumen
  const geloescht = alteBackupsLoeschen();
  if (geloescht === 0) {
    console.log(`  Keine Backups älter als ${aufbewahrungTage} Tage gefunden.`);
  } else {
    console.log(`  ${geloescht} Backup(s) älter als ${aufbewahrungTage} Tage gelöscht.`);
  }

  console.log('Backup erfolgreich abgeschlossen.');
} catch (fehler) {
  console.error('FEHLER beim Backup:', fehler?.message || fehler);
  process.exitCode = 1;
} finally {
  // Arbeitsordner immer aufräumen
  if (arbeitsOrdner) {
    try { fs.rmSync(arbeitsOrdner, { recursive: true, force: true }); } catch { /* egal */ }
  }
}
