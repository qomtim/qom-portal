# QOM Editor – Einbau in die Website (qom-website)

Diese Vorlagen verbinden das Website-Repo (github.com/qomtim/qom-website)
mit dem QOM Editor. Der Build bricht dabei **nie**: Wenn das CMS nicht
erreichbar ist, greift automatisch die nächste Quelle.

## 1. Welche Datei wohin?

| Vorlage hier                       | Ziel im Website-Repo             | Zweck |
| ---------------------------------- | -------------------------------- | ----- |
| `content.js`                       | `src/data/content.js`            | Lädt die Inhalte beim Build: QOM-CMS → (übergangsweise) Storyblok → `site.js` |
| `preview.js`                       | `public/preview.js`              | Live-Vorschau der Entwürfe (ersetzt das bisherige Storyblok-Vorschau-Skript) |
| `blog/index.astro`                 | `src/pages/blog/index.astro`     | Blog-Übersicht |
| `blog/[slug].astro`                | `src/pages/blog/[slug].astro`    | Einzelner Blogbeitrag |

**Wichtig vor dem Kopieren:**

- `content.js`: Das Feld-Mapping in `qomAbbilden()` ist nur ein **Beispiel** –
  es muss an die Feld-Schlüssel aus dem QOM-Adminbereich und an die Struktur
  angepasst werden, die die bestehenden Komponenten erwarten (Vorbild:
  `src/data/site.js`). Das bisherige Storyblok-Mapping aus der alten
  `content.js` in die Funktion `storyblokAbbilden()` übernehmen.
- `preview.js`: Die Zuordnungstabelle `SB_ZUORDNUNG` (bestehende
  `data-sb`/`data-sbp`-Pfade → QOM-Feldschlüssel) ausfüllen. Neue Bereiche
  können direkt mit `data-qom="feldschluessel"` ausgezeichnet werden.
  Im Layout einbinden (vor `</body>`):

  ```html
  <script src="/preview.js"
          data-cms="https://editor.quitordinarymarketing.ch"
          data-projekt="qom-website"></script>
  ```

- Blog-Seiten: Das Markup ist bewusst schlicht – idealerweise ins bestehende
  Layout der Website einbetten. Der Blog-Link in der Navigation soll nur
  erscheinen, wenn Beiträge existieren (Beispiel-Snippet steht im Kopf von
  `blog/index.astro`).

## 2. GitHub-Secrets eintragen

Im Website-Repo unter **Settings → Secrets and variables → Actions →
New repository secret** drei Secrets anlegen:

| Secret            | Wert (Beispiel)                                | Woher? |
| ----------------- | ---------------------------------------------- | ------ |
| `QOM_CMS_URL`     | `https://editor.quitordinarymarketing.ch`      | Adresse des QOM Editors |
| `QOM_CMS_TOKEN`   | `…` (langer Zufallswert)                       | QOM-Adminbereich → Projekt → API-Token |
| `QOM_CMS_PROJEKT` | `qom-website`                                  | Projekt-Adresse (Slug) im QOM-Adminbereich |

`STORYBLOK_TOKEN` vorerst **behalten** – er ist die Übergangs-Reserve.
Erst löschen, wenn die Website nachweislich komplett über das QOM CMS baut.

Dann in `.github/workflows/deploy.yml` die Secrets an den Build-Schritt
durchreichen (bei `astro build` bzw. `npm run build`):

```yaml
- name: Website bauen
  run: npm run build
  env:
    QOM_CMS_URL: ${{ secrets.QOM_CMS_URL }}
    QOM_CMS_TOKEN: ${{ secrets.QOM_CMS_TOKEN }}
    QOM_CMS_PROJEKT: ${{ secrets.QOM_CMS_PROJEKT }}
    STORYBLOK_TOKEN: ${{ secrets.STORYBLOK_TOKEN }}
```

## 3. Lokal testen

Im Website-Repo eine Datei `.env` anlegen (nicht committen!):

```
QOM_CMS_URL=https://editor.quitordinarymarketing.ch
QOM_CMS_TOKEN=<API-Token aus dem Adminbereich>
QOM_CMS_PROJEKT=qom-website
```

Dann:

```bash
npm run build        # Build-Log prüfen: "[inhalte] Quelle: QOM-CMS (…)"
npm run preview      # Website unter http://localhost:4321 anschauen
```

Prüfen:

1. **Inhalte:** Im Build-Log muss `[inhalte] Quelle: QOM-CMS` stehen.
   Steht dort `Storyblok` oder `site.js`, sind Adresse/Token/Projekt falsch
   oder das Projekt hat noch keine veröffentlichten Inhalte.
2. **Blog:** `/blog/` zeigt die veröffentlichten Beiträge, jeder Beitrag ist
   unter `/blog/<adresse>/` erreichbar. Ohne Beiträge erscheint die
   Übersicht mit dem Hinweis "Zurzeit sind keine Beiträge vorhanden."
3. **Live-Vorschau:** Website mit `?preview=<Vorschau-Token>` aufrufen
   (Token steht im QOM-Adminbereich beim Projekt). Unten links erscheint
   "Vorschau – zeigt unveröffentlichte Entwürfe" und die Texte zeigen den
   Entwurfs-Stand. Im QOM Editor tippen → das Vorschau-Fenster
   aktualisiert sich live.

## 4. Fallback-Verhalten (was passiert wenn …)

| Situation                                   | Verhalten |
| ------------------------------------------- | --------- |
| QOM CMS nicht erreichbar / Token falsch     | Warnung im Build-Log, Inhalte kommen von Storyblok (solange Token vorhanden), sonst von `site.js`. Build läuft durch. |
| QOM-Projekt existiert, ist aber noch leer   | Wird wie "nicht erreichbar" behandelt – nächste Quelle übernimmt. |
| Storyblok gekündigt (`STORYBLOK_TOKEN` weg) | Stufe wird übersprungen, `site.js` bleibt letztes Netz. |
| Posts-API nicht erreichbar                  | Blog-Übersicht baut mit leerer Liste, keine Beitragsseiten, Build läuft durch. |
| Vorschau-API nicht erreichbar               | Website funktioniert normal, nur die Entwurfs-Vorschau bleibt aus (Meldung in der Browser-Konsole). |

## 5. Reihenfolge für die Umstellung (empfohlen)

1. Secrets eintragen (Abschnitt 2), Dateien einbauen (Abschnitt 1),
   Mapping anpassen.
2. Deploy laufen lassen und prüfen, dass die Website unverändert aussieht
   (Quelle: QOM-CMS im Log).
3. Einige Tage Parallelbetrieb: Änderungen im QOM Editor veröffentlichen
   und auf der Website kontrollieren.
4. Erst danach Storyblok kündigen und `STORYBLOK_TOKEN` entfernen.
