// =============================================================================
// QOM Editor – Live-Vorschau-Skript für die Kundenwebsite
// (Nachfolger von public/preview.js im Website-Repo)
// =============================================================================
//
// EINBAU: Diese Datei als `public/preview.js` ins Website-Repo legen und im
// Layout (z.B. src/layouts/Layout.astro, vor </body>) einbinden:
//
//   <script src="/preview.js"
//           data-cms="https://editor.quitordinarymarketing.ch"
//           data-projekt="qom-website"></script>
//
// WAS ES TUT:
//   - Ohne `?preview=<token>` in der Adresse passiert NICHTS (normale Besucher
//     merken nichts, das Skript beendet sich sofort).
//   - Mit `?preview=<token>` (so lädt der QOM Editor die Website in sein
//     Vorschau-Fenster) holt es den ENTWURFS-Stand von der Content-API und
//     ersetzt Texte und Bilder auf der Seite:
//       * Elemente mit  data-qom="feldkey"          (neues Attribut)
//       * Elemente mit  data-sb / data-sbp          (bestehende Storyblok-
//         Attribute) über die Zuordnungstabelle SB_ZUORDNUNG unten.
//   - Es lauscht auf postMessage-Nachrichten des QOM Editors
//     ({ typ: 'qom-vorschau', feld, wert }) und aktualisiert live beim Tippen.
//
// KEIN Framework, defensiv programmiert: Wenn die API nicht erreichbar ist,
// bleibt die Website ganz normal nutzbar (nur die Vorschau bleibt statisch).
// =============================================================================

(function () {
  'use strict';

  // ---------------------------------------------------------------------------
  // Zuordnung: bestehende data-sb-/data-sbp-Pfade → QOM-Feldschlüssel.
  // >>> AN DIE WEBSITE ANPASSEN: linke Seite = Wert des data-sb/data-sbp-
  // Attributs im HTML, rechte Seite = Feldschlüssel im QOM Editor. <<<
  // Kann alternativ VOR dem Einbinden dieses Skripts über
  // `window.QOM_SB_ZUORDNUNG = { … }` gesetzt/ergänzt werden.
  // ---------------------------------------------------------------------------
  var SB_ZUORDNUNG = {
    // 'site.content.hero_title': 'hero_titel',
    // 'site.content.hero_subtitle': 'hero_untertitel',
    // 'site.content.hero_image': 'hero_bild',
  };

  try {
    starten();
  } catch (fehler) {
    // Die Vorschau darf die Website nie kaputt machen.
    if (window.console && console.warn) console.warn('[qom-vorschau] Deaktiviert:', fehler);
  }

  function starten() {
    // --- Nur aktiv, wenn die Seite mit ?preview=<token> geladen wurde --------
    var token = '';
    try {
      token = new URLSearchParams(window.location.search).get('preview') || '';
    } catch (fehler) {
      return; // sehr alter Browser – Vorschau still überspringen
    }
    if (!token) return;

    // --- Konfiguration aus dem eigenen <script>-Tag lesen ---------------------
    var skript = document.currentScript;
    if (!skript || !skript.dataset || !skript.dataset.cms) {
      skript = document.querySelector('script[data-cms][data-projekt]');
    }
    var cmsBasis = (skript && skript.dataset && skript.dataset.cms ? skript.dataset.cms : '').replace(/\/+$/, '');
    var projekt = skript && skript.dataset && skript.dataset.projekt ? skript.dataset.projekt : '';
    if (!cmsBasis || !projekt) {
      console.warn('[qom-vorschau] data-cms oder data-projekt fehlt am <script>-Tag – Vorschau deaktiviert.');
      return;
    }

    var cmsOrigin = '';
    try {
      cmsOrigin = new URL(cmsBasis).origin;
    } catch (fehler) {
      console.warn('[qom-vorschau] Ungültige CMS-Adresse im data-cms-Attribut:', cmsBasis);
      return;
    }

    // Externe Zuordnung (falls gesetzt) über die eingebaute legen.
    var zuordnung = {};
    var schluessel;
    for (schluessel in SB_ZUORDNUNG) {
      if (Object.prototype.hasOwnProperty.call(SB_ZUORDNUNG, schluessel)) {
        zuordnung[schluessel] = SB_ZUORDNUNG[schluessel];
      }
    }
    var extern = window.QOM_SB_ZUORDNUNG;
    if (extern && typeof extern === 'object') {
      for (schluessel in extern) {
        if (Object.prototype.hasOwnProperty.call(extern, schluessel)) {
          zuordnung[schluessel] = extern[schluessel];
        }
      }
    }

    // Umkehrung: Feldschlüssel → Liste der data-sb/data-sbp-Pfade
    var feldZuSbPfaden = {};
    for (schluessel in zuordnung) {
      if (!Object.prototype.hasOwnProperty.call(zuordnung, schluessel)) continue;
      var feldKey = zuordnung[schluessel];
      if (!feldZuSbPfaden[feldKey]) feldZuSbPfaden[feldKey] = [];
      feldZuSbPfaden[feldKey].push(schluessel);
    }

    // --- Hilfsfunktionen ------------------------------------------------------

    function attributWertEscapen(wert) {
      // Für den Einsatz in [attr="…"]-Selektoren (Feldschlüssel sind einfach,
      // aber wir gehen auf Nummer sicher).
      return String(wert).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    }

    function bildUrlAbsolut(wert) {
      if (!wert) return '';
      if (/^https?:\/\//i.test(wert)) return wert;
      if (wert.indexOf('/uploads/') === 0) return cmsBasis + wert;
      return wert;
    }

    function elementeFuerFeld(feld) {
      var selektoren = ['[data-qom="' + attributWertEscapen(feld) + '"]'];
      var pfade = feldZuSbPfaden[feld] || [];
      for (var i = 0; i < pfade.length; i++) {
        var pfad = attributWertEscapen(pfade[i]);
        selektoren.push('[data-sb="' + pfad + '"]');
        selektoren.push('[data-sbp="' + pfad + '"]');
      }
      try {
        return document.querySelectorAll(selektoren.join(', '));
      } catch (fehler) {
        return [];
      }
    }

    function feldAnwenden(feld, wert) {
      if (typeof feld !== 'string' || feld === '') return;
      var elemente = elementeFuerFeld(feld);
      for (var i = 0; i < elemente.length; i++) {
        var element = elemente[i];
        try {
          if (element.tagName === 'IMG') {
            var url = bildUrlAbsolut(String(wert == null ? '' : wert));
            if (url) {
              element.src = url;
              element.removeAttribute('srcset'); // sonst gewinnt das alte Bild
            }
          } else if (element.tagName === 'A' && element.hasAttribute('data-qom-href')) {
            // Optional: <a data-qom="feld" data-qom-href> aktualisiert den Link.
            element.href = String(wert == null ? '' : wert);
          } else {
            element.textContent = String(wert == null ? '' : wert);
          }
        } catch (fehler) {
          /* einzelnes Element überspringen, Rest weiter aktualisieren */
        }
      }
    }

    function alleFelderAnwenden(felder) {
      if (!felder || typeof felder !== 'object') return;
      for (var feld in felder) {
        if (Object.prototype.hasOwnProperty.call(felder, feld)) {
          feldAnwenden(feld, felder[feld]);
        }
      }
    }

    // Bereiche ein-/ausblenden: Elemente mit data-qom-bereich="<key>" werden
    // versteckt, wenn der Bereich im Entwurf ausgeblendet ist.
    function bereicheAnwenden(bereiche) {
      if (!bereiche || typeof bereiche !== 'object') return;
      for (var key in bereiche) {
        if (!Object.prototype.hasOwnProperty.call(bereiche, key)) continue;
        var sichtbar = !!(bereiche[key] && bereiche[key].sichtbar);
        var liste = document.querySelectorAll('[data-qom-bereich="' + attributWertEscapen(key) + '"]');
        for (var i = 0; i < liste.length; i++) {
          liste[i].style.display = sichtbar ? '' : 'none';
        }
      }
    }

    // --- 1) Entwurfs-Stand von der Content-API holen --------------------------

    var apiUrl = cmsBasis + '/api/v1/projects/' + encodeURIComponent(projekt)
      + '/content?version=draft&token=' + encodeURIComponent(token);

    fetch(apiUrl)
      .then(function (antwort) {
        if (!antwort.ok) throw new Error('HTTP ' + antwort.status);
        return antwort.json();
      })
      .then(function (daten) {
        if (daten && daten.felder) {
          alleFelderAnwenden(daten.felder);
          bereicheAnwenden(daten.bereiche);
          hinweisAnzeigen();
        }
      })
      .catch(function (fehler) {
        // API nicht erreichbar oder Token ungültig: Website bleibt unverändert.
        console.warn('[qom-vorschau] Entwurfs-Stand konnte nicht geladen werden:', fehler && fehler.message ? fehler.message : fehler);
      });

    // --- 2) Live-Aktualisierung beim Tippen (postMessage vom QOM Editor) ------

    window.addEventListener('message', function (ereignis) {
      // Nur Nachrichten vom CMS akzeptieren (der Editor läuft dort als Seite,
      // die diese Website im iframe zeigt).
      if (ereignis.origin !== cmsOrigin) return;
      var daten = ereignis.data;
      if (!daten || daten.typ !== 'qom-vorschau') return;
      try {
        feldAnwenden(daten.feld, daten.wert);
      } catch (fehler) {
        /* nie die Seite stören */
      }
    });

    // --- Kleiner, dezenter Hinweis, dass Entwürfe angezeigt werden ------------

    var hinweisGezeigt = false;
    function hinweisAnzeigen() {
      if (hinweisGezeigt || !document.body) return;
      hinweisGezeigt = true;
      try {
        var hinweis = document.createElement('div');
        hinweis.textContent = 'Vorschau – zeigt unveröffentlichte Entwürfe';
        hinweis.setAttribute('style',
          'position:fixed;left:12px;bottom:12px;z-index:99999;' +
          'background:#111;color:#fff;font:12px/1.4 system-ui,sans-serif;' +
          'padding:6px 10px;border-radius:6px;opacity:.85;pointer-events:none;');
        document.body.appendChild(hinweis);
      } catch (fehler) {
        /* rein kosmetisch – Fehler ignorieren */
      }
    }
  }
})();
