// =============================================================================
// QOM Editor – Ladelogik für Website-Inhalte (Vorlage für src/data/content.js)
// =============================================================================
//
// EINBAU INS WEBSITE-REPO (github.com/qomtim/qom-website):
//
//   1. Diese Datei ersetzt (bzw. wird eingearbeitet in) `src/data/content.js`.
//      Die bestehende Datei vorher sichern – ihr Storyblok-Mapping wird unten
//      in `storyblokAbbilden()` wiederverwendet (siehe TODO-Markierung).
//   2. Neue GitHub-Secrets im Website-Repo anlegen (Settings → Secrets and
//      variables → Actions):
//        QOM_CMS_URL      z.B. https://editor.quitordinarymarketing.ch
//        QOM_CMS_TOKEN    das API-Token des Projekts (aus dem QOM-Adminbereich)
//        QOM_CMS_PROJEKT  der Projekt-Slug im CMS, z.B. qom-website
//      und im Build-Schritt von `.github/workflows/deploy.yml` als
//      Umgebungsvariablen durchreichen (siehe ANLEITUNG.md).
//   3. `STORYBLOK_TOKEN` bleibt übergangsweise bestehen. Sobald der
//      Parallelbetrieb verifiziert ist, kann das Secret entfernt werden –
//      die Kette überspringt Storyblok dann automatisch.
//
// LADEKETTE (Primer §6) – der Build darf NIE brechen:
//
//   1. QOM-CMS-API   → veröffentlichter Stand von editor.quitordinarymarketing.ch
//   2. Storyblok     → (übergangsweise) der bisherige Weg
//   3. site.js       → statischer Notfall-Inhalt im Repo
//
//   Jede Stufe ist in try/catch verpackt. Schlägt eine Stufe fehl (Netzwerk,
//   falsches Token, leeres Projekt), gibt es eine klare Konsolen-Warnung und
//   die nächste Stufe übernimmt. Erst wenn wirklich alles scheitert, wird ein
//   leeres Objekt geliefert – auch dann baut die Website noch.
//
// WICHTIG – FELD-MAPPING ANPASSEN:
//
//   Die Funktion `qomAbbilden()` unten enthält nur ein BEISPIEL-Mapping.
//   Die Feld-Schlüssel (z.B. `hero_titel`) müssen exakt den Schlüsseln
//   entsprechen, die im QOM-Adminbereich für das Projekt angelegt wurden,
//   und die Zielstruktur muss der Form entsprechen, die die bestehenden
//   Astro-Komponenten heute aus `site.js` bzw. dem Storyblok-Mapping erwarten.
//   Am einfachsten: `site.js` daneben legen und Feld für Feld übertragen.
//
// API-ANTWORTFORM (GET /api/v1/projects/:slug/content?token=…):
//
//   {
//     projekt:     { name, slug, logo_url },
//     stand:       "published" | "draft",
//     felder:      { "hero_titel": "…", "hero_bild": "/uploads/qom-website/abc.jpg", … },
//     sammlungen:  { "team": { label: "Team", eintraege: [ { name: "…", … } ] }, … },
//     generiert_am: "2026-08-09T…"
//   }
//
//   Bild-Werte aus dem CMS sind RELATIVE Pfade (/uploads/…) und müssen mit
//   der CMS-Basis-URL absolut gemacht werden – dafür gibt es `bildUrl()`.
// =============================================================================

// Umgebungsvariablen: Astro/Vite stellt sie unter `import.meta.env` bereit,
// beim GitHub-Actions-Build kommen sie zusätzlich über `process.env`.
// Wir prüfen beides, damit die Datei in jedem Kontext funktioniert.
function envWert(name) {
  try {
    if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[name]) {
      return String(import.meta.env[name]);
    }
  } catch {
    /* import.meta.env existiert ausserhalb von Vite nicht – kein Problem */
  }
  if (typeof process !== 'undefined' && process.env && process.env[name]) {
    return String(process.env[name]);
  }
  return '';
}

const QOM_CMS_URL = envWert('QOM_CMS_URL').replace(/\/+$/, '');
const QOM_CMS_TOKEN = envWert('QOM_CMS_TOKEN');
const QOM_CMS_PROJEKT = envWert('QOM_CMS_PROJEKT');
const STORYBLOK_TOKEN = envWert('STORYBLOK_TOKEN');

const ABRUF_TIMEOUT_MS = 10000;

/** Macht CMS-Bildpfade (/uploads/…) absolut. Fremde URLs bleiben unverändert. */
export function bildUrl(wert) {
  if (!wert || typeof wert !== 'string') return '';
  if (/^https?:\/\//i.test(wert)) return wert;
  if (wert.startsWith('/uploads/') && QOM_CMS_URL) return QOM_CMS_URL + wert;
  return wert;
}

/** fetch mit Timeout – ein hängender Server darf den Build nicht blockieren. */
async function abrufen(url) {
  const abbruch = new AbortController();
  const timer = setTimeout(() => abbruch.abort(), ABRUF_TIMEOUT_MS);
  try {
    const antwort = await fetch(url, { signal: abbruch.signal });
    if (!antwort.ok) throw new Error(`HTTP ${antwort.status}`);
    return await antwort.json();
  } finally {
    clearTimeout(timer);
  }
}

// -----------------------------------------------------------------------------
// Stufe 1: QOM-CMS-API
// -----------------------------------------------------------------------------

/**
 * BEISPIEL-Mapping: CMS-Daten → Struktur, die die Astro-Komponenten erwarten.
 * >>> AN DIE BESTEHENDEN KOMPONENTEN ANPASSEN (Vorbild: src/data/site.js). <<<
 *
 * `felder` ist ein flaches Objekt { schluessel: wert }, `sammlungen` enthält
 * pro Liste { label, eintraege: [...] }. Die Roh-Daten werden zusätzlich
 * unter `felder`/`sammlungen` mitgegeben, damit beim Umbau nichts verloren geht.
 */
function qomAbbilden(daten) {
  const felder = daten.felder || {};
  const sammlungen = daten.sammlungen || {};
  const eintraege = (schluessel) => (sammlungen[schluessel] && sammlungen[schluessel].eintraege) || [];

  return {
    quelle: 'qom-cms',
    projekt: daten.projekt || {},

    // --- Beispiel: Startseite – Titelbereich -------------------------------
    hero: {
      titel: felder.hero_titel || '',
      untertitel: felder.hero_untertitel || '',
      bild: bildUrl(felder.hero_bild),
      knopfText: felder.hero_knopf_text || '',
      knopfLink: felder.hero_knopf_link || '',
    },

    // --- Beispiel: Listen (Collections) ------------------------------------
    team: eintraege('team').map((person) => ({
      name: person.name || '',
      rolle: person.rolle || '',
      bild: bildUrl(person.bild),
    })),
    referenzen: eintraege('referenzen'),
    kundenstimmen: eintraege('kundenstimmen'),
    kennzahlen: eintraege('kennzahlen'),
    faq: eintraege('faq'),

    // --- Beispiel: Kontakt ---------------------------------------------------
    kontakt: {
      email: felder.kontakt_email || '',
      telefon: felder.kontakt_telefon || '',
      adresse: felder.kontakt_adresse || '',
    },

    // Roh-Daten für den Umbau / für Komponenten, die direkt zugreifen wollen:
    felder,
    sammlungen,
  };
}

async function vomQomCms() {
  if (!QOM_CMS_URL || !QOM_CMS_TOKEN || !QOM_CMS_PROJEKT) {
    console.warn('[inhalte] QOM-CMS übersprungen: QOM_CMS_URL, QOM_CMS_TOKEN oder QOM_CMS_PROJEKT nicht gesetzt.');
    return null;
  }
  const url = `${QOM_CMS_URL}/api/v1/projects/${encodeURIComponent(QOM_CMS_PROJEKT)}/content?token=${encodeURIComponent(QOM_CMS_TOKEN)}`;
  const daten = await abrufen(url);
  if (!daten || typeof daten !== 'object' || !daten.felder) {
    throw new Error('Antwort hat nicht die erwartete Form (kein "felder"-Objekt).');
  }
  const istLeer = Object.keys(daten.felder).length === 0
    && Object.keys(daten.sammlungen || {}).length === 0;
  if (istLeer) {
    // Frisch angelegtes Projekt ohne veröffentlichte Inhalte: lieber auf die
    // nächste Stufe ausweichen, als eine leere Website zu bauen.
    console.warn('[inhalte] QOM-CMS liefert (noch) keine veröffentlichten Inhalte – nächste Quelle wird versucht.');
    return null;
  }
  return qomAbbilden(daten);
}

// -----------------------------------------------------------------------------
// Stufe 2: Storyblok (übergangsweise, bis der Parallelbetrieb verifiziert ist)
// -----------------------------------------------------------------------------

/**
 * >>> TODO: Hier das BESTEHENDE Storyblok-Mapping aus der heutigen
 * src/data/content.js einsetzen (Story `site` → Komponenten-Struktur). <<<
 *
 * Solange kein Mapping eingesetzt ist, gibt diese Funktion bewusst `null`
 * zurück, damit die Kette sauber auf site.js weiterfällt, statt eine
 * halb gemappte Struktur zu liefern.
 */
function storyblokAbbilden(story) { // eslint-disable-line no-unused-vars
  console.warn('[inhalte] Storyblok-Mapping noch nicht eingesetzt (storyblokAbbilden) – site.js-Fallback wird verwendet.');
  return null;
}

async function vonStoryblok() {
  if (!STORYBLOK_TOKEN) {
    console.warn('[inhalte] Storyblok übersprungen: STORYBLOK_TOKEN nicht gesetzt.');
    return null;
  }
  const url = `https://api.storyblok.com/v2/cdn/stories/site?version=published&token=${encodeURIComponent(STORYBLOK_TOKEN)}&cv=${Date.now()}`;
  const daten = await abrufen(url);
  if (!daten || !daten.story) throw new Error('Antwort enthält keine Story.');
  return storyblokAbbilden(daten.story);
}

// -----------------------------------------------------------------------------
// Stufe 3: site.js-Fallback (statisch im Repo – funktioniert immer)
// -----------------------------------------------------------------------------

async function vonSiteJs() {
  try {
    const modul = await import('./site.js');
    const inhalt = modul.site ?? modul.default ?? modul;
    return { quelle: 'site.js', ...inhalt };
  } catch (fehler) {
    console.warn(`[inhalte] site.js-Fallback konnte nicht geladen werden: ${fehler.message}`);
    return null;
  }
}

// -----------------------------------------------------------------------------
// Die Kette
// -----------------------------------------------------------------------------

/**
 * Lädt die Website-Inhalte über die Kette QOM-CMS → Storyblok → site.js.
 * Wirft NIE einen Fehler – im schlimmsten Fall kommt ein leeres Objekt zurück.
 */
export async function ladeInhalte() {
  // Stufe 1: QOM-CMS
  try {
    const inhalt = await vomQomCms();
    if (inhalt) {
      console.log('[inhalte] Quelle: QOM-CMS (' + QOM_CMS_URL + ')');
      return inhalt;
    }
  } catch (fehler) {
    console.warn(`[inhalte] WARNUNG: QOM-CMS nicht erreichbar oder fehlerhaft (${fehler.message}) – weiche auf Storyblok aus.`);
  }

  // Stufe 2: Storyblok
  try {
    const inhalt = await vonStoryblok();
    if (inhalt) {
      console.log('[inhalte] Quelle: Storyblok');
      return inhalt;
    }
  } catch (fehler) {
    console.warn(`[inhalte] WARNUNG: Storyblok nicht erreichbar oder fehlerhaft (${fehler.message}) – weiche auf site.js aus.`);
  }

  // Stufe 3: site.js
  const fallback = await vonSiteJs();
  if (fallback) {
    console.log('[inhalte] Quelle: site.js (statischer Fallback)');
    return fallback;
  }

  // Allerletztes Netz: leeres Objekt, damit der Build durchläuft.
  console.warn('[inhalte] WARNUNG: Keine Inhaltsquelle verfügbar – es wird ein leeres Inhaltsobjekt verwendet.');
  return { quelle: 'leer', felder: {}, sammlungen: {} };
}

// Beim Build einmal laden; Komponenten importieren einfach `inhalte`:
//   import { inhalte } from '../data/content.js';
export const inhalte = await ladeInhalte();
export default inhalte;
