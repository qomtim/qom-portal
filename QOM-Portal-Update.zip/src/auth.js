// Sessions, Login-Schutz und CSRF.
// Sessions liegen in der Datenbank; der Browser bekommt nur eine zufällige ID
// als httpOnly-Cookie. CSRF über Double-Submit-Cookie + Hidden-Field/Header.
import { db } from './db.js';
import { config } from './config.js';
import { neuesToken, sichererVergleich, sqliteZeitStempel } from './security.js';

export const SESSION_COOKIE = 'qom_sid';
export const CSRF_COOKIE = 'qom_csrf';

export function sessionErstellen(reply, userId) {
  const id = neuesToken();
  const ablauf = sqliteZeitStempel(config.sessionDauerMs);
  db.prepare(`INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)`).run(id, userId, ablauf);
  reply.setCookie(SESSION_COOKIE, id, {
    path: '/',
    httpOnly: true,
    secure: config.istProduktion,
    sameSite: 'lax',
    maxAge: Math.floor(config.sessionDauerMs / 1000),
  });
}

export function sessionBeenden(request, reply) {
  const sid = request.cookies?.[SESSION_COOKIE];
  if (sid) db.prepare(`DELETE FROM sessions WHERE id = ?`).run(sid);
  reply.clearCookie(SESSION_COOKIE, { path: '/' });
}

export function aktuellerNutzer(request) {
  const sid = request.cookies?.[SESSION_COOKIE];
  if (!sid) return null;
  const zeile = db.prepare(
    `SELECT u.id, u.email, u.name, u.is_admin, u.role
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.id = ? AND s.expires_at > datetime('now')`
  ).get(sid);
  return zeile || null;
}

// Sorgt dafür, dass jeder Browser ein CSRF-Cookie hat, und liefert den Wert.
export function csrfSicherstellen(request, reply) {
  let wert = request.cookies?.[CSRF_COOKIE];
  if (!wert) {
    wert = neuesToken();
    reply.setCookie(CSRF_COOKIE, wert, {
      path: '/',
      httpOnly: false, // muss von unserem Vanilla-JS lesbar sein
      secure: config.istProduktion,
      sameSite: 'lax',
    });
  }
  return wert;
}

export function csrfPruefen(request) {
  const cookieWert = request.cookies?.[CSRF_COOKIE];
  const gesendet = request.headers['x-csrf-token'] || request.body?._csrf;
  return Boolean(cookieWert && gesendet && sichererVergleich(cookieWert, gesendet));
}

export function istGeschaeftsfuehrer(nutzer) {
  return Boolean(nutzer && (nutzer.role === 'owner' || nutzer.is_admin));
}

// Zugriffsobjekt eines Nutzers auf ein Projekt – oder null bei keinem Zugriff.
//   kind: 'owner' (Geschäftsführer) | 'staff' (Mitarbeiter) | 'customer' (Kunde)
//   darfAlles: bearbeitet auch gesperrte Felder & sieht alle Bereiche (owner/staff)
//   admin:     darf in den QOM-Adminbereich (nur owner)
export function projektZugriff(nutzer, projekt) {
  if (!nutzer || !projekt) return null;
  if (istGeschaeftsfuehrer(nutzer)) {
    return { kind: 'owner', darfAlles: true, admin: true };
  }
  const mitglied = db.prepare(
    `SELECT 1 FROM memberships WHERE user_id = ? AND project_id = ?`
  ).get(nutzer.id, projekt.id);
  if (!mitglied) return null;
  if (nutzer.role === 'staff') {
    return { kind: 'staff', darfAlles: true, admin: false };
  }
  return { kind: 'customer', darfAlles: false, admin: false };
}

// Rückwärtskompatibel: 'admin' (darf alles) | 'editor' (eingeschränkt) | null
export function projektRolle(nutzer, projektId) {
  const projekt = db.prepare(`SELECT id FROM projects WHERE id = ?`).get(projektId);
  const zugriff = projektZugriff(nutzer, projekt);
  if (!zugriff) return null;
  return zugriff.darfAlles ? 'admin' : 'editor';
}

export function projekteDesNutzers(nutzer) {
  if (!nutzer) return [];
  if (istGeschaeftsfuehrer(nutzer)) {
    return db.prepare(`SELECT * FROM projects ORDER BY name`).all();
  }
  return db.prepare(
    `SELECT p.* FROM projects p
       JOIN memberships m ON m.project_id = p.id
      WHERE m.user_id = ? ORDER BY p.name`
  ).all(nutzer.id);
}
