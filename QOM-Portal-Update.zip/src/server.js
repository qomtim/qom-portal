// QOM Editor – Server-Einstiegspunkt.
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import Fastify from 'fastify';
import fastifyCookie from '@fastify/cookie';
import fastifyFormbody from '@fastify/formbody';
import fastifyMultipart from '@fastify/multipart';
import fastifyStatic from '@fastify/static';
import fastifyView from '@fastify/view';
import fastifyRateLimit from '@fastify/rate-limit';
import nunjucks from 'nunjucks';

import { config } from './config.js';
import { db } from './db.js';
import { aktuellerNutzer, csrfSicherstellen, csrfPruefen } from './auth.js';
import { authRouten } from './routes/auth-routen.js';
import { editorRouten } from './routes/editor.js';
import { adsRouten } from './routes/ads.js';
import { blogRouten } from './routes/blog.js';
import { uploadRouten } from './routes/uploads.js';
import { adminRouten } from './routes/admin.js';
import { apiRouten } from './routes/api.js';

const hier = path.dirname(fileURLToPath(import.meta.url));

export function appErstellen() {
  const app = Fastify({
    logger: {
      level: config.istProduktion ? 'info' : 'warn',
      // Sensible Daten nicht ins Log schreiben
      redact: ['req.headers.cookie', 'req.headers.authorization', 'req.headers["x-csrf-token"]', 'req.headers["x-metrics-token"]', 'req.headers["x-runner-token"]'],
      serializers: {
        // URL ohne Query-String loggen, damit keine Tokens (?token=…) im Log landen
        req(request) {
          return {
            method: request.method,
            url: String(request.url || '').split('?')[0],
            remoteAddress: request.ip,
          };
        },
      },
    },
    trustProxy: config.trustProxy,
    bodyLimit: config.uploadMaxBytes + 1024 * 1024,
  });

  app.register(fastifyCookie);
  app.register(fastifyFormbody);
  app.register(fastifyMultipart, {
    limits: { fileSize: config.uploadMaxBytes, files: 1 },
  });
  app.register(fastifyRateLimit, {
    global: false,
    keyGenerator: (request) => request.ip,
  });
  app.register(fastifyStatic, {
    root: path.join(hier, 'public'),
    prefix: '/static/',
    maxAge: config.istProduktion ? '7d' : 0,
  });
  app.register(fastifyView, {
    engine: { nunjucks },
    root: path.join(hier, 'views'),
    options: {
      onConfigure(env) {
        env.addFilter('datum', (iso) => {
          if (!iso) return '';
          const d = new Date(iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z');
          return d.toLocaleDateString('de-CH', { day: '2-digit', month: '2-digit', year: 'numeric' })
            + ', ' + d.toLocaleTimeString('de-CH', { hour: '2-digit', minute: '2-digit' });
        });
        env.addFilter('json', (wert) => JSON.stringify(wert));
        // Zahlen-Formatierung fürs Ads-Dashboard (Schweizer Format)
        env.addFilter('fix2', (v) => (Number(v) || 0).toLocaleString('de-CH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
        env.addFilter('fix0', (v) => Math.round(Number(v) || 0).toLocaleString('de-CH'));
        env.addFilter('prozent', (v) => (Number(v) || 0).toLocaleString('de-CH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' %');
      },
    },
  });

  // Auf jeder Anfrage: Nutzer aus der Session laden, CSRF-Cookie sicherstellen
  app.addHook('onRequest', async (request, reply) => {
    request.nutzer = aktuellerNutzer(request);
    request.csrfToken = csrfSicherstellen(request, reply);
  });

  // Sicherheits-Header auf jeder Antwort. Die CSP ist bewusst so gewählt, dass
  // sie externe Skripte/Objekte und Clickjacking blockt, aber die Live-Vorschau
  // (iframe der Kundenwebsite) und Kundenlogos (externe Bilder) nicht bricht.
  app.addHook('onSend', async (request, reply) => {
    reply.header('x-content-type-options', 'nosniff');
    reply.header('x-frame-options', 'SAMEORIGIN');
    reply.header('referrer-policy', 'strict-origin-when-cross-origin');
    if (!request.url.startsWith('/api/') && !request.url.startsWith('/vorschau/')) {
      reply.header('content-security-policy', [
        "default-src 'self'",
        "base-uri 'self'",
        "object-src 'none'",
        "frame-ancestors 'self'",
        "img-src 'self' data: https:",
        "style-src 'self' 'unsafe-inline'",
        "script-src 'self' 'unsafe-inline'",
        "connect-src 'self'",
        "frame-src https:",
        "form-action 'self'",
      ].join('; '));
    }
  });

  // Alle Formular-/AJAX-POSTs brauchen ein gültiges CSRF-Token.
  // Die Content-API (nur GET) und der Login selbst sind über eigene Regeln geschützt.
  app.addHook('preHandler', async (request, reply) => {
    const schreibend = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(request.method);
    if (!schreibend) return;
    if (request.url.startsWith('/api/')) return; // Content-API ist Token-basiert
    // Multipart (Uploads) NICHT pauschal überspringen: csrfPruefen wertet das
    // x-csrf-token aus dem Header aus, den der Upload ohnehin mitschickt.
    if (!csrfPruefen(request)) {
      reply.code(403);
      if (request.headers['x-requested-with'] === 'fetch') {
        return reply.send({ fehler: 'Sitzung abgelaufen. Bitte Seite neu laden.' });
      }
      return reply.view('fehler.njk', {
        titel: 'Sitzung abgelaufen',
        meldung: 'Deine Sitzung ist abgelaufen. Bitte lade die Seite neu und versuche es nochmals.',
        nutzer: request.nutzer,
      });
    }
  });

  // Fehlerseiten ohne Stacktraces
  app.setErrorHandler((fehler, request, reply) => {
    request.log.error(fehler);
    const status = fehler.statusCode && fehler.statusCode < 500 ? fehler.statusCode : 500;
    reply.code(status);
    if (request.url.startsWith('/api/') || request.headers['x-requested-with'] === 'fetch') {
      return reply.send({ fehler: status === 500 ? 'Interner Fehler.' : fehler.message });
    }
    return reply.view('fehler.njk', {
      titel: 'Das hat leider nicht geklappt',
      meldung: status === 500
        ? 'Es ist ein technischer Fehler aufgetreten. QOM wurde informiert.'
        : fehler.message,
      nutzer: request.nutzer,
    });
  });

  app.setNotFoundHandler((request, reply) => {
    reply.code(404);
    if (request.url.startsWith('/api/')) return reply.send({ fehler: 'Nicht gefunden.' });
    return reply.view('fehler.njk', {
      titel: 'Seite nicht gefunden',
      meldung: 'Diese Seite gibt es nicht (mehr).',
      nutzer: request.nutzer,
    });
  });

  app.get('/health', async () => {
    db.prepare('SELECT 1').get();
    return { status: 'ok', zeit: new Date().toISOString() };
  });

  app.register(authRouten);
  app.register(editorRouten);
  app.register(adsRouten);
  app.register(blogRouten);
  app.register(uploadRouten);
  app.register(adminRouten);
  app.register(apiRouten);

  return app;
}

// Nur starten, wenn direkt aufgerufen (Tests importieren appErstellen)
if (process.argv[1] && path.resolve(process.argv[1]) === path.join(hier, 'server.js')) {
  // Schutzriegel: im Produktionsbetrieb darf die Datenbank NICHT in einem
  // Cloud-Sync-Ordner liegen (Google Drive, Dropbox, OneDrive, iCloud) –
  // das kann SQLite beschädigen und lädt Kundendaten ungewollt in die Cloud.
  if (config.istProduktion && /CloudStorage|Google ?Drive|Dropbox|OneDrive|com~apple~CloudDocs|iCloud/i.test(config.dbPfad)) {
    console.error('ABBRUCH: Die Datenbank liegt in einem Cloud-Sync-Ordner. Setze DATA_DIR/DB_PATH auf einen Serverpfad ausserhalb jeder Synchronisation.');
    console.error('Pfad:', config.dbPfad);
    process.exit(1);
  }

  const app = appErstellen();

  // Fehler nicht still verschlucken
  process.on('unhandledRejection', (grund) => app.log.error({ grund }, 'Unbehandelte Promise-Ablehnung'));
  process.on('uncaughtException', (fehler) => app.log.error({ fehler }, 'Unbehandelte Ausnahme'));

  // Sauberes Herunterfahren (SIGTERM/SIGINT): offene Anfragen abschliessen, DB schliessen
  let faehrtHerunter = false;
  for (const signal of ['SIGTERM', 'SIGINT']) {
    process.on(signal, async () => {
      if (faehrtHerunter) return;
      faehrtHerunter = true;
      try { await app.close(); db.close(); } catch (fehler) { console.error(fehler); }
      process.exit(0);
    });
  }

  app.listen({ host: config.host, port: config.port }).then(() => {
    console.log(`QOM Editor läuft auf http://${config.host}:${config.port}`);
  }).catch((fehler) => {
    console.error(fehler);
    process.exit(1);
  });
}
