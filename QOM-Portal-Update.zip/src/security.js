// Passwort-Hashing, Tokens und einfache HTML-Bereinigung für den Blog-Editor.
import argon2 from 'argon2';
import crypto from 'node:crypto';

export async function passwortHashen(passwort) {
  return argon2.hash(passwort, { type: argon2.argon2id });
}

export async function passwortPruefen(hash, passwort) {
  try {
    return await argon2.verify(hash, passwort);
  } catch {
    return false;
  }
}

// 32 Bytes Zufall, URL-sicher kodiert → hohe Entropie für API-/Preview-/Session-Tokens
export function neuesToken() {
  return crypto.randomBytes(32).toString('base64url');
}

// Hash eines Tokens (für Einladungs-/Reset-Links): in der DB steht nur der Hash,
// der Rohwert lebt nur im Link/der E-Mail. So sind DB-/Backup-Lecks nutzlos.
export function tokenHash(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}

export function sichererVergleich(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

export function slugAusText(text) {
  return String(text)
    .toLowerCase()
    .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'beitrag';
}

// Zeitstempel im SQLite-Format (UTC, "JJJJ-MM-TT HH:MM:SS"), damit
// String-Vergleiche mit datetime('now') korrekt funktionieren.
export function sqliteZeitStempel(offsetMs = 0) {
  return new Date(Date.now() + offsetMs).toISOString().slice(0, 19).replace('T', ' ');
}

// Der Blog-Editor erlaubt nur eine kleine Menge an HTML (fett, kursiv,
// Zwischentitel, Listen, Links, Absätze). Alles andere wird entfernt –
// serverseitig, damit kein Schad-HTML in die Datenbank gelangt.
//
// Sicherheitsprinzip: Erlaubte Tags werden NEU aufgebaut und dabei ALLE
// Attribute verworfen (Ausnahme: geprüftes href bei <a>). Dadurch kann kein
// Event-Handler (onerror, onclick …) und keine javascript:-URL überleben,
// egal wie das Tag geschrieben ist (auch "<img/src=x onerror=…>").
const ERLAUBTE_TAGS = new Set([
  'p', 'br', 'strong', 'b', 'em', 'i', 'u', 'h2', 'h3',
  'ul', 'ol', 'li', 'a', 'blockquote',
]);
// Tags, deren Inhalt (nicht nur das Tag) komplett entfernt wird.
const BLOCK_TAGS = new Set([
  'script', 'style', 'iframe', 'object', 'embed', 'form',
  'svg', 'math', 'textarea', 'noscript', 'template',
]);

function textEscapen(text) {
  return text.replace(/&(?!(?:[a-zA-Z][a-zA-Z0-9]*|#\d+|#x[0-9a-fA-F]+);)/g, '&amp;')
    .replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function hrefBereinigen(attribute) {
  const treffer = /href\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'>]+))/i.exec(attribute || '');
  if (!treffer) return '';
  const href = (treffer[2] ?? treffer[3] ?? treffer[4] ?? '').trim();
  if (/^(https?:\/\/|mailto:|tel:|\/|#)/i.test(href)) {
    return href.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '%3C').replace(/>/g, '%3E');
  }
  return '';
}

export function htmlBereinigen(html) {
  const s = String(html);
  let out = '';
  let i = 0;
  const n = s.length;

  while (i < n) {
    const lt = s.indexOf('<', i);
    if (lt === -1) { out += s.slice(i); break; }
    out += s.slice(i, lt); // Text zwischen Tags unverändert übernehmen (kommt als HTML-Entities)

    // Kommentare überspringen
    if (s.startsWith('<!--', lt)) {
      const ende = s.indexOf('-->', lt + 4);
      i = ende === -1 ? n : ende + 3;
      continue;
    }
    const gt = s.indexOf('>', lt);
    if (gt === -1) { out += textEscapen(s.slice(lt)); break; } // vereinzeltes "<"

    const roh = s.slice(lt, gt + 1);
    const treffer = /^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9]*)([^>]*)>$/.exec(roh);
    if (!treffer) { out += textEscapen(roh); i = gt + 1; continue; } // kein echtes Tag → als Text zeigen

    const schliessend = treffer[1] === '/';
    const tag = treffer[2].toLowerCase();
    const attribute = treffer[3] || '';

    if (!ERLAUBTE_TAGS.has(tag)) {
      if (!schliessend && BLOCK_TAGS.has(tag)) {
        // Gefährliches Element samt Inhalt entfernen
        const schluss = new RegExp('</\\s*' + tag + '\\s*>', 'i');
        const rest = s.slice(gt + 1);
        const cm = schluss.exec(rest);
        i = cm ? gt + 1 + cm.index + cm[0].length : n;
      } else {
        i = gt + 1; // nur das Tag entfernen, Inhalt bleibt
      }
      continue;
    }

    if (schliessend) {
      out += `</${tag}>`;
    } else if (tag === 'a') {
      const href = hrefBereinigen(attribute);
      out += href ? `<a href="${href}" rel="noopener">` : '<a>';
    } else if (tag === 'br') {
      out += '<br>';
    } else {
      out += `<${tag}>`;
    }
    i = gt + 1;
  }

  return out.trim();
}
