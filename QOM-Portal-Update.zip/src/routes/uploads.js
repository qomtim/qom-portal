// Bild-Uploads: nur Bilder, Grössenlimit, Dateinamen neu vergeben,
// automatische Optimierung (max. 2400 px + WebP-Variante).
import path from 'node:path';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import sharp from 'sharp';
import fastifyStatic from '@fastify/static';
import { config } from '../config.js';
import { audit } from '../db.js';
import { sichererVergleich } from '../security.js';
import { CSRF_COOKIE } from '../auth.js';
import { zugriffPruefen } from './editor.js';

const ERLAUBTE_FORMATE = new Set(['jpeg', 'png', 'webp', 'avif']);

// Verarbeitet ein hochgeladenes Bild (Optimierung + WebP-Variante) und legt es
// unter uploads/<slug>/ ab. Gibt die relativen URLs zurück.
// Wirft Error('FORMAT') bzw. Error('VERARBEITUNG') für saubere HTTP-Antworten.
export async function bildVerarbeiten(puffer, slug) {
  const SHARP_OPTS = { limitInputPixels: 80_000_000, failOn: 'error' };
  let meta;
  try {
    meta = await sharp(puffer, SHARP_OPTS).metadata();
  } catch {
    throw new Error('FORMAT');
  }
  if (!ERLAUBTE_FORMATE.has(meta.format)) throw new Error('FORMAT');

  const zielOrdner = path.join(config.uploadsVerzeichnis, slug);
  await fs.mkdir(zielOrdner, { recursive: true });
  const basisName = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}`;
  const alsPng = meta.format === 'png' || meta.hasAlpha;
  const endung = alsPng ? 'png' : 'jpg';
  try {
    const bild = sharp(puffer, SHARP_OPTS).rotate().resize({
      width: config.bildMaxPixel,
      height: config.bildMaxPixel,
      fit: 'inside',
      withoutEnlargement: true,
    });
    if (alsPng) {
      await bild.clone().png({ compressionLevel: 9 }).toFile(path.join(zielOrdner, `${basisName}.${endung}`));
    } else {
      await bild.clone().jpeg({ quality: 82, mozjpeg: true }).toFile(path.join(zielOrdner, `${basisName}.${endung}`));
    }
    await bild.clone().webp({ quality: 80 }).toFile(path.join(zielOrdner, `${basisName}.webp`));
  } catch {
    throw new Error('VERARBEITUNG');
  }
  return {
    dateiname: `${basisName}.${endung}`,
    url: `/uploads/${slug}/${basisName}.${endung}`,
    webp: `/uploads/${slug}/${basisName}.webp`,
  };
}

export async function uploadRouten(app) {
  // Ausgelieferte Bilder: Dateinamen sind zufällig → aggressiv cachen erlaubt
  app.register(fastifyStatic, {
    root: config.uploadsVerzeichnis,
    prefix: '/uploads/',
    decorateReply: false,
    maxAge: '365d',
    immutable: true,
    index: false,
    list: false,
  });

  app.post('/projekt/:slug/upload', {
    config: { rateLimit: { max: 60, timeWindow: '1 minute' } },
  }, async (request, reply) => {
    const zugriff = zugriffPruefen(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;

    // Multipart umgeht die globale CSRF-Prüfung → hier per Header prüfen
    const csrfHeader = request.headers['x-csrf-token'];
    const csrfCookie = request.cookies?.[CSRF_COOKIE];
    if (!csrfHeader || !csrfCookie || !sichererVergleich(csrfHeader, csrfCookie)) {
      return reply.code(403).send({ fehler: 'Sitzung abgelaufen. Bitte Seite neu laden.' });
    }

    const datei = await request.file();
    if (!datei) return reply.code(400).send({ fehler: 'Keine Datei erhalten.' });

    let puffer;
    try {
      puffer = await datei.toBuffer();
    } catch {
      return reply.code(413).send({ fehler: 'Das Bild ist zu gross (maximal 15 MB).' });
    }

    let ergebnis;
    try {
      ergebnis = await bildVerarbeiten(puffer, projekt.slug);
    } catch (e) {
      if (e.message === 'FORMAT') {
        return reply.code(415).send({ fehler: 'Bitte lade ein Bild hoch (JPG, PNG oder WebP).' });
      }
      return reply.code(415).send({ fehler: 'Das Bild konnte nicht verarbeitet werden. Bitte ein anderes Bild versuchen.' });
    }

    audit(request.nutzer.id, projekt.id, 'bild_hochgeladen', ergebnis.dateiname);
    return reply.send({ ok: true, url: ergebnis.url, webp: ergebnis.webp });
  });
}
