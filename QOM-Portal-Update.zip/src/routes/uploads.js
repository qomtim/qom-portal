// Bild-Uploads: nur Bilder, Grössenlimit, Dateinamen neu vergeben,
// automatische Optimierung (max. 2400 px + WebP-Variante).
import path from 'node:path';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import sharp from 'sharp';
import fastifyStatic from '@fastify/static';
import { config } from '../config.js';
import { audit } from '../db.js';
import { sichererVergleich } from '../security.js';
import { CSRF_COOKIE } from '../auth.js';
import { zugriffPruefen } from './editor.js';

const ERLAUBTE_FORMATE = new Set(['jpeg', 'png', 'webp', 'avif']);

export async function uploadRouten(app) {
  // Ausgelieferte Bilder: Dateinamen sind zufällig → aggressiv cachen erlaubt
  app.register(fastifyStatic, {
    root: config.uploadsVerzeichnis,
    prefix: '/uploads/',
    decorateReply: false,
    maxAge: '365d',
    immutable: true,
    index: false,
    list: false,
  });

  app.post('/projekt/:slug/upload', {
    config: { rateLimit: { max: 60, timeWindow: '1 minute' } },
  }, async (request, reply) => {
    const zugriff = zugriffPruefen(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;

    // Multipart umgeht die globale CSRF-Prüfung → hier per Header prüfen
    const csrfHeader = request.headers['x-csrf-token'];
    const csrfCookie = request.cookies?.[CSRF_COOKIE];
    if (!csrfHeader || !csrfCookie || !sichererVergleich(csrfHeader, csrfCookie)) {
      return reply.code(403).send({ fehler: 'Sitzung abgelaufen. Bitte Seite neu laden.' });
    }

    const datei = await request.file();
    if (!datei) return reply.code(400).send({ fehler: 'Keine Datei erhalten.' });

    let puffer;
    try {
      puffer = await datei.toBuffer();
    } catch {
      return reply.code(413).send({ fehler: 'Das Bild ist zu gross (maximal 15 MB).' });
    }

    // Schutz gegen "Bild-Bomben": begrenzt die zulässige Pixelmenge (nicht nur die Dateigrösse)
    const SHARP_OPTS = { limitInputPixels: 80_000_000, failOn: 'error' };

    // Formatprüfung anhand des tatsächlichen Inhalts, nicht des Dateinamens
    let meta;
    try {
      meta = await sharp(puffer, SHARP_OPTS).metadata();
    } catch {
      return reply.code(415).send({ fehler: 'Bitte lade ein Bild hoch (JPG, PNG oder WebP).' });
    }
    if (!ERLAUBTE_FORMATE.has(meta.format)) {
      return reply.code(415).send({ fehler: 'Dieses Format wird nicht unterstützt. Bitte JPG, PNG oder WebP verwenden.' });
    }

    const zielOrdner = path.join(config.uploadsVerzeichnis, projekt.slug);
    await fs.mkdir(zielOrdner, { recursive: true });
    const basisName = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}`;

    // Hauptdatei: PNG bleibt PNG (Transparenz), alles andere wird JPG
    const alsPng = meta.format === 'png' || meta.hasAlpha;
    const endung = alsPng ? 'png' : 'jpg';
    const hauptPfad = path.join(zielOrdner, `${basisName}.${endung}`);
    try {
      const bild = sharp(puffer, SHARP_OPTS).rotate().resize({
        width: config.bildMaxPixel,
        height: config.bildMaxPixel,
        fit: 'inside',
        withoutEnlargement: true,
      });
      if (alsPng) {
        await bild.clone().png({ compressionLevel: 9 }).toFile(hauptPfad);
      } else {
        await bild.clone().jpeg({ quality: 82, mozjpeg: true }).toFile(hauptPfad);
      }
      await bild.clone().webp({ quality: 80 }).toFile(path.join(zielOrdner, `${basisName}.webp`));
    } catch {
      return reply.code(415).send({ fehler: 'Das Bild konnte nicht verarbeitet werden. Bitte ein anderes Bild versuchen.' });
    }

    audit(request.nutzer.id, projekt.id, 'bild_hochgeladen', `${basisName}.${endung}`);
    return reply.send({
      ok: true,
      url: `/uploads/${projekt.slug}/${basisName}.${endung}`,
      webp: `/uploads/${projekt.slug}/${basisName}.webp`,
    });
  });
}
