// Blog-Verwaltung: Kunden schreiben eigene Beiträge (wenn für das Projekt aktiviert).
import { db, audit } from '../db.js';
import { htmlBereinigen, slugAusText } from '../security.js';
import { deployAusloesen } from '../webhook.js';
import { zugriffPruefen } from './editor.js';

function blogZugriff(request, reply) {
  const zugriff = zugriffPruefen(request, reply);
  if (!zugriff) return null;
  const { projekt, rolle } = zugriff;
  if (rolle === 'editor' && !projekt.blog_aktiv) {
    reply.code(404).view('fehler.njk', {
      titel: 'Seite nicht gefunden',
      meldung: 'Diese Seite gibt es nicht (mehr).',
      nutzer: request.nutzer,
    });
    return null;
  }
  return zugriff;
}

function beitragHolen(projektId, id) {
  return db.prepare(
    `SELECT p.*, u.name AS autor_name FROM posts p
       LEFT JOIN users u ON u.id = p.author_user_id
      WHERE p.id = ? AND p.project_id = ?`
  ).get(Number(id), projektId);
}

function eindeutigerSlug(projektId, wunsch, ausserId = 0) {
  let basis = slugAusText(wunsch);
  let kandidat = basis;
  let laufnummer = 2;
  while (db.prepare(
    `SELECT 1 FROM posts WHERE project_id = ? AND slug = ? AND id != ?`
  ).get(projektId, kandidat, ausserId)) {
    kandidat = `${basis}-${laufnummer++}`;
  }
  return kandidat;
}

export async function blogRouten(app) {
  app.get('/projekt/:slug/blog', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt, rolle } = zugriff;
    const beitraege = db.prepare(
      `SELECT p.*, u.name AS autor_name FROM posts p
         LEFT JOIN users u ON u.id = p.author_user_id
        WHERE p.project_id = ?
        ORDER BY COALESCE(p.published_at, p.created_at) DESC, p.id DESC`
    ).all(projekt.id);
    return reply.view('blog-liste.njk', {
      nutzer: request.nutzer, projekt, rolle, beitraege, csrf: request.csrfToken,
    });
  });

  app.get('/projekt/:slug/blog/neu', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt, rolle } = zugriff;
    return reply.view('blog-bearbeiten.njk', {
      nutzer: request.nutzer, projekt, rolle, beitrag: null, csrf: request.csrfToken,
    });
  });

  app.post('/projekt/:slug/blog/neu', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;
    const titel = String(request.body?.titel || '').trim() || 'Neuer Beitrag';
    const ergebnis = db.prepare(
      `INSERT INTO posts (project_id, title, slug, teaser, body_html, cover_url, status, author_user_id)
       VALUES (?, ?, ?, ?, ?, ?, 'draft', ?)`
    ).run(
      projekt.id,
      titel,
      eindeutigerSlug(projekt.id, titel),
      String(request.body?.teaser || '').trim(),
      htmlBereinigen(request.body?.body_html || ''),
      String(request.body?.cover_url || ''),
      request.nutzer.id,
    );
    audit(request.nutzer.id, projekt.id, 'beitrag_erstellt', titel);
    if (request.headers['x-requested-with'] === 'fetch') {
      return reply.send({ ok: true, id: ergebnis.lastInsertRowid });
    }
    return reply.redirect(`/projekt/${projekt.slug}/blog/${ergebnis.lastInsertRowid}`);
  });

  app.get('/projekt/:slug/blog/:id', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt, rolle } = zugriff;
    const beitrag = beitragHolen(projekt.id, request.params.id);
    if (!beitrag) {
      return reply.code(404).view('fehler.njk', {
        titel: 'Beitrag nicht gefunden',
        meldung: 'Diesen Beitrag gibt es nicht (mehr).',
        nutzer: request.nutzer,
      });
    }
    return reply.view('blog-bearbeiten.njk', {
      nutzer: request.nutzer, projekt, rolle, beitrag, csrf: request.csrfToken,
      veroeffentlicht: request.query.veroeffentlicht === '1',
      gespeichert: request.query.gespeichert === '1',
    });
  });

  function beitragSpeichern(request, projekt, beitrag) {
    const titel = String(request.body?.titel || '').trim() || beitrag.title;
    // Slug bleibt stabil, sobald der Beitrag einmal veröffentlicht war
    // (damit Links nicht brechen); bei Entwürfen folgt er dem Titel.
    const slug = beitrag.published_at ? beitrag.slug : eindeutigerSlug(projekt.id, titel, beitrag.id);
    db.prepare(
      `UPDATE posts SET title = ?, slug = ?, teaser = ?, body_html = ?, cover_url = ?,
              updated_at = datetime('now')
        WHERE id = ?`
    ).run(
      titel,
      slug,
      String(request.body?.teaser || '').trim(),
      htmlBereinigen(request.body?.body_html || ''),
      String(request.body?.cover_url || ''),
      beitrag.id,
    );
    return titel;
  }

  // Speichern + Veröffentlichen in einem Schritt (der grosse Knopf im Formular)
  app.post('/projekt/:slug/blog/:id/veroeffentlichen-mit-speichern', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;
    const beitrag = beitragHolen(projekt.id, request.params.id);
    if (!beitrag) return reply.code(404).send({ fehler: 'Beitrag nicht gefunden.' });

    const titel = beitragSpeichern(request, projekt, beitrag);
    db.prepare(
      `UPDATE posts SET status = 'published',
              published_at = COALESCE(published_at, datetime('now')),
              updated_at = datetime('now')
        WHERE id = ?`
    ).run(beitrag.id);
    audit(request.nutzer.id, projekt.id, 'beitrag_veroeffentlicht', titel);
    await deployAusloesen(projekt, request.nutzer.id);
    return reply.redirect(`/projekt/${projekt.slug}/blog/${beitrag.id}?veroeffentlicht=1`);
  });

  app.post('/projekt/:slug/blog/:id', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;
    const beitrag = beitragHolen(projekt.id, request.params.id);
    if (!beitrag) return reply.code(404).send({ fehler: 'Beitrag nicht gefunden.' });

    const titel = beitragSpeichern(request, projekt, beitrag);
    audit(request.nutzer.id, projekt.id, 'beitrag_gespeichert', titel);
    if (request.headers['x-requested-with'] === 'fetch') return reply.send({ ok: true });
    return reply.redirect(`/projekt/${projekt.slug}/blog/${beitrag.id}?gespeichert=1`);
  });

  app.post('/projekt/:slug/blog/:id/veroeffentlichen', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;
    const beitrag = beitragHolen(projekt.id, request.params.id);
    if (!beitrag) return reply.code(404).send({ fehler: 'Beitrag nicht gefunden.' });

    db.prepare(
      `UPDATE posts SET status = 'published',
              published_at = COALESCE(published_at, datetime('now')),
              updated_at = datetime('now')
        WHERE id = ?`
    ).run(beitrag.id);
    audit(request.nutzer.id, projekt.id, 'beitrag_veroeffentlicht', beitrag.title);
    const ergebnis = await deployAusloesen(projekt, request.nutzer.id);
    if (request.headers['x-requested-with'] === 'fetch') {
      return reply.send({ ok: true, deploy: ergebnis });
    }
    return reply.redirect(`/projekt/${projekt.slug}/blog/${beitrag.id}?veroeffentlicht=1`);
  });

  app.post('/projekt/:slug/blog/:id/zurueckziehen', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;
    const beitrag = beitragHolen(projekt.id, request.params.id);
    if (!beitrag) return reply.code(404).send({ fehler: 'Beitrag nicht gefunden.' });

    db.prepare(`UPDATE posts SET status = 'draft', updated_at = datetime('now') WHERE id = ?`).run(beitrag.id);
    audit(request.nutzer.id, projekt.id, 'beitrag_zurueckgezogen', beitrag.title);
    const ergebnis = await deployAusloesen(projekt, request.nutzer.id);
    if (request.headers['x-requested-with'] === 'fetch') {
      return reply.send({ ok: true, deploy: ergebnis });
    }
    return reply.redirect(`/projekt/${projekt.slug}/blog/${beitrag.id}`);
  });

  app.post('/projekt/:slug/blog/:id/loeschen', async (request, reply) => {
    const zugriff = blogZugriff(request, reply);
    if (!zugriff) return reply;
    const { projekt } = zugriff;
    const beitrag = beitragHolen(projekt.id, request.params.id);
    if (!beitrag) return reply.code(404).send({ fehler: 'Beitrag nicht gefunden.' });

    const warVeroeffentlicht = beitrag.status === 'published';
    db.prepare(`DELETE FROM posts WHERE id = ?`).run(beitrag.id);
    audit(request.nutzer.id, projekt.id, 'beitrag_geloescht', beitrag.title);
    if (warVeroeffentlicht) await deployAusloesen(projekt, request.nutzer.id);
    return reply.redirect(`/projekt/${projekt.slug}/blog`);
  });
}
