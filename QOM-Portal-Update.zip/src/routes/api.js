// Content-API für den Website-Build und die Live-Vorschau.
// Nur lesend, Token-geschützt, mit CORS (die Vorschau lädt Entwurfs-Daten
// direkt von der Kundenwebsite aus).
import { db, audit } from '../db.js';
import { config } from '../config.js';
import { sichererVergleich, slugAusText } from '../security.js';

const API_RATE_LIMIT = {
  config: { rateLimit: { max: 240, timeWindow: '1 minute' } },
};

// Prüft das globale Läufer-Token (für die Generierungs-Warteschlange).
function laeuferErlaubt(token) {
  return Boolean(config.runnerToken && token && sichererVergleich(token, config.runnerToken));
}

function projektMitToken(slug, token, version) {
  const projekt = db.prepare(`SELECT * FROM projects WHERE slug = ?`).get(String(slug));
  if (!projekt || !token) return null;
  const erwartet = version === 'draft' ? projekt.preview_token : projekt.api_token;
  return sichererVergleich(token, erwartet) ? projekt : null;
}

function jsonParsen(text, fallback) {
  try { return JSON.parse(text); } catch { return fallback; }
}

export async function apiRouten(app) {
  app.addHook('onSend', async (request, reply) => {
    if (request.url.startsWith('/api/')) {
      reply.header('access-control-allow-origin', '*');
      reply.header('cache-control', 'no-store');
    }
  });

  app.get('/api/v1/projects/:slug/content', API_RATE_LIMIT, async (request, reply) => {
    const version = request.query.version === 'draft' ? 'draft' : 'published';
    const projekt = projektMitToken(request.params.slug, request.query.token || request.headers['x-portal-token'], version);
    if (!projekt) return reply.code(401).send({ fehler: 'Ungültiges Token.' });

    const felderZeilen = db.prepare(
      `SELECT key, value_draft, value_published FROM fields WHERE project_id = ? ORDER BY sort, id`
    ).all(projekt.id);
    const felder = {};
    for (const zeile of felderZeilen) {
      felder[zeile.key] = version === 'draft' ? zeile.value_draft : zeile.value_published;
    }

    const sammlungen = {};
    const sammlungZeilen = db.prepare(
      `SELECT * FROM collections WHERE project_id = ? ORDER BY sort, id`
    ).all(projekt.id);
    for (const sammlung of sammlungZeilen) {
      const items = db.prepare(
        `SELECT data_draft, data_published, geloescht_draft FROM collection_items
          WHERE collection_id = ? ORDER BY sort, id`
      ).all(sammlung.id);
      const eintraege = [];
      for (const item of items) {
        if (version === 'draft') {
          if (item.geloescht_draft) continue;
          eintraege.push(jsonParsen(item.data_draft, {}));
        } else {
          if (item.data_published === '{}') continue; // nie veröffentlicht
          eintraege.push(jsonParsen(item.data_published, {}));
        }
      }
      sammlungen[sammlung.key] = { label: sammlung.label, eintraege };
    }

    // Bereiche/Seiten: sichtbar ja/nein (für Ein-/Ausblenden auf der Website)
    const bereiche = {};
    const bereichZeilen = db.prepare(
      `SELECT key, label, sichtbar_draft, sichtbar_published FROM sections WHERE project_id = ? ORDER BY sort, id`
    ).all(projekt.id);
    for (const b of bereichZeilen) {
      bereiche[b.key] = {
        label: b.label,
        sichtbar: Boolean(version === 'draft' ? b.sichtbar_draft : b.sichtbar_published),
      };
    }

    return {
      projekt: { name: projekt.name, slug: projekt.slug, logo_url: projekt.logo_url },
      stand: version,
      felder,
      sammlungen,
      bereiche,
      generiert_am: new Date().toISOString(),
    };
  });

  app.get('/api/v1/projects/:slug/posts', API_RATE_LIMIT, async (request, reply) => {
    const version = request.query.version === 'draft' ? 'draft' : 'published';
    const projekt = projektMitToken(request.params.slug, request.query.token || request.headers['x-portal-token'], version);
    if (!projekt) return reply.code(401).send({ fehler: 'Ungültiges Token.' });

    const filter = version === 'draft' ? '' : `AND status = 'published'`;
    const beitraege = db.prepare(
      `SELECT title, slug, cover_url, teaser, body_html, status, published_at
         FROM posts WHERE project_id = ? ${filter}
        ORDER BY COALESCE(published_at, created_at) DESC, id DESC`
    ).all(projekt.id);

    return {
      beitraege: beitraege.map((beitrag) => ({
        titel: beitrag.title,
        slug: beitrag.slug,
        titelbild: beitrag.cover_url,
        teaser: beitrag.teaser,
        inhalt_html: beitrag.body_html,
        status: beitrag.status,
        veroeffentlicht_am: beitrag.published_at,
      })),
    };
  });

  // Kennzahlen-Ingest: n8n schickt periodisch die Meta-Ads-Zahlen herein.
  // Eigenes Schreib-Token (metrics_token), getrennt vom Lese-Token.
  const INGEST_RATE_LIMIT = { config: { rateLimit: { max: 120, timeWindow: '1 minute' } } };
  app.post('/api/v1/projects/:slug/metrics', INGEST_RATE_LIMIT, async (request, reply) => {
    const projekt = db.prepare(`SELECT * FROM projects WHERE slug = ?`).get(String(request.params.slug));
    const token = request.query.token || request.headers['x-metrics-token'];
    if (!projekt || !token || !projekt.metrics_token || !sichererVergleich(token, projekt.metrics_token)) {
      return reply.code(401).send({ fehler: 'Ungültiges Token.' });
    }
    const b = request.body || {};
    const z = (wert) => (Number.isFinite(Number(wert)) ? Number(wert) : 0);
    const tag = /^\d{4}-\d{2}-\d{2}$/.test(String(b.tag || '')) ? b.tag : new Date().toISOString().slice(0, 10);

    const spend = z(b.spend);
    const impressions = z(b.impressions);
    const clicks = z(b.clicks);
    const purchases = z(b.purchases);
    // Abgeleitete Werte selbst berechnen, wenn n8n sie nicht mitschickt
    const cpm = b.cpm != null ? z(b.cpm) : (impressions > 0 ? (spend / impressions) * 1000 : 0);
    const ctr = b.ctr != null ? z(b.ctr) : (impressions > 0 ? (clicks / impressions) * 100 : 0);
    const cpc = b.cpc != null ? z(b.cpc) : (clicks > 0 ? spend / clicks : 0);
    const cpp = b.cost_per_purchase != null ? z(b.cost_per_purchase) : (purchases > 0 ? spend / purchases : 0);
    let zusatz = '{}';
    try { if (b.zusatz && typeof b.zusatz === 'object') zusatz = JSON.stringify(b.zusatz); } catch { zusatz = '{}'; }

    db.prepare(
      `INSERT INTO ad_metrics (project_id, tag, spend, impressions, reach, clicks, cpm, ctr, cpc,
                               purchases, cost_per_purchase, results, leads, waehrung, zusatz, updated_at)
       VALUES (@pid, @tag, @spend, @impressions, @reach, @clicks, @cpm, @ctr, @cpc,
               @purchases, @cpp, @results, @leads, @waehrung, @zusatz, datetime('now'))
       ON CONFLICT(project_id, tag) DO UPDATE SET
         spend=@spend, impressions=@impressions, reach=@reach, clicks=@clicks, cpm=@cpm, ctr=@ctr, cpc=@cpc,
         purchases=@purchases, cost_per_purchase=@cpp, results=@results, leads=@leads,
         waehrung=@waehrung, zusatz=@zusatz, updated_at=datetime('now')`
    ).run({
      pid: projekt.id, tag, spend, impressions, reach: z(b.reach), clicks, cpm, ctr, cpc,
      purchases, cpp, results: z(b.results), leads: z(b.leads),
      waehrung: (String(b.waehrung || 'CHF').slice(0, 8)) || 'CHF', zusatz,
    });
    return { ok: true, tag };
  });

  // ---- Generierungs-Warteschlange (nur für den Server-Läufer) ----------

  // Offene Aufträge abholen (Status 'bereit')
  app.get('/api/v1/jobs', API_RATE_LIMIT, async (request, reply) => {
    if (!laeuferErlaubt(request.query.token || request.headers['x-runner-token'])) {
      return reply.code(401).send({ fehler: 'Ungültiges Läufer-Token.' });
    }
    const jobs = db.prepare(
      `SELECT id, slug, name, projekt_typ, website_url, alte_seite_url, google_drive_url, bemerkungen,
              aenderungswunsch, meta_ad_account_id, api_token, preview_token, generierung_am
         FROM projects WHERE generierung_status = 'bereit' ORDER BY generierung_am`
    ).all();
    // Bild-Ablage pro Projekt mitliefern (absolute URLs, damit der Läufer sie
    // direkt laden/verlinken kann). Grundlage für die Sektionen der Website.
    const basis = String(config.baseUrl || '').replace(/\/+$/, '');
    const bilderStmt = db.prepare(`SELECT url, beschreibung FROM assets WHERE project_id = ? ORDER BY created_at`);
    for (const job of jobs) {
      job.bilder = bilderStmt.all(job.id).map((b) => ({ url: basis + b.url, beschreibung: b.beschreibung }));
      delete job.id;
    }
    return { jobs };
  });

  // Status eines Auftrags melden (in_arbeit | fertig | fehler)
  app.post('/api/v1/jobs/:slug/status', API_RATE_LIMIT, async (request, reply) => {
    if (!laeuferErlaubt(request.query.token || request.headers['x-runner-token'])) {
      return reply.code(401).send({ fehler: 'Ungültiges Läufer-Token.' });
    }
    const projekt = db.prepare(`SELECT id FROM projects WHERE slug = ?`).get(String(request.params.slug));
    if (!projekt) return reply.code(404).send({ fehler: 'Projekt nicht gefunden.' });
    const erlaubt = ['bereit', 'in_arbeit', 'fertig', 'fehler'];
    const roh = String(request.body?.status || '');
    const status = erlaubt.includes(roh) ? roh : 'fehler';
    const meldung = String(request.body?.meldung || '').slice(0, 300);
    db.prepare(`UPDATE projects SET generierung_status = ?, generierung_am = datetime('now') WHERE id = ?`)
      .run(meldung ? `${status}: ${meldung}` : status, projekt.id);
    audit(null, projekt.id, 'generierung_status', `${status} ${meldung}`.trim());

    // Fortschritt in den Verbesserungs-Chat schreiben (für die Bearbeiter sichtbar)
    let chatText = '';
    if (status === 'fertig') chatText = meldung || 'Fertig! Die Vorschau ist aktualisiert – lade sie mit Strg+F5 neu.';
    else if (status === 'fehler') chatText = 'Da ist etwas schiefgelaufen' + (meldung ? ': ' + meldung : '.');
    if (chatText) {
      db.prepare(`INSERT INTO gen_chat (project_id, rolle, text, autor) VALUES (?, 'system', ?, 'Claude')`)
        .run(projekt.id, chatText.slice(0, 1000));
    }
    return { ok: true };
  });

  // Generierte Inhalte ins Portal schreiben, damit die neue Seite sofort
  // im Editor bearbeitbar ist. Legt Felder/Sammlungen/Bereiche an bzw. füllt sie.
  app.post('/api/v1/jobs/:slug/content', API_RATE_LIMIT, async (request, reply) => {
    if (!laeuferErlaubt(request.query.token || request.headers['x-runner-token'])) {
      return reply.code(401).send({ fehler: 'Ungültiges Läufer-Token.' });
    }
    const projekt = db.prepare(`SELECT id FROM projects WHERE slug = ?`).get(String(request.params.slug));
    if (!projekt) return reply.code(404).send({ fehler: 'Projekt nicht gefunden.' });
    const body = request.body || {};
    const feldTyp = (t) => (['text', 'textarea', 'image'].includes(t) ? t : 'text');
    const saeubereKey = (k) => slugAusText(String(k || '')).replace(/-/g, '_').slice(0, 60);

    const felderUpsert = db.prepare(
      `INSERT INTO fields (project_id, key, group_label, field_label, type, value_draft, value_published, editable_by_editor, sort)
       VALUES (@pid, @key, @group, @label, @type, @val, @val, 1, @sort)
       ON CONFLICT(project_id, key) DO UPDATE SET
         group_label = excluded.group_label, field_label = excluded.field_label, type = excluded.type,
         value_draft = excluded.value_draft, value_published = excluded.value_published`
    );
    const tx = db.transaction(() => {
      let sort = 0;
      for (const f of Array.isArray(body.felder) ? body.felder.slice(0, 300) : []) {
        const key = saeubereKey(f.key);
        if (!key) continue;
        felderUpsert.run({
          pid: projekt.id, key, group: String(f.group || 'Inhalte').slice(0, 120),
          label: String(f.label || key).slice(0, 200), type: feldTyp(f.type),
          val: String(f.value ?? '').slice(0, 20000), sort: ++sort,
        });
      }
      // Bereiche (Seiten ein-/ausblenden)
      const bereichUpsert = db.prepare(
        `INSERT INTO sections (project_id, key, label, sort) VALUES (?, ?, ?, ?)
         ON CONFLICT(project_id, key) DO UPDATE SET label = excluded.label`
      );
      let bs = 0;
      for (const b of Array.isArray(body.bereiche) ? body.bereiche.slice(0, 100) : []) {
        const key = saeubereKey(b.key);
        if (key) bereichUpsert.run(projekt.id, key, String(b.label || key).slice(0, 200), ++bs);
      }
    });
    tx();
    audit(null, projekt.id, 'generierung_inhalt', `${(body.felder || []).length} Felder`);
    return { ok: true };
  });

  app.get('/api/v1/projects/:slug/posts/:postslug', API_RATE_LIMIT, async (request, reply) => {
    const version = request.query.version === 'draft' ? 'draft' : 'published';
    const projekt = projektMitToken(request.params.slug, request.query.token || request.headers['x-portal-token'], version);
    if (!projekt) return reply.code(401).send({ fehler: 'Ungültiges Token.' });

    const filter = version === 'draft' ? '' : `AND status = 'published'`;
    const beitrag = db.prepare(
      `SELECT title, slug, cover_url, teaser, body_html, status, published_at
         FROM posts WHERE project_id = ? AND slug = ? ${filter}`
    ).get(projekt.id, request.params.postslug);
    if (!beitrag) return reply.code(404).send({ fehler: 'Beitrag nicht gefunden.' });

    return {
      titel: beitrag.title,
      slug: beitrag.slug,
      titelbild: beitrag.cover_url,
      teaser: beitrag.teaser,
      inhalt_html: beitrag.body_html,
      status: beitrag.status,
      veroeffentlicht_am: beitrag.published_at,
    };
  });
}
