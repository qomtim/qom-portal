// QOM-Adminbereich (nur Geschäftsführer): Projekte, Felder, Sammlungen,
// Bereiche, Konten, Tokens, Generierung, Audit-Log.
// Strikt getrennt vom Editor-Bereich – jede Route prüft die Rolle serverseitig.
import path from 'node:path';
import fs from 'node:fs/promises';
import { db, audit } from '../db.js';
import { config } from '../config.js';
import { neuesToken, slugAusText, sqliteZeitStempel, passwortHashen, tokenHash, sichererVergleich } from '../security.js';
import { istGeschaeftsfuehrer, CSRF_COOKIE } from '../auth.js';
import { mailSenden, mailKonfiguriert } from '../mailer.js';
import { generierungAusloesen } from '../webhook.js';
import { bildVerarbeiten } from './uploads.js';

function adminErzwingen(request, reply) {
  if (!request.nutzer) {
    reply.redirect('/login');
    return false;
  }
  if (!istGeschaeftsfuehrer(request.nutzer)) {
    reply.code(404).view('fehler.njk', {
      titel: 'Seite nicht gefunden',
      meldung: 'Diese Seite gibt es nicht (mehr).',
      nutzer: request.nutzer,
    });
    return false;
  }
  return true;
}

function projektOder404(request, reply) {
  const projekt = db.prepare(`SELECT * FROM projects WHERE slug = ?`).get(request.params.slug);
  if (!projekt) {
    reply.code(404).view('fehler.njk', {
      titel: 'Projekt nicht gefunden',
      meldung: 'Dieses Projekt gibt es nicht (mehr).',
      nutzer: request.nutzer,
    });
    return null;
  }
  return projekt;
}

export function schemaTextParsen(text) {
  const zeilen = String(text || '').split('\n').map((zeile) => zeile.trim()).filter(Boolean);
  const schema = [];
  for (const zeile of zeilen) {
    const teile = zeile.split('|').map((teil) => teil.trim());
    const key = slugAusText(teile[0] || '').replace(/-/g, '_');
    if (!key) continue;
    const label = teile[1] || teile[0];
    const typ = ['text', 'textarea', 'image'].includes(teile[2]) ? teile[2] : 'text';
    schema.push({ key, label, type: typ });
  }
  return schema;
}

export function schemaAlsText(schemaJson) {
  try {
    return JSON.parse(schemaJson).map((spalte) => `${spalte.key} | ${spalte.label} | ${spalte.type}`).join('\n');
  } catch {
    return '';
  }
}

const VORLAGE_FELDER = [
  ['startseite_titel', 'Startseite – Titelbereich', 'Titel', 'text'],
  ['startseite_untertitel', 'Startseite – Titelbereich', 'Untertitel', 'textarea'],
  ['startseite_titelbild', 'Startseite – Titelbereich', 'Titelbild', 'image'],
  ['startseite_knopf_text', 'Startseite – Titelbereich', 'Beschriftung Knopf', 'text'],
  ['einleitung_titel', 'Startseite – Einleitung', 'Titel', 'text'],
  ['einleitung_text', 'Startseite – Einleitung', 'Text', 'textarea'],
  ['kontakt_email', 'Kontakt', 'E-Mail-Adresse', 'text'],
  ['kontakt_telefon', 'Kontakt', 'Telefon', 'text'],
  ['kontakt_adresse', 'Kontakt', 'Adresse', 'textarea'],
  ['logo', 'Allgemein', 'Logo', 'image'],
  ['footer_text', 'Allgemein', 'Text in der Fusszeile', 'textarea'],
];

const VORLAGE_SAMMLUNGEN = [
  ['team', 'Team', [
    { key: 'name', label: 'Name', type: 'text' },
    { key: 'funktion', label: 'Funktion', type: 'text' },
    { key: 'foto', label: 'Foto', type: 'image' },
    { key: 'beschreibung', label: 'Beschreibung', type: 'textarea' },
  ]],
  ['referenzen', 'Referenzen', [
    { key: 'titel', label: 'Titel', type: 'text' },
    { key: 'beschreibung', label: 'Beschreibung', type: 'textarea' },
    { key: 'bild', label: 'Bild', type: 'image' },
    { key: 'link', label: 'Link (Adresse der Website)', type: 'text' },
  ]],
  ['kundenstimmen', 'Kundenstimmen', [
    { key: 'zitat', label: 'Zitat', type: 'textarea' },
    { key: 'autor', label: 'Name', type: 'text' },
    { key: 'firma', label: 'Firma / Ort', type: 'text' },
  ]],
  ['kennzahlen', 'Kennzahlen', [
    { key: 'wert', label: 'Zahl (z.B. "25+")', type: 'text' },
    { key: 'beschriftung', label: 'Beschriftung', type: 'text' },
  ]],
  ['faq', 'Häufige Fragen', [
    { key: 'frage', label: 'Frage', type: 'text' },
    { key: 'antwort', label: 'Antwort', type: 'textarea' },
  ]],
];

// Bereiche, die der Kunde ein-/ausblenden kann (matchen die Sammlungen + Blog)
const VORLAGE_BEREICHE = [
  ['team', 'Team-Bereich'],
  ['referenzen', 'Referenzen'],
  ['kundenstimmen', 'Kundenstimmen'],
  ['kennzahlen', 'Kennzahlen'],
  ['faq', 'Häufige Fragen'],
  ['blog', 'Blog'],
];

export function vorlageAnwenden(projektId) {
  const feldEinfuegen = db.prepare(
    `INSERT INTO fields (project_id, key, group_label, field_label, type, sort) VALUES (?, ?, ?, ?, ?, ?)`
  );
  VORLAGE_FELDER.forEach(([key, gruppe, label, typ], index) => {
    feldEinfuegen.run(projektId, key, gruppe, label, typ, index + 1);
  });
  const sammlungEinfuegen = db.prepare(
    `INSERT INTO collections (project_id, key, label, item_schema, sort) VALUES (?, ?, ?, ?, ?)`
  );
  VORLAGE_SAMMLUNGEN.forEach(([key, label, schema], index) => {
    sammlungEinfuegen.run(projektId, key, label, JSON.stringify(schema), index + 1);
  });
  const bereichEinfuegen = db.prepare(
    `INSERT INTO sections (project_id, key, label, sort) VALUES (?, ?, ?, ?)`
  );
  VORLAGE_BEREICHE.forEach(([key, label], index) => {
    bereichEinfuegen.run(projektId, key, label, index + 1);
  });
}

// Kunden-Umfang als Ein-Klick-Voreinstellung
function umfangAnwenden(projekt, modus) {
  const setzeText = db.prepare(`UPDATE fields SET editable_by_editor = 1 WHERE project_id = ? AND type != 'image'`);
  const setzeAlleFelder = db.prepare(`UPDATE fields SET editable_by_editor = 1 WHERE project_id = ?`);
  const setzeAlleSammlungen = db.prepare(`UPDATE collections SET editable_by_editor = 1 WHERE project_id = ?`);
  if (modus === 'nur-texte') {
    db.prepare(`UPDATE projects SET kunde_darf_bilder = 0, kunde_darf_sammlungen = 0, kunde_darf_seiten_schalten = 0 WHERE id = ?`).run(projekt.id);
    setzeText.run(projekt.id);
  } else if (modus === 'texte-bilder') {
    db.prepare(`UPDATE projects SET kunde_darf_bilder = 1, kunde_darf_sammlungen = 0, kunde_darf_seiten_schalten = 0 WHERE id = ?`).run(projekt.id);
    setzeAlleFelder.run(projekt.id);
  } else if (modus === 'alles') {
    db.prepare(`UPDATE projects SET kunde_darf_bilder = 1, kunde_darf_sammlungen = 1, kunde_darf_seiten_schalten = 1, blog_aktiv = 1 WHERE id = ?`).run(projekt.id);
    setzeAlleFelder.run(projekt.id);
    setzeAlleSammlungen.run(projekt.id);
  }
}

export async function adminRouten(app) {
  // ---- Übersicht & Projekt anlegen -------------------------------------

  app.get('/admin', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekte = db.prepare(`
      SELECT p.*,
        (SELECT COUNT(*) FROM memberships m WHERE m.project_id = p.id) AS anzahl_nutzer,
        (SELECT COUNT(*) FROM fields f WHERE f.project_id = p.id) AS anzahl_felder,
        (SELECT COUNT(*) FROM posts po WHERE po.project_id = p.id) AS anzahl_beitraege
      FROM projects p ORDER BY p.created_at DESC, p.name
    `).all();
    return reply.view('admin/uebersicht.njk', {
      nutzer: request.nutzer, projekte, csrf: request.csrfToken,
      // Läufer-Modell: der Server-Läufer holt "bereit"-Aufträge selbst ab,
      // darum ist die Generierung immer auslösbar (kein Webhook nötig).
      generierungBereit: true,
    });
  });

  app.post('/admin/projekte/neu', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const name = String(request.body?.name || '').trim();
    if (!name) return reply.redirect('/admin');
    let slug = slugAusText(request.body?.slug || name);
    while (db.prepare(`SELECT 1 FROM projects WHERE slug = ?`).get(slug)) slug = `${slug}-2`;

    const typ = ['website', 'ads', 'beides'].includes(request.body?.projekt_typ) ? request.body.projekt_typ : 'website';
    const ergebnis = db.prepare(
      `INSERT INTO projects (slug, name, website_url, alte_seite_url, google_drive_url, bemerkungen,
                             deploy_webhook_url, api_token, preview_token, metrics_token, projekt_typ, blog_aktiv)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      slug, name,
      String(request.body?.website_url || '').trim(),
      String(request.body?.alte_seite_url || '').trim(),
      String(request.body?.google_drive_url || '').trim(),
      String(request.body?.bemerkungen || '').trim(),
      String(request.body?.deploy_webhook_url || '').trim(),
      neuesToken(), neuesToken(), neuesToken(),
      typ,
      request.body?.blog_aktiv ? 1 : 0,
    );
    const projektId = ergebnis.lastInsertRowid;
    if (request.body?.vorlage === 'qom-standard') vorlageAnwenden(projektId);
    const umfang = request.body?.umfang;
    if (['nur-texte', 'texte-bilder', 'alles'].includes(umfang)) {
      umfangAnwenden({ id: projektId }, umfang);
    }
    audit(request.nutzer.id, projektId, 'projekt_erstellt', name);

    // Optional gleich an Claude schicken
    if (request.body?.gleich_generieren) {
      const projekt = db.prepare(`SELECT * FROM projects WHERE id = ?`).get(projektId);
      await generierungAusloesen(projekt, request.nutzer);
    }
    return reply.redirect(`/admin/projekt/${slug}`);
  });

  // ---- Einstellungen ----------------------------------------------------

  app.get('/admin/projekt/:slug', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    return reply.view('admin/projekt.njk', {
      nutzer: request.nutzer, projekt, csrf: request.csrfToken,
      baseUrl: config.baseUrl,
      generierungBereit: true,
      bilder: db.prepare(`SELECT id, dateiname, url, beschreibung FROM assets WHERE project_id = ? ORDER BY created_at`).all(projekt.id),
      gespeichert: request.query.gespeichert === '1',
      rotiert: request.query.rotiert === '1',
      umfangGesetzt: request.query.umfang || '',
      generiert: request.query.generiert === '1',
      bildFehler: request.query.bild_fehler || '',
      loeschenFehler: request.query.loeschen_fehler === '1',
    });
  });

  app.post('/admin/projekt/:slug/einstellungen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const typ = ['website', 'ads', 'beides'].includes(request.body?.projekt_typ) ? request.body.projekt_typ : projekt.projekt_typ;
    db.prepare(
      `UPDATE projects SET name = ?, projekt_typ = ?, website_url = ?, alte_seite_url = ?, google_drive_url = ?,
              bemerkungen = ?, deploy_webhook_url = ?, generierung_webhook_url = ?, freigabe_webhook_url = ?, logo_url = ?,
              meta_ad_account_id = ?, meta_konto_name = ?,
              blog_aktiv = ?, kunde_darf_bilder = ?, kunde_darf_sammlungen = ?, kunde_darf_seiten_schalten = ?
        WHERE id = ?`
    ).run(
      String(request.body?.name || projekt.name).trim(),
      typ,
      String(request.body?.website_url || '').trim(),
      String(request.body?.alte_seite_url || '').trim(),
      String(request.body?.google_drive_url || '').trim(),
      String(request.body?.bemerkungen || '').trim(),
      String(request.body?.deploy_webhook_url || '').trim(),
      String(request.body?.generierung_webhook_url || '').trim(),
      String(request.body?.freigabe_webhook_url || '').trim(),
      String(request.body?.logo_url || '').trim(),
      String(request.body?.meta_ad_account_id || '').trim().slice(0, 60),
      String(request.body?.meta_konto_name || '').trim().slice(0, 120),
      request.body?.blog_aktiv ? 1 : 0,
      request.body?.kunde_darf_bilder ? 1 : 0,
      request.body?.kunde_darf_sammlungen ? 1 : 0,
      request.body?.kunde_darf_seiten_schalten ? 1 : 0,
      projekt.id,
    );
    audit(request.nutzer.id, projekt.id, 'projekt_geaendert', '');
    return reply.redirect(`/admin/projekt/${projekt.slug}?gespeichert=1`);
  });

  app.post('/admin/projekt/:slug/umfang', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const modus = request.body?.modus;
    if (['nur-texte', 'texte-bilder', 'alles'].includes(modus)) {
      umfangAnwenden(projekt, modus);
      audit(request.nutzer.id, projekt.id, 'umfang_gesetzt', modus);
    }
    return reply.redirect(`/admin/projekt/${projekt.slug}?umfang=${modus}`);
  });

  app.post('/admin/projekt/:slug/generieren', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    await generierungAusloesen(projekt, request.nutzer);
    return reply.redirect(`/admin/projekt/${projekt.slug}?generiert=1`);
  });

  // ---- Bild-Ablage (Grundlage für die Website-Generierung) -------------
  // Upload läuft per fetch → CSRF hier über den Header (Multipart umgeht die
  // globale Prüfung). Antwort ist JSON, damit die Seite ohne Reload nachlädt.
  app.post('/admin/projekt/:slug/bilder', {
    config: { rateLimit: { max: 60, timeWindow: '1 minute' } },
  }, async (request, reply) => {
    if (!request.nutzer || !istGeschaeftsfuehrer(request.nutzer)) {
      return reply.code(403).send({ fehler: 'Kein Zugriff.' });
    }
    const projekt = db.prepare(`SELECT id, slug FROM projects WHERE slug = ?`).get(request.params.slug);
    if (!projekt) return reply.code(404).send({ fehler: 'Projekt nicht gefunden.' });

    const csrfHeader = request.headers['x-csrf-token'];
    const csrfCookie = request.cookies?.[CSRF_COOKIE];
    if (!csrfHeader || !csrfCookie || !sichererVergleich(csrfHeader, csrfCookie)) {
      return reply.code(403).send({ fehler: 'Sitzung abgelaufen. Bitte Seite neu laden.' });
    }

    const datei = await request.file();
    if (!datei) return reply.code(400).send({ fehler: 'Keine Datei erhalten.' });
    const beschreibung = String(request.query.beschreibung || '').trim().slice(0, 120);

    let puffer;
    try {
      puffer = await datei.toBuffer();
    } catch {
      return reply.code(413).send({ fehler: 'Das Bild ist zu gross (maximal 15 MB).' });
    }

    let ergebnis;
    try {
      ergebnis = await bildVerarbeiten(puffer, projekt.slug);
    } catch (e) {
      if (e.message === 'FORMAT') return reply.code(415).send({ fehler: 'Bitte lade ein Bild hoch (JPG, PNG oder WebP).' });
      return reply.code(415).send({ fehler: 'Das Bild konnte nicht verarbeitet werden. Bitte ein anderes versuchen.' });
    }
    db.prepare(`INSERT INTO assets (project_id, dateiname, url, beschreibung) VALUES (?, ?, ?, ?)`)
      .run(projekt.id, ergebnis.dateiname, ergebnis.url, beschreibung);
    audit(request.nutzer.id, projekt.id, 'ablage_bild_hochgeladen', ergebnis.dateiname);
    return reply.send({ ok: true, url: ergebnis.url });
  });

  app.post('/admin/projekt/:slug/bilder/:id/loeschen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const asset = db.prepare(`SELECT * FROM assets WHERE id = ? AND project_id = ?`).get(request.params.id, projekt.id);
    if (asset) {
      const basis = asset.dateiname.replace(/\.[^.]+$/, '');
      const ordner = path.join(config.uploadsVerzeichnis, projekt.slug);
      await fs.rm(path.join(ordner, asset.dateiname), { force: true }).catch(() => {});
      await fs.rm(path.join(ordner, `${basis}.webp`), { force: true }).catch(() => {});
      db.prepare(`DELETE FROM assets WHERE id = ?`).run(asset.id);
      audit(request.nutzer.id, projekt.id, 'ablage_bild_geloescht', asset.dateiname);
    }
    return reply.redirect(`/admin/projekt/${projekt.slug}#bilder`);
  });

  app.post('/admin/projekt/:slug/bilder/:id/beschreibung', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const beschreibung = String(request.body?.beschreibung || '').trim().slice(0, 120);
    db.prepare(`UPDATE assets SET beschreibung = ? WHERE id = ? AND project_id = ?`)
      .run(beschreibung, request.params.id, projekt.id);
    audit(request.nutzer.id, projekt.id, 'ablage_bild_beschriftet', String(request.params.id));
    return reply.redirect(`/admin/projekt/${projekt.slug}#bilder`);
  });

  app.post('/admin/projekt/:slug/token-rotieren', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const art = request.body?.art === 'preview' ? 'preview_token'
      : request.body?.art === 'metrics' ? 'metrics_token' : 'api_token';
    db.prepare(`UPDATE projects SET ${art} = ? WHERE id = ?`).run(neuesToken(), projekt.id);
    audit(request.nutzer.id, projekt.id, 'token_rotiert', art);
    return reply.redirect(`/admin/projekt/${projekt.slug}?rotiert=1`);
  });

  app.post('/admin/projekt/:slug/loeschen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    if (String(request.body?.bestaetigung || '') !== projekt.slug) {
      return reply.redirect(`/admin/projekt/${projekt.slug}?loeschen_fehler=1`);
    }
    db.prepare(`DELETE FROM projects WHERE id = ?`).run(projekt.id);
    await fs.rm(path.join(config.uploadsVerzeichnis, projekt.slug), { recursive: true, force: true }).catch(() => {});
    audit(request.nutzer.id, null, 'projekt_geloescht', projekt.name);
    return reply.redirect('/admin');
  });

  // ---- Felder verwalten -------------------------------------------------

  app.get('/admin/projekt/:slug/felder', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const felder = db.prepare(`SELECT * FROM fields WHERE project_id = ? ORDER BY sort, id`).all(projekt.id);
    return reply.view('admin/felder.njk', { nutzer: request.nutzer, projekt, felder, csrf: request.csrfToken });
  });

  app.post('/admin/projekt/:slug/felder/neu', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const key = slugAusText(request.body?.key || request.body?.field_label || '').replace(/-/g, '_');
    if (!key) return reply.redirect(`/admin/projekt/${projekt.slug}/felder`);
    const maxSort = db.prepare(`SELECT COALESCE(MAX(sort), 0) AS m FROM fields WHERE project_id = ?`).get(projekt.id).m;
    db.prepare(
      `INSERT OR IGNORE INTO fields (project_id, key, group_label, field_label, type, editable_by_editor, sort)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(
      projekt.id, key,
      String(request.body?.group_label || '').trim(),
      String(request.body?.field_label || key).trim(),
      ['text', 'textarea', 'image'].includes(request.body?.type) ? request.body.type : 'text',
      request.body?.editable_by_editor ? 1 : 0,
      maxSort + 1,
    );
    audit(request.nutzer.id, projekt.id, 'feld_erstellt', key);
    return reply.redirect(`/admin/projekt/${projekt.slug}/felder`);
  });

  app.post('/admin/projekt/:slug/felder/:id/loeschen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const feld = db.prepare(`SELECT * FROM fields WHERE id = ? AND project_id = ?`).get(Number(request.params.id), projekt.id);
    if (feld) {
      db.prepare(`DELETE FROM fields WHERE id = ?`).run(feld.id);
      audit(request.nutzer.id, projekt.id, 'feld_geloescht', feld.key);
    }
    return reply.redirect(`/admin/projekt/${projekt.slug}/felder`);
  });

  app.post('/admin/projekt/:slug/felder/:id', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const feld = db.prepare(`SELECT * FROM fields WHERE id = ? AND project_id = ?`).get(Number(request.params.id), projekt.id);
    if (!feld) return reply.redirect(`/admin/projekt/${projekt.slug}/felder`);
    db.prepare(
      `UPDATE fields SET group_label = ?, field_label = ?, type = ?, editable_by_editor = ?, sort = ? WHERE id = ?`
    ).run(
      String(request.body?.group_label ?? feld.group_label).trim(),
      String(request.body?.field_label ?? feld.field_label).trim(),
      ['text', 'textarea', 'image'].includes(request.body?.type) ? request.body.type : feld.type,
      request.body?.editable_by_editor ? 1 : 0,
      Number(request.body?.sort ?? feld.sort) || feld.sort,
      feld.id,
    );
    audit(request.nutzer.id, projekt.id, 'feld_geaendert', feld.key);
    return reply.redirect(`/admin/projekt/${projekt.slug}/felder`);
  });

  // ---- Sammlungen verwalten --------------------------------------------

  app.get('/admin/projekt/:slug/sammlungen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const sammlungen = db.prepare(
      `SELECT c.*, (SELECT COUNT(*) FROM collection_items ci WHERE ci.collection_id = c.id) AS anzahl
         FROM collections c WHERE c.project_id = ? ORDER BY c.sort, c.id`
    ).all(projekt.id).map((sammlung) => ({ ...sammlung, schema_text: schemaAlsText(sammlung.item_schema) }));
    return reply.view('admin/sammlungen.njk', { nutzer: request.nutzer, projekt, sammlungen, csrf: request.csrfToken });
  });

  app.post('/admin/projekt/:slug/sammlungen/neu', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const key = slugAusText(request.body?.key || request.body?.label || '').replace(/-/g, '_');
    if (!key) return reply.redirect(`/admin/projekt/${projekt.slug}/sammlungen`);
    const schema = schemaTextParsen(request.body?.schema_text);
    const maxSort = db.prepare(`SELECT COALESCE(MAX(sort), 0) AS m FROM collections WHERE project_id = ?`).get(projekt.id).m;
    db.prepare(
      `INSERT OR IGNORE INTO collections (project_id, key, label, item_schema, editable_by_editor, sort)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(
      projekt.id, key,
      String(request.body?.label || key).trim(),
      JSON.stringify(schema),
      request.body?.editable_by_editor ? 1 : 0,
      maxSort + 1,
    );
    audit(request.nutzer.id, projekt.id, 'sammlung_erstellt', key);
    return reply.redirect(`/admin/projekt/${projekt.slug}/sammlungen`);
  });

  app.post('/admin/projekt/:slug/sammlungen/:id/loeschen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const sammlung = db.prepare(`SELECT * FROM collections WHERE id = ? AND project_id = ?`).get(Number(request.params.id), projekt.id);
    if (sammlung) {
      db.prepare(`DELETE FROM collections WHERE id = ?`).run(sammlung.id);
      audit(request.nutzer.id, projekt.id, 'sammlung_geloescht', sammlung.key);
    }
    return reply.redirect(`/admin/projekt/${projekt.slug}/sammlungen`);
  });

  app.post('/admin/projekt/:slug/sammlungen/:id', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const sammlung = db.prepare(`SELECT * FROM collections WHERE id = ? AND project_id = ?`).get(Number(request.params.id), projekt.id);
    if (!sammlung) return reply.redirect(`/admin/projekt/${projekt.slug}/sammlungen`);
    db.prepare(
      `UPDATE collections SET label = ?, item_schema = ?, editable_by_editor = ?, sort = ? WHERE id = ?`
    ).run(
      String(request.body?.label ?? sammlung.label).trim(),
      JSON.stringify(schemaTextParsen(request.body?.schema_text)),
      request.body?.editable_by_editor ? 1 : 0,
      Number(request.body?.sort ?? sammlung.sort) || sammlung.sort,
      sammlung.id,
    );
    audit(request.nutzer.id, projekt.id, 'sammlung_geaendert', sammlung.key);
    return reply.redirect(`/admin/projekt/${projekt.slug}/sammlungen`);
  });

  // ---- Bereiche (Seiten ein-/ausblenden) verwalten ---------------------

  app.get('/admin/projekt/:slug/bereiche', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const bereiche = db.prepare(`SELECT * FROM sections WHERE project_id = ? ORDER BY sort, id`).all(projekt.id);
    return reply.view('admin/bereiche.njk', { nutzer: request.nutzer, projekt, bereiche, csrf: request.csrfToken });
  });

  app.post('/admin/projekt/:slug/bereiche/neu', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const key = slugAusText(request.body?.key || request.body?.label || '').replace(/-/g, '_');
    if (!key) return reply.redirect(`/admin/projekt/${projekt.slug}/bereiche`);
    const maxSort = db.prepare(`SELECT COALESCE(MAX(sort), 0) AS m FROM sections WHERE project_id = ?`).get(projekt.id).m;
    db.prepare(
      `INSERT OR IGNORE INTO sections (project_id, key, label, editor_darf_schalten, sort) VALUES (?, ?, ?, ?, ?)`
    ).run(projekt.id, key, String(request.body?.label || key).trim(), request.body?.editor_darf_schalten ? 1 : 0, maxSort + 1);
    audit(request.nutzer.id, projekt.id, 'bereich_erstellt', key);
    return reply.redirect(`/admin/projekt/${projekt.slug}/bereiche`);
  });

  app.post('/admin/projekt/:slug/bereiche/:id', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const bereich = db.prepare(`SELECT * FROM sections WHERE id = ? AND project_id = ?`).get(Number(request.params.id), projekt.id);
    if (!bereich) return reply.redirect(`/admin/projekt/${projekt.slug}/bereiche`);
    db.prepare(`UPDATE sections SET label = ?, editor_darf_schalten = ?, sort = ? WHERE id = ?`)
      .run(String(request.body?.label ?? bereich.label).trim(), request.body?.editor_darf_schalten ? 1 : 0, Number(request.body?.sort ?? bereich.sort) || bereich.sort, bereich.id);
    audit(request.nutzer.id, projekt.id, 'bereich_geaendert', bereich.key);
    return reply.redirect(`/admin/projekt/${projekt.slug}/bereiche`);
  });

  app.post('/admin/projekt/:slug/bereiche/:id/loeschen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const bereich = db.prepare(`SELECT * FROM sections WHERE id = ? AND project_id = ?`).get(Number(request.params.id), projekt.id);
    if (bereich) {
      db.prepare(`DELETE FROM sections WHERE id = ?`).run(bereich.id);
      audit(request.nutzer.id, projekt.id, 'bereich_geloescht', bereich.key);
    }
    return reply.redirect(`/admin/projekt/${projekt.slug}/bereiche`);
  });

  // ---- Nutzer & Einladungen (pro Projekt) ------------------------------

  app.get('/admin/projekt/:slug/nutzer', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const mitglieder = db.prepare(
      `SELECT u.id, u.name, u.email, u.role FROM memberships m
         JOIN users u ON u.id = m.user_id WHERE m.project_id = ? ORDER BY u.name`
    ).all(projekt.id);
    const einladungen = db.prepare(
      `SELECT * FROM invites WHERE project_id = ? AND used_at IS NULL AND expires_at > datetime('now') ORDER BY created_at DESC`
    ).all(projekt.id);
    return reply.view('admin/nutzer.njk', {
      nutzer: request.nutzer, projekt, mitglieder, einladungen,
      csrf: request.csrfToken, baseUrl: config.baseUrl, mailAktiv: mailKonfiguriert(),
      eingeladen: request.query.eingeladen === '1',
    });
  });

  app.post('/admin/projekt/:slug/nutzer/einladen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const email = String(request.body?.email || '').trim();
    if (!email.includes('@')) return reply.redirect(`/admin/projekt/${projekt.slug}/nutzer`);
    const rolle = request.body?.rolle === 'staff' ? 'staff' : 'customer';
    const token = neuesToken();
    const ablauf = sqliteZeitStempel(config.einladungDauerMs);
    db.prepare(
      `INSERT INTO invites (token, project_id, email, role, neue_rolle, expires_at) VALUES (?, ?, ?, 'editor', ?, ?)`
    ).run(tokenHash(token), projekt.id, email, rolle, ablauf);
    const link = `${config.baseUrl}/einladung/${token}`;
    await mailSenden({
      an: email,
      betreff: `Einladung: Website von ${projekt.name} bearbeiten`,
      text: `Hallo\n\nDu wurdest eingeladen, die Website "${projekt.name}" im QOM Editor zu bearbeiten.\n\nKlicke auf diesen Link, um dein Konto einzurichten (gültig für 7 Tage):\n${link}\n\nDein QOM-Team\nQuit Ordinary Marketing`,
    });
    audit(request.nutzer.id, projekt.id, 'einladung_erstellt', email);
    return reply.redirect(`/admin/projekt/${projekt.slug}/nutzer?eingeladen=1`);
  });

  app.post('/admin/projekt/:slug/nutzer/:userId/entfernen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    db.prepare(`DELETE FROM memberships WHERE user_id = ? AND project_id = ?`).run(Number(request.params.userId), projekt.id);
    audit(request.nutzer.id, projekt.id, 'nutzer_entfernt', String(request.params.userId));
    return reply.redirect(`/admin/projekt/${projekt.slug}/nutzer`);
  });

  app.post('/admin/projekt/:slug/einladung/:id/loeschen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    db.prepare(`DELETE FROM invites WHERE id = ? AND project_id = ?`).run(Number(request.params.id), projekt.id);
    return reply.redirect(`/admin/projekt/${projekt.slug}/nutzer`);
  });

  // ---- Audit-Log --------------------------------------------------------

  app.get('/admin/projekt/:slug/audit', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const projekt = projektOder404(request, reply);
    if (!projekt) return reply;
    const eintraege = db.prepare(
      `SELECT a.*, u.name AS nutzer_name, u.email AS nutzer_email
         FROM audit_log a LEFT JOIN users u ON u.id = a.user_id
        WHERE a.project_id = ? ORDER BY a.id DESC LIMIT 200`
    ).all(projekt.id);
    return reply.view('admin/audit.njk', { nutzer: request.nutzer, projekt, eintraege, csrf: request.csrfToken });
  });

  // ---- Konten (Geschäftsführer, Mitarbeiter, Kunden) -------------------

  app.get('/admin/konten', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const konten = db.prepare(
      `SELECT u.*,
         (SELECT GROUP_CONCAT(p.name, ', ') FROM memberships m JOIN projects p ON p.id = m.project_id WHERE m.user_id = u.id) AS projekte
       FROM users u ORDER BY CASE u.role WHEN 'owner' THEN 0 WHEN 'staff' THEN 1 ELSE 2 END, u.name`
    ).all();
    const projekte = db.prepare(`SELECT id, name, slug FROM projects ORDER BY name`).all();
    // Für die Projekt-Zuweisung: welche Projekte hat wer?
    const zuordnung = {};
    for (const zeile of db.prepare(`SELECT user_id, project_id FROM memberships`).all()) {
      (zuordnung[zeile.user_id] ||= new Set()).add(zeile.project_id);
    }
    const kontenMitProjekten = konten.map((k) => ({
      ...k,
      projektIds: Array.from(zuordnung[k.id] || []),
    }));
    return reply.view('admin/konten.njk', {
      nutzer: request.nutzer, konten: kontenMitProjekten, projekte,
      csrf: request.csrfToken, baseUrl: config.baseUrl, mailAktiv: mailKonfiguriert(),
      angelegt: request.query.angelegt || '',
      fehler: request.query.fehler || '',
    });
  });

  app.post('/admin/konten/neu', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const name = String(request.body?.name || '').trim();
    const email = String(request.body?.email || '').trim();
    const rolle = ['owner', 'staff', 'customer'].includes(request.body?.role) ? request.body.role : 'customer';
    const passwort = String(request.body?.passwort || '');
    if (!name || !email.includes('@')) return reply.redirect('/admin/konten?fehler=eingabe');
    if (db.prepare(`SELECT 1 FROM users WHERE email = ?`).get(email)) {
      return reply.redirect('/admin/konten?fehler=email');
    }
    if (passwort && passwort.length < 10) return reply.redirect('/admin/konten?fehler=passwort');

    const hash = await passwortHashen(passwort || neuesToken());
    const ergebnis = db.prepare(
      `INSERT INTO users (email, pw_hash, name, role, is_admin) VALUES (?, ?, ?, ?, ?)`
    ).run(email, hash, name, rolle, rolle === 'owner' ? 1 : 0);
    const userId = ergebnis.lastInsertRowid;

    // Projekte zuweisen (nicht für owner – der sieht ohnehin alles)
    const projektIds = [].concat(request.body?.projekt_ids || []).map(Number).filter(Boolean);
    if (rolle !== 'owner') {
      const einfuegen = db.prepare(`INSERT OR IGNORE INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`);
      for (const pid of projektIds) einfuegen.run(userId, pid);
    }
    audit(request.nutzer.id, null, 'konto_erstellt', `${email} (${rolle})`);

    // Ohne gesetztes Passwort: Einladungs-/Reset-Link erzeugen
    let hinweis = 'ok';
    if (!passwort) {
      const token = neuesToken();
      db.prepare(`INSERT INTO password_resets (token, user_id, expires_at) VALUES (?, ?, ?)`)
        .run(tokenHash(token), userId, sqliteZeitStempel(config.einladungDauerMs));
      const link = `${config.baseUrl}/passwort-zuruecksetzen/${token}`;
      await mailSenden({
        an: email,
        betreff: 'Dein QOM-Editor-Konto',
        text: `Hallo ${name}\n\nFür dich wurde ein Konto im QOM Editor angelegt. Setze hier dein Passwort (gültig 7 Tage):\n${link}\n\nDein QOM-Team`,
      });
      hinweis = mailKonfiguriert() ? 'link-mail' : 'link-anzeigen:' + token;
    }
    return reply.redirect('/admin/konten?angelegt=' + encodeURIComponent(hinweis));
  });

  app.post('/admin/konten/:id/projekte', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const ziel = db.prepare(`SELECT * FROM users WHERE id = ?`).get(Number(request.params.id));
    if (!ziel) return reply.redirect('/admin/konten');
    const projektIds = [].concat(request.body?.projekt_ids || []).map(Number).filter(Boolean);
    db.transaction(() => {
      db.prepare(`DELETE FROM memberships WHERE user_id = ?`).run(ziel.id);
      if (ziel.role !== 'owner') {
        const einfuegen = db.prepare(`INSERT OR IGNORE INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`);
        for (const pid of projektIds) einfuegen.run(ziel.id, pid);
      }
    })();
    audit(request.nutzer.id, null, 'konto_projekte_geaendert', ziel.email);
    return reply.redirect('/admin/konten');
  });

  app.post('/admin/konten/:id/rolle', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const ziel = db.prepare(`SELECT * FROM users WHERE id = ?`).get(Number(request.params.id));
    if (!ziel) return reply.redirect('/admin/konten');
    const rolle = ['owner', 'staff', 'customer'].includes(request.body?.role) ? request.body.role : ziel.role;
    // Verhindern, dass sich der letzte Geschäftsführer selbst herabstuft
    if (ziel.role === 'owner' && rolle !== 'owner') {
      const anzahlOwner = db.prepare(`SELECT COUNT(*) AS n FROM users WHERE role = 'owner'`).get().n;
      if (anzahlOwner <= 1) return reply.redirect('/admin/konten?fehler=letzter-owner');
    }
    db.prepare(`UPDATE users SET role = ?, is_admin = ? WHERE id = ?`).run(rolle, rolle === 'owner' ? 1 : 0, ziel.id);
    if (rolle === 'owner') db.prepare(`DELETE FROM memberships WHERE user_id = ?`).run(ziel.id);
    audit(request.nutzer.id, null, 'konto_rolle_geaendert', `${ziel.email} -> ${rolle}`);
    return reply.redirect('/admin/konten');
  });

  app.post('/admin/konten/:id/loeschen', async (request, reply) => {
    if (!adminErzwingen(request, reply)) return reply;
    const ziel = db.prepare(`SELECT * FROM users WHERE id = ?`).get(Number(request.params.id));
    if (!ziel) return reply.redirect('/admin/konten');
    if (ziel.id === request.nutzer.id) return reply.redirect('/admin/konten?fehler=selbst');
    if (ziel.role === 'owner') {
      const anzahlOwner = db.prepare(`SELECT COUNT(*) AS n FROM users WHERE role = 'owner'`).get().n;
      if (anzahlOwner <= 1) return reply.redirect('/admin/konten?fehler=letzter-owner');
    }
    db.prepare(`DELETE FROM users WHERE id = ?`).run(ziel.id);
    audit(request.nutzer.id, null, 'konto_geloescht', ziel.email);
    return reply.redirect('/admin/konten');
  });
}
