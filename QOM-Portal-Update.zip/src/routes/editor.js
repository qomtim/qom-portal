// Der Editor-Bereich für Kunden, Mitarbeiter und Geschäftsführer.
// Alle Rechte werden hier serverseitig geprüft – nie nur in der Oberfläche.
import { db, audit } from '../db.js';
import { config } from '../config.js';
import { projektZugriff } from '../auth.js';
import { deployAusloesen } from '../webhook.js';

export function projektHolen(slug) {
  return db.prepare(`SELECT * FROM projects WHERE slug = ?`).get(String(slug));
}

// Liefert {projekt, zugriff, rolle} oder beantwortet die Anfrage mit 404.
// rolle bleibt aus Kompatibilität erhalten: 'admin' (darf alles) | 'editor'.
export function zugriffPruefen(request, reply) {
  if (!request.nutzer) {
    // Bei AJAX (Auto-Speichern) klare 401-Meldung statt HTML-Redirect,
    // damit der Kunde eine verständliche Meldung sieht und nichts still verloren geht.
    if (request.headers['x-requested-with'] === 'fetch') {
      reply.code(401).send({ fehler: 'Deine Sitzung ist abgelaufen. Bitte melde dich neu an.', neu_anmelden: true });
    } else {
      reply.redirect('/login');
    }
    return null;
  }
  const projekt = projektHolen(request.params.slug);
  const zugriff = projekt ? projektZugriff(request.nutzer, projekt) : null;
  if (!projekt || !zugriff) {
    // Bewusst identisch zu "gibt es nicht": Existenz fremder Projekte nicht verraten
    reply.code(404).view('fehler.njk', {
      titel: 'Seite nicht gefunden',
      meldung: 'Diese Seite gibt es nicht (mehr).',
      nutzer: request.nutzer,
    });
    return null;
  }
  return { projekt, zugriff, rolle: zugriff.darfAlles ? 'admin' : 'editor' };
}

function schemaParsen(text) {
  try {
    const geparst = JSON.parse(text);
    return Array.isArray(geparst) ? geparst : [];
  } catch {
    return [];
  }
}

function hatUnveroeffentlichteAenderungen(projektId) {
  const feld = db.prepare(
    `SELECT 1 FROM fields WHERE project_id = ? AND value_draft != value_published LIMIT 1`
  ).get(projektId);
  if (feld) return true;
  const item = db.prepare(
    `SELECT 1 FROM collection_items ci JOIN collections c ON c.id = ci.collection_id
      WHERE c.project_id = ? AND (ci.data_draft != ci.data_published OR ci.geloescht_draft = 1) LIMIT 1`
  ).get(projektId);
  if (item) return true;
  const bereich = db.prepare(
    `SELECT 1 FROM sections WHERE project_id = ? AND sichtbar_draft != sichtbar_published LIMIT 1`
  ).get(projektId);
  return Boolean(bereich);
}

export async function editorRouten(app) {
  // Vorschau-Proxy: liefert die (HTTP-)Test-Seite über den HTTPS-Portalursprung
  // aus, damit sie im Editor als iframe eingebettet werden kann (sonst blockt
  // der Browser HTTP-in-HTTPS). Nur für eingeloggte Nutzer.
  async function vorschauProxy(request, reply) {
    if (!request.nutzer) return reply.code(401).send('Bitte einloggen.');
    const slug = String(request.params.slug || '').replace(/[^a-z0-9-]/gi, '');
    const rest = String(request.params['*'] || '').replace(/\.\./g, '');
    try {
      const antwort = await fetch(config.vorschauBasisUrl + '/' + slug + '/' + rest, { signal: AbortSignal.timeout(15000) });
      const puffer = Buffer.from(await antwort.arrayBuffer());
      reply.code(antwort.status);
      const ct = antwort.headers.get('content-type');
      if (ct) reply.header('content-type', ct);
      reply.header('cache-control', 'no-store');
      return reply.send(puffer);
    } catch (e) {
      return reply.code(502).send('Vorschau gerade nicht erreichbar.');
    }
  }
  app.get('/vorschau/:slug', vorschauProxy);
  app.get('/vorschau/:slug/*', vorschauProxy);

  app.get('/projekt/:slug', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    // Reine Ads-Projekte haben keinen Website-Editor → direkt aufs Dashboard
    if (projekt.projekt_typ === 'ads') {
      return reply.redirect(`/projekt/${projekt.slug}/ads`);
    }
    const nurKunde = !zugriff.darfAlles;

    // Felder laden – Kunde sieht nur freigegebene, und je nach Umfang keine Bilder
    let felderSql = `SELECT * FROM fields WHERE project_id = ?`;
    if (nurKunde) {
      felderSql += ` AND editable_by_editor = 1`;
      if (!projekt.kunde_darf_bilder) felderSql += ` AND type != 'image'`;
    }
    felderSql += ` ORDER BY sort, id`;
    const felder = db.prepare(felderSql).all(projekt.id);

    const gruppen = [];
    const gruppenMap = new Map();
    for (const feld of felder) {
      const label = feld.group_label || 'Inhalte';
      if (!gruppenMap.has(label)) {
        const gruppe = { label, felder: [] };
        gruppenMap.set(label, gruppe);
        gruppen.push(gruppe);
      }
      gruppenMap.get(label).felder.push(feld);
    }

    // Sammlungen – Kunde nur wenn erlaubt
    let sammlungen = [];
    if (!nurKunde || projekt.kunde_darf_sammlungen) {
      const sammlungenRoh = db.prepare(
        `SELECT * FROM collections WHERE project_id = ? ${nurKunde ? 'AND editable_by_editor = 1' : ''} ORDER BY sort, id`
      ).all(projekt.id);
      sammlungen = sammlungenRoh.map((sammlung) => ({
        ...sammlung,
        schema: schemaParsen(sammlung.item_schema),
        eintraege: db.prepare(
          `SELECT id, data_draft, geloescht_draft FROM collection_items WHERE collection_id = ? ORDER BY sort, id`
        ).all(sammlung.id).map((zeile) => ({
          id: zeile.id,
          geloescht: Boolean(zeile.geloescht_draft),
          daten: (() => { try { return JSON.parse(zeile.data_draft); } catch { return {}; } })(),
        })),
      }));
    }

    // Bereiche zum Ein-/Ausblenden – Kunde nur wenn freigeschaltet
    let bereiche = [];
    const darfBereicheSchalten = !nurKunde || projekt.kunde_darf_seiten_schalten;
    if (darfBereicheSchalten) {
      bereiche = db.prepare(
        `SELECT * FROM sections WHERE project_id = ? ${nurKunde ? 'AND editor_darf_schalten = 1' : ''} ORDER BY sort, id`
      ).all(projekt.id);
    }

    return reply.view('editor.njk', {
      nutzer: request.nutzer,
      projekt,
      zugriff,
      rolle: kontext.rolle,
      gruppen,
      sammlungen,
      bereiche,
      darfBlog: projekt.blog_aktiv || zugriff.darfAlles,
      hatAds: projekt.projekt_typ === 'beides',
      hatEntwurf: hatUnveroeffentlichteAenderungen(projekt.id),
      veroeffentlicht: request.query.veroeffentlicht === '1',
      csrf: request.csrfToken,
    });
  });

  // Ein einzelnes Feld speichern (AJAX, Entwurf)
  app.post('/projekt/:slug/feld', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    const { key, wert } = request.body || {};

    const feld = db.prepare(
      `SELECT * FROM fields WHERE project_id = ? AND key = ?`
    ).get(projekt.id, String(key || ''));
    if (!feld) return reply.code(404).send({ fehler: 'Feld nicht gefunden.' });
    if (!zugriff.darfAlles) {
      if (!feld.editable_by_editor) return reply.code(403).send({ fehler: 'Dieses Feld ist für dich gesperrt.' });
      if (feld.type === 'image' && !projekt.kunde_darf_bilder) {
        return reply.code(403).send({ fehler: 'Bilder ändern ist für dich nicht freigeschaltet.' });
      }
    }

    db.prepare(`UPDATE fields SET value_draft = ? WHERE id = ?`).run(String(wert ?? ''), feld.id);
    audit(request.nutzer.id, projekt.id, 'feld_gespeichert', feld.key);
    return reply.send({ ok: true });
  });

  // ---- Bereiche ein-/ausblenden ----------------------------------------

  app.post('/projekt/:slug/bereich/:key/sichtbarkeit', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    if (!zugriff.darfAlles && !projekt.kunde_darf_seiten_schalten) {
      return reply.code(403).send({ fehler: 'Nicht erlaubt.' });
    }
    const bereich = db.prepare(
      `SELECT * FROM sections WHERE project_id = ? AND key = ?`
    ).get(projekt.id, String(request.params.key));
    if (!bereich) return reply.code(404).send({ fehler: 'Bereich nicht gefunden.' });
    if (!zugriff.darfAlles && !bereich.editor_darf_schalten) {
      return reply.code(403).send({ fehler: 'Nicht erlaubt.' });
    }
    const sichtbar = request.body?.sichtbar ? 1 : 0;
    db.prepare(`UPDATE sections SET sichtbar_draft = ? WHERE id = ?`).run(sichtbar, bereich.id);
    audit(request.nutzer.id, projekt.id, 'bereich_geschaltet', `${bereich.key}=${sichtbar}`);
    return reply.send({ ok: true });
  });

  // ---- Sammlungen (Team, Referenzen, FAQ, …) ---------------------------

  function sammlungHolen(projekt, zugriff, key) {
    const sammlung = db.prepare(
      `SELECT * FROM collections WHERE project_id = ? AND key = ?`
    ).get(projekt.id, String(key));
    if (!sammlung) return { fehler: 404 };
    if (!zugriff.darfAlles) {
      if (!sammlung.editable_by_editor || !projekt.kunde_darf_sammlungen) return { fehler: 403 };
    }
    return { sammlung };
  }

  app.post('/projekt/:slug/sammlung/:key/neu', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    const { sammlung, fehler } = sammlungHolen(projekt, zugriff, request.params.key);
    if (fehler) return reply.code(fehler).send({ fehler: 'Nicht erlaubt.' });

    const maxSort = db.prepare(
      `SELECT COALESCE(MAX(sort), 0) AS m FROM collection_items WHERE collection_id = ?`
    ).get(sammlung.id).m;
    const ergebnis = db.prepare(
      `INSERT INTO collection_items (collection_id, data_draft, data_published, sort) VALUES (?, '{}', '{}', ?)`
    ).run(sammlung.id, maxSort + 1);
    audit(request.nutzer.id, projekt.id, 'eintrag_erstellt', sammlung.key);
    return reply.send({ ok: true, id: ergebnis.lastInsertRowid });
  });

  app.post('/projekt/:slug/sammlung/:key/:itemId/loeschen', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    const { sammlung, fehler } = sammlungHolen(projekt, zugriff, request.params.key);
    if (fehler) return reply.code(fehler).send({ fehler: 'Nicht erlaubt.' });

    const item = db.prepare(
      `SELECT * FROM collection_items WHERE id = ? AND collection_id = ?`
    ).get(Number(request.params.itemId), sammlung.id);
    if (!item) return reply.code(404).send({ fehler: 'Eintrag nicht gefunden.' });

    if (item.data_published === '{}') {
      db.prepare(`DELETE FROM collection_items WHERE id = ?`).run(item.id);
    } else {
      db.prepare(`UPDATE collection_items SET geloescht_draft = 1 WHERE id = ?`).run(item.id);
    }
    audit(request.nutzer.id, projekt.id, 'eintrag_geloescht', sammlung.key);
    return reply.send({ ok: true });
  });

  app.post('/projekt/:slug/sammlung/:key/:itemId/wiederherstellen', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    const { sammlung, fehler } = sammlungHolen(projekt, zugriff, request.params.key);
    if (fehler) return reply.code(fehler).send({ fehler: 'Nicht erlaubt.' });
    db.prepare(
      `UPDATE collection_items SET geloescht_draft = 0 WHERE id = ? AND collection_id = ?`
    ).run(Number(request.params.itemId), sammlung.id);
    return reply.send({ ok: true });
  });

  app.post('/projekt/:slug/sammlung/:key/sortierung', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    const { sammlung, fehler } = sammlungHolen(projekt, zugriff, request.params.key);
    if (fehler) return reply.code(fehler).send({ fehler: 'Nicht erlaubt.' });

    const ids = Array.isArray(request.body?.ids) ? request.body.ids.map(Number) : [];
    const setzen = db.prepare(
      `UPDATE collection_items SET sort = ? WHERE id = ? AND collection_id = ?`
    );
    db.transaction(() => {
      ids.forEach((id, index) => setzen.run(index + 1, id, sammlung.id));
    })();
    return reply.send({ ok: true });
  });

  app.post('/projekt/:slug/sammlung/:key/:itemId', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    const { sammlung, fehler } = sammlungHolen(projekt, zugriff, request.params.key);
    if (fehler) return reply.code(fehler).send({ fehler: 'Nicht erlaubt.' });

    const item = db.prepare(
      `SELECT id FROM collection_items WHERE id = ? AND collection_id = ?`
    ).get(Number(request.params.itemId), sammlung.id);
    if (!item) return reply.code(404).send({ fehler: 'Eintrag nicht gefunden.' });

    const schema = schemaParsen(sammlung.item_schema);
    const erlaubteSpalten = new Set(schema.map((spalte) => spalte.key));
    const eingehend = request.body?.daten || {};
    const bereinigt = {};
    for (const [spaltenKey, wert] of Object.entries(eingehend)) {
      if (erlaubteSpalten.has(spaltenKey)) bereinigt[spaltenKey] = String(wert ?? '');
    }

    db.prepare(`UPDATE collection_items SET data_draft = ? WHERE id = ?`)
      .run(JSON.stringify(bereinigt), item.id);
    audit(request.nutzer.id, projekt.id, 'eintrag_gespeichert', sammlung.key);
    return reply.send({ ok: true });
  });

  // ---- Veröffentlichen --------------------------------------------------

  app.post('/projekt/:slug/veroeffentlichen', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt } = kontext;

    db.transaction(() => {
      db.prepare(`UPDATE fields SET value_published = value_draft WHERE project_id = ?`).run(projekt.id);
      db.prepare(
        `DELETE FROM collection_items WHERE geloescht_draft = 1 AND collection_id IN
           (SELECT id FROM collections WHERE project_id = ?)`
      ).run(projekt.id);
      db.prepare(
        `UPDATE collection_items SET data_published = data_draft WHERE collection_id IN
           (SELECT id FROM collections WHERE project_id = ?)`
      ).run(projekt.id);
      db.prepare(`UPDATE sections SET sichtbar_published = sichtbar_draft WHERE project_id = ?`).run(projekt.id);
    })();
    audit(request.nutzer.id, projekt.id, 'veroeffentlicht', '');

    const ergebnis = await deployAusloesen(projekt, request.nutzer.id);
    if (request.headers['x-requested-with'] === 'fetch') {
      return reply.send({ ok: true, deploy: ergebnis });
    }
    return reply.redirect(`/projekt/${projekt.slug}?veroeffentlicht=1`);
  });
}
