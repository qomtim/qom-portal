// E-Mail-Versand über Infomaniak-SMTP. Ohne SMTP-Konfiguration werden Mails
// nur ins Log geschrieben (praktisch für lokale Entwicklung) und der Link
// zusätzlich in der Admin-Oberfläche angezeigt.
import nodemailer from 'nodemailer';
import { config } from './config.js';

let transporter = null;
if (config.smtp.host && config.smtp.user) {
  transporter = nodemailer.createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    secure: config.smtp.secure,
    auth: { user: config.smtp.user, pass: config.smtp.pass },
    // Harte Zeitlimits, damit ein träger Mailserver nie eine Anfrage blockiert
    connectionTimeout: 5000,
    greetingTimeout: 5000,
    socketTimeout: 10000,
  });
}

export function mailKonfiguriert() {
  return Boolean(transporter);
}

export async function mailSenden({ an, betreff, text }) {
  if (!transporter) {
    console.log(`[Mail nicht konfiguriert] An: ${an} | ${betreff}\n${text}`);
    return false;
  }
  await transporter.sendMail({
    from: config.smtp.absender,
    to: an,
    subject: betreff,
    text,
  });
  return true;
}
