// QOM Editor – Blog: einfacher Text-Editor (fett, kursiv, Zwischentitel,
// Listen, Links) und Titelbild-Upload. Reines Vanilla-JS.
(function () {
  'use strict';

  var formular = document.getElementById('beitrag-formular');
  if (!formular) return;
  var projektSlug = formular.dataset.projekt;
  var textFeld = document.getElementById('beitrag-text');
  var htmlFeld = document.getElementById('body-html-feld');

  function csrfToken() {
    var treffer = document.cookie.match(/(?:^|;\s*)qom_csrf=([^;]+)/);
    return treffer ? decodeURIComponent(treffer[1]) : '';
  }

  // Schutz vor Datenverlust: warnen, wenn mit ungespeicherten Änderungen
  // weggeklickt wird.
  var schmutzig = false;
  var wirdGesendet = false;
  formular.addEventListener('input', function () { schmutzig = true; });
  textFeld.addEventListener('input', function () { schmutzig = true; });
  window.addEventListener('beforeunload', function (ereignis) {
    if (schmutzig && !wirdGesendet) {
      ereignis.preventDefault();
      ereignis.returnValue = '';
    }
  });

  // Beim Absenden: HTML aus dem Editor in das versteckte Feld übernehmen
  formular.addEventListener('submit', function () {
    wirdGesendet = true;
    htmlFeld.value = textFeld.innerHTML;
  });

  // Werkzeugleiste
  document.querySelectorAll('.editor-werkzeuge button').forEach(function (knopf) {
    knopf.addEventListener('mousedown', function (ereignis) {
      ereignis.preventDefault(); // Auswahl im Editor nicht verlieren
    });
    knopf.addEventListener('click', function () {
      textFeld.focus();
      if (knopf.dataset.befehl) {
        document.execCommand(knopf.dataset.befehl, false, null);
      } else if (knopf.dataset.block) {
        var aktuellerBlock = document.queryCommandValue('formatBlock');
        var ziel = knopf.dataset.block;
        document.execCommand('formatBlock', false, aktuellerBlock === ziel ? 'p' : ziel);
      } else if (knopf.hasAttribute('data-link')) {
        var adresse = window.prompt('Link-Adresse (z.B. https://www.beispiel.ch):');
        if (adresse) {
          if (!/^(https?:\/\/|mailto:|tel:|\/)/i.test(adresse)) adresse = 'https://' + adresse;
          document.execCommand('createLink', false, adresse);
        }
      }
    });
  });

  // Eingefügten Text säubern (Word/Websites bringen viel unerwünschtes HTML mit)
  textFeld.addEventListener('paste', function (ereignis) {
    ereignis.preventDefault();
    var text = (ereignis.clipboardData || window.clipboardData).getData('text/plain');
    document.execCommand('insertText', false, text);
  });

  // Titelbild
  var coverFeld = document.getElementById('cover-feld');
  var coverUrlFeld = document.getElementById('cover-url-feld');
  if (coverFeld) {
    var dateiwahl = document.createElement('input');
    dateiwahl.type = 'file';
    dateiwahl.accept = 'image/jpeg,image/png,image/webp,image/avif';

    function coverSetzen(url) {
      var vorschau = coverFeld.querySelector('.bild-vorschau');
      var entfernen = coverFeld.querySelector('.bild-entfernen');
      coverUrlFeld.value = url;
      if (url) {
        vorschau.src = url;
        vorschau.hidden = false;
        entfernen.hidden = false;
        coverFeld.classList.add('hat-bild');
      } else {
        vorschau.removeAttribute('src');
        vorschau.hidden = true;
        entfernen.hidden = true;
        coverFeld.classList.remove('hat-bild');
      }
    }

    function hochladen(datei) {
      if (!datei || datei.type.indexOf('image/') !== 0) return;
      coverFeld.classList.add('laedt');
      var daten = new FormData();
      daten.append('datei', datei);
      fetch('/projekt/' + projektSlug + '/upload', {
        method: 'POST',
        headers: { 'x-csrf-token': csrfToken(), 'x-requested-with': 'fetch' },
        body: daten,
        credentials: 'same-origin',
      }).then(function (antwort) {
        return antwort.json().then(function (körper) {
          if (!antwort.ok) throw new Error(körper.fehler || 'Upload fehlgeschlagen.');
          return körper;
        });
      }).then(function (körper) {
        coverFeld.classList.remove('laedt');
        coverSetzen(körper.url);
      }).catch(function (fehler) {
        coverFeld.classList.remove('laedt');
        window.alert(fehler.message || 'Upload fehlgeschlagen.');
      });
    }

    coverFeld.addEventListener('click', function (ereignis) {
      if (ereignis.target.closest('.bild-entfernen')) {
        coverSetzen('');
        return;
      }
      dateiwahl.value = '';
      dateiwahl.click();
    });
    dateiwahl.addEventListener('change', function () {
      if (dateiwahl.files[0]) hochladen(dateiwahl.files[0]);
    });
    coverFeld.addEventListener('dragover', function (ereignis) {
      ereignis.preventDefault();
      coverFeld.classList.add('zieht');
    });
    coverFeld.addEventListener('dragleave', function () {
      coverFeld.classList.remove('zieht');
    });
    coverFeld.addEventListener('drop', function (ereignis) {
      ereignis.preventDefault();
      coverFeld.classList.remove('zieht');
      var datei = ereignis.dataTransfer.files && ereignis.dataTransfer.files[0];
      if (datei) hochladen(datei);
    });
  }
})();
