// QOM Editor – Editor-Seite: automatisches Speichern, Bilder, Sammlungen,
// Veröffentlichen und Live-Vorschau. Bewusst reines Vanilla-JS.
(function () {
  'use strict';

  var wurzel = document.getElementById('editor');
  if (!wurzel) return;
  var projektSlug = wurzel.dataset.projekt;
  var vorschauUrl = wurzel.dataset.vorschauUrl || '';

  function csrfToken() {
    var treffer = document.cookie.match(/(?:^|;\s*)qom_csrf=([^;]+)/);
    return treffer ? decodeURIComponent(treffer[1]) : '';
  }

  var status = document.getElementById('speicher-status');
  var offeneSpeicherungen = 0;
  function statusSetzen(text, istFehler) {
    if (!status) return;
    status.textContent = text;
    status.style.color = istFehler ? '#b91c1c' : '';
  }

  // optionen.still = true: Statuszeile nicht anfassen (der Aufrufer meldet selbst)
  function senden(pfad, daten, optionen) {
    optionen = optionen || {};
    offeneSpeicherungen++;
    if (!optionen.still) statusSetzen('Speichert …');
    return fetch(pfad, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-csrf-token': csrfToken(),
        'x-requested-with': 'fetch',
      },
      body: JSON.stringify(daten || {}),
      credentials: 'same-origin',
    }).then(function (antwort) {
      if (!antwort.ok) {
        return antwort.json().catch(function () { return {}; }).then(function (körper) {
          var fehler = new Error(körper.fehler || 'Speichern fehlgeschlagen.');
          fehler.neuAnmelden = antwort.status === 401 || körper.neu_anmelden;
          throw fehler;
        });
      }
      return antwort.json();
    }).then(
      function (körper) { abschluss(true, null, optionen); return körper; },
      function (fehler) { abschluss(false, fehler, optionen); throw fehler; }
    );
  }

  // Zähler genau EINMAL herunterzählen und Status setzen
  function abschluss(erfolg, fehler, optionen) {
    offeneSpeicherungen = Math.max(0, offeneSpeicherungen - 1);
    if (optionen && optionen.still) return;
    if (!erfolg) {
      if (fehler && fehler.neuAnmelden) {
        statusSetzen('Deine Sitzung ist abgelaufen. Melde dich in einem neuen Tab neu an – deine Eingaben bleiben hier stehen.', true);
      } else {
        statusSetzen((fehler && fehler.message) || 'Speichern fehlgeschlagen – bitte Seite neu laden.', true);
      }
      return;
    }
    if (offeneSpeicherungen === 0) {
      statusSetzen('Gespeichert ✓');
      entwurfAnzeigen(true);
    }
  }

  function entwurfAnzeigen(sichtbar) {
    var badge = document.getElementById('entwurf-badge');
    if (badge) badge.classList.toggle('versteckt', !sichtbar);
  }

  // ---- Entprelltes Speichern -------------------------------------------

  var timer = {};
  function verzoegert(schluessel, funktion) {
    clearTimeout(timer[schluessel]);
    timer[schluessel] = setTimeout(funktion, 600);
  }

  function feldSpeichern(eingabe) {
    var key = eingabe.dataset.feld;
    senden('/projekt/' + projektSlug + '/feld', { key: key, wert: eingabe.value });
    vorschauAktualisieren(key, eingabe.value);
  }

  function eintragSpeichern(eintragElement) {
    var sammlungKey = eintragElement.closest('[data-sammlung]').dataset.sammlung;
    var id = eintragElement.dataset.eintrag;
    var daten = {};
    eintragElement.querySelectorAll('[data-spalte]').forEach(function (eingabe) {
      daten[eingabe.dataset.spalte] = eingabe.value;
    });
    senden('/projekt/' + projektSlug + '/sammlung/' + sammlungKey + '/' + id, { daten: daten });
  }

  wurzel.addEventListener('input', function (ereignis) {
    var ziel = ereignis.target;
    if (ziel.matches('[data-feld]') && ziel.type !== 'hidden') {
      verzoegert('feld-' + ziel.dataset.feld, function () { feldSpeichern(ziel); });
    } else if (ziel.matches('[data-spalte]')) {
      var eintrag = ziel.closest('[data-eintrag]');
      if (eintrag) {
        verzoegert('eintrag-' + eintrag.dataset.eintrag, function () { eintragSpeichern(eintrag); });
      }
    }
  });

  // ---- Bild-Felder ------------------------------------------------------

  var dateiwahl = document.createElement('input');
  dateiwahl.type = 'file';
  dateiwahl.accept = 'image/jpeg,image/png,image/webp,image/avif';
  var aktivesBildfeld = null;

  function bildHochladen(bildFeld, datei) {
    if (!datei || datei.type.indexOf('image/') !== 0) {
      statusSetzen('Bitte wähle ein Bild aus (JPG, PNG oder WebP).', true);
      return;
    }
    bildFeld.classList.add('laedt');
    var formular = new FormData();
    formular.append('datei', datei);
    fetch('/projekt/' + projektSlug + '/upload', {
      method: 'POST',
      headers: { 'x-csrf-token': csrfToken(), 'x-requested-with': 'fetch' },
      body: formular,
      credentials: 'same-origin',
    }).then(function (antwort) {
      return antwort.json().then(function (körper) {
        if (!antwort.ok) throw new Error(körper.fehler || 'Upload fehlgeschlagen.');
        return körper;
      });
    }).then(function (körper) {
      bildFeld.classList.remove('laedt');
      bildSetzen(bildFeld, körper.url);
    }).catch(function (fehler) {
      bildFeld.classList.remove('laedt');
      statusSetzen(fehler.message || 'Upload fehlgeschlagen.', true);
    });
  }

  function bildSetzen(bildFeld, url) {
    var versteckt = bildFeld.querySelector('input[type="hidden"]');
    var vorschau = bildFeld.querySelector('.bild-vorschau');
    var entfernen = bildFeld.querySelector('.bild-entfernen');
    versteckt.value = url;
    if (url) {
      vorschau.src = url;
      vorschau.hidden = false;
      if (entfernen) entfernen.hidden = false;
      bildFeld.classList.add('hat-bild');
    } else {
      vorschau.removeAttribute('src');
      vorschau.hidden = true;
      if (entfernen) entfernen.hidden = true;
      bildFeld.classList.remove('hat-bild');
    }
    // Speichern anstossen (Feld oder Sammlungs-Eintrag)
    if (versteckt.dataset.feld) {
      feldSpeichern(versteckt);
    } else {
      var eintrag = bildFeld.closest('[data-eintrag]');
      if (eintrag) eintragSpeichern(eintrag);
    }
  }

  wurzel.addEventListener('click', function (ereignis) {
    var entfernen = ereignis.target.closest('.bild-entfernen');
    if (entfernen) {
      ereignis.stopPropagation();
      bildSetzen(entfernen.closest('.bild-feld'), '');
      return;
    }
    var bildFeld = ereignis.target.closest('.bild-feld');
    if (bildFeld) {
      aktivesBildfeld = bildFeld;
      dateiwahl.value = '';
      dateiwahl.click();
    }
  });

  dateiwahl.addEventListener('change', function () {
    if (aktivesBildfeld && dateiwahl.files[0]) bildHochladen(aktivesBildfeld, dateiwahl.files[0]);
  });

  wurzel.addEventListener('dragover', function (ereignis) {
    var bildFeld = ereignis.target.closest('.bild-feld');
    if (bildFeld) {
      ereignis.preventDefault();
      bildFeld.classList.add('zieht');
    }
  });
  wurzel.addEventListener('dragleave', function (ereignis) {
    var bildFeld = ereignis.target.closest('.bild-feld');
    if (bildFeld) bildFeld.classList.remove('zieht');
  });
  wurzel.addEventListener('drop', function (ereignis) {
    var bildFeld = ereignis.target.closest('.bild-feld');
    if (bildFeld) {
      ereignis.preventDefault();
      bildFeld.classList.remove('zieht');
      var datei = ereignis.dataTransfer.files && ereignis.dataTransfer.files[0];
      if (datei) bildHochladen(bildFeld, datei);
    }
  });

  // ---- Sammlungen: hinzufügen, löschen, sortieren -----------------------

  document.querySelectorAll('.eintrag-neu').forEach(function (knopf) {
    knopf.addEventListener('click', function () {
      var key = knopf.dataset.sammlungKey;
      senden('/projekt/' + projektSlug + '/sammlung/' + key + '/neu', {}).then(function () {
        window.location.href = window.location.pathname + '#sammlung-' + key;
        window.location.reload();
      });
    });
  });

  wurzel.addEventListener('click', function (ereignis) {
    var eintrag = ereignis.target.closest('[data-eintrag]');
    if (!eintrag) return;
    var sammlungElement = eintrag.closest('[data-sammlung]');
    var key = sammlungElement && sammlungElement.dataset.sammlung;

    if (ereignis.target.closest('.eintrag-loeschen')) {
      if (!window.confirm('Diesen Eintrag löschen?')) return;
      senden('/projekt/' + projektSlug + '/sammlung/' + key + '/' + eintrag.dataset.eintrag + '/loeschen', {})
        .then(function () { window.location.reload(); });
    } else if (ereignis.target.closest('.eintrag-wiederherstellen')) {
      senden('/projekt/' + projektSlug + '/sammlung/' + key + '/' + eintrag.dataset.eintrag + '/wiederherstellen', {})
        .then(function () { window.location.reload(); });
    } else if (ereignis.target.closest('.eintrag-hoch') || ereignis.target.closest('.eintrag-runter')) {
      var hoch = Boolean(ereignis.target.closest('.eintrag-hoch'));
      var nachbar = hoch ? eintrag.previousElementSibling : eintrag.nextElementSibling;
      if (!nachbar) return;
      if (hoch) nachbar.before(eintrag); else nachbar.after(eintrag);
      var ids = [];
      sammlungElement.querySelectorAll('[data-eintrag]').forEach(function (element) {
        ids.push(Number(element.dataset.eintrag));
      });
      senden('/projekt/' + projektSlug + '/sammlung/' + key + '/sortierung', { ids: ids });
    }
  });

  // ---- Veröffentlichen --------------------------------------------------

  var veroeffentlichenKnopf = document.getElementById('veroeffentlichen');
  var meldung = document.getElementById('publish-meldung');
  function meldungZeigen(text, ok) {
    if (!meldung) return;
    meldung.textContent = text;
    meldung.classList.remove('versteckt', 'hinweis-ok', 'hinweis-fehler');
    meldung.classList.add(ok ? 'hinweis-ok' : 'hinweis-fehler');
    if (ok) setTimeout(function () { meldung.classList.add('versteckt'); }, 9000);
  }
  if (veroeffentlichenKnopf) {
    veroeffentlichenKnopf.addEventListener('click', function () {
      veroeffentlichenKnopf.disabled = true;
      veroeffentlichenKnopf.textContent = 'Wird veröffentlicht …';
      // still: true → eigene Meldung, damit nie "Speichern fehlgeschlagen" beim Veröffentlichen erscheint
      senden('/projekt/' + projektSlug + '/veroeffentlichen', {}, { still: true }).then(function (körper) {
        veroeffentlichenKnopf.disabled = false;
        veroeffentlichenKnopf.textContent = 'Veröffentlichen';
        entwurfAnzeigen(false);
        meldungZeigen((körper.deploy && körper.deploy.meldung) || 'Veröffentlicht.', true);
      }).catch(function () {
        veroeffentlichenKnopf.disabled = false;
        veroeffentlichenKnopf.textContent = 'Veröffentlichen';
        meldungZeigen('Das Veröffentlichen hat gerade nicht geklappt. Bitte lade die Seite neu und versuche es nochmals.', false);
      });
    });
  }

  // ---- Bereiche ein-/ausblenden ----------------------------------------
  wurzel.addEventListener('change', function (ereignis) {
    var schalter = ereignis.target.closest('[data-bereich-schalter]');
    if (!schalter) return;
    var zeile = schalter.closest('[data-bereich]');
    var key = zeile.dataset.bereich;
    var sichtbar = schalter.checked;
    zeile.classList.toggle('aus', !sichtbar);
    senden('/projekt/' + projektSlug + '/bereich/' + encodeURIComponent(key) + '/sichtbarkeit', { sichtbar: sichtbar });
  });

  // ---- Live-Vorschau ----------------------------------------------------

  var iframe = document.getElementById('vorschau-iframe');
  if (iframe && vorschauUrl) {
    iframe.src = vorschauUrl;
  }
  function vorschauAktualisieren(key, wert) {
    if (!iframe || !iframe.contentWindow) return;
    iframe.contentWindow.postMessage(
      { typ: 'qom-vorschau', feld: key, wert: wert },
      '*'
    );
  }
})();
