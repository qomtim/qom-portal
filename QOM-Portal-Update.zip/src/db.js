// Datenbank-Zugriff. Eine SQLite-Datei, Zugriff ausschliesslich über
// Prepared Statements (better-sqlite3 erzwingt das ohnehin).
import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { neuesToken } from './security.js';

fs.mkdirSync(path.dirname(config.dbPfad), { recursive: true });
fs.mkdirSync(config.uploadsVerzeichnis, { recursive: true });

export const db = new Database(config.dbPfad);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pw_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  is_admin INTEGER NOT NULL DEFAULT 0,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('owner','staff','customer')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  website_url TEXT NOT NULL DEFAULT '',
  alte_seite_url TEXT NOT NULL DEFAULT '',
  google_drive_url TEXT NOT NULL DEFAULT '',
  bemerkungen TEXT NOT NULL DEFAULT '',
  deploy_webhook_url TEXT NOT NULL DEFAULT '',
  generierung_webhook_url TEXT NOT NULL DEFAULT '',
  generierung_status TEXT NOT NULL DEFAULT '',
  generierung_am TEXT,
  api_token TEXT NOT NULL,
  preview_token TEXT NOT NULL,
  metrics_token TEXT NOT NULL DEFAULT '',
  logo_url TEXT NOT NULL DEFAULT '',
  projekt_typ TEXT NOT NULL DEFAULT 'website' CHECK (projekt_typ IN ('website','ads','beides')),
  meta_ad_account_id TEXT NOT NULL DEFAULT '',
  meta_konto_name TEXT NOT NULL DEFAULT '',
  blog_aktiv INTEGER NOT NULL DEFAULT 0,
  kunde_darf_bilder INTEGER NOT NULL DEFAULT 1,
  kunde_darf_sammlungen INTEGER NOT NULL DEFAULT 1,
  kunde_darf_seiten_schalten INTEGER NOT NULL DEFAULT 0,
  freigabe_webhook_url TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS memberships (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'editor' CHECK (role IN ('admin','editor')),
  PRIMARY KEY (user_id, project_id)
);

CREATE TABLE IF NOT EXISTS fields (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  group_label TEXT NOT NULL DEFAULT '',
  field_label TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'text' CHECK (type IN ('text','textarea','image')),
  value_draft TEXT NOT NULL DEFAULT '',
  value_published TEXT NOT NULL DEFAULT '',
  editable_by_editor INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  UNIQUE (project_id, key)
);

CREATE TABLE IF NOT EXISTS collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  label TEXT NOT NULL,
  item_schema TEXT NOT NULL DEFAULT '[]',
  editable_by_editor INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  UNIQUE (project_id, key)
);

CREATE TABLE IF NOT EXISTS collection_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id INTEGER NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
  data_draft TEXT NOT NULL DEFAULT '{}',
  data_published TEXT NOT NULL DEFAULT '{}',
  geloescht_draft INTEGER NOT NULL DEFAULT 0,
  sort INTEGER NOT NULL DEFAULT 0
);

-- Bereiche/Seiten, die der Kunde ein- und ausblenden kann
CREATE TABLE IF NOT EXISTS sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  label TEXT NOT NULL,
  sichtbar_draft INTEGER NOT NULL DEFAULT 1,
  sichtbar_published INTEGER NOT NULL DEFAULT 1,
  editor_darf_schalten INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  UNIQUE (project_id, key)
);

-- Bild-Ablage pro Projekt: Grundlage für die Website-Generierung.
-- Hierhin lädt das QOM-Team die echten Kundenbilder; Claude baut die
-- Sektionen passend zu den vorhandenen Bildern.
CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  dateiname TEXT NOT NULL,
  url TEXT NOT NULL,
  beschreibung TEXT NOT NULL DEFAULT '',   -- z.B. "Team", "Logo", "Hero", "Referenz"
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Meta-Ads-Kennzahlen: ein Schnappschuss pro Tag und Projekt (von n8n befüllt)
CREATE TABLE IF NOT EXISTS ad_metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  tag TEXT NOT NULL,                    -- 'JJJJ-MM-TT'
  spend REAL NOT NULL DEFAULT 0,        -- Ausgaben
  impressions INTEGER NOT NULL DEFAULT 0,
  reach INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  cpm REAL NOT NULL DEFAULT 0,
  ctr REAL NOT NULL DEFAULT 0,
  cpc REAL NOT NULL DEFAULT 0,
  purchases INTEGER NOT NULL DEFAULT 0,
  cost_per_purchase REAL NOT NULL DEFAULT 0,
  results INTEGER NOT NULL DEFAULT 0,   -- Ergebnisse (z.B. Leads)
  leads INTEGER NOT NULL DEFAULT 0,
  waehrung TEXT NOT NULL DEFAULT 'CHF',
  zusatz TEXT NOT NULL DEFAULT '{}',    -- beliebige weitere Kennzahlen als JSON
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (project_id, tag)
);

-- Videos zur Freigabe durch den Kunden
CREATE TABLE IF NOT EXISTS ad_videos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  titel TEXT NOT NULL DEFAULT '',
  drive_url TEXT NOT NULL DEFAULT '',
  thumbnail_url TEXT NOT NULL DEFAULT '',
  notiz TEXT NOT NULL DEFAULT '',       -- Notiz von QOM an den Kunden
  status TEXT NOT NULL DEFAULT 'neu' CHECK (status IN ('neu','freigegeben','aenderung_gewuenscht')),
  kommentar TEXT NOT NULL DEFAULT '',   -- Rückmeldung des Kunden
  sort INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  entschieden_am TEXT,
  entschieden_von INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT '',
  slug TEXT NOT NULL,
  cover_url TEXT NOT NULL DEFAULT '',
  teaser TEXT NOT NULL DEFAULT '',
  body_html TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  published_at TEXT,
  author_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (project_id, slug)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  aktion TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS invites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL UNIQUE,
  project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  email TEXT NOT NULL COLLATE NOCASE,
  role TEXT NOT NULL DEFAULT 'editor',
  neue_rolle TEXT NOT NULL DEFAULT 'customer',
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS password_resets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  used_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_fields_project ON fields(project_id, sort);
CREATE INDEX IF NOT EXISTS idx_items_collection ON collection_items(collection_id, sort);
CREATE INDEX IF NOT EXISTS idx_sections_project ON sections(project_id, sort);
CREATE INDEX IF NOT EXISTS idx_posts_project ON posts(project_id, status);
CREATE INDEX IF NOT EXISTS idx_audit_project ON audit_log(project_id, created_at);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_metrics_project ON ad_metrics(project_id, tag);
CREATE INDEX IF NOT EXISTS idx_videos_project ON ad_videos(project_id, sort);
CREATE INDEX IF NOT EXISTS idx_assets_project ON assets(project_id, created_at);
`);

// --- Migration für bereits bestehende Datenbanken -----------------------
// Fügt neue Spalten hinzu, falls die DB aus einer früheren Version stammt.
function spalten(tabelle) {
  return new Set(db.prepare(`PRAGMA table_info(${tabelle})`).all().map((z) => z.name));
}
function spalteSicherstellen(tabelle, name, definition) {
  if (!spalten(tabelle).has(name)) {
    db.exec(`ALTER TABLE ${tabelle} ADD COLUMN ${name} ${definition}`);
  }
}
spalteSicherstellen('users', 'role', `TEXT NOT NULL DEFAULT 'customer'`);
spalteSicherstellen('projects', 'alte_seite_url', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'google_drive_url', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'bemerkungen', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'generierung_webhook_url', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'generierung_status', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'generierung_am', `TEXT`);
spalteSicherstellen('projects', 'kunde_darf_bilder', `INTEGER NOT NULL DEFAULT 1`);
spalteSicherstellen('projects', 'kunde_darf_sammlungen', `INTEGER NOT NULL DEFAULT 1`);
spalteSicherstellen('projects', 'kunde_darf_seiten_schalten', `INTEGER NOT NULL DEFAULT 0`);
spalteSicherstellen('invites', 'neue_rolle', `TEXT NOT NULL DEFAULT 'customer'`);
spalteSicherstellen('projects', 'metrics_token', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'projekt_typ', `TEXT NOT NULL DEFAULT 'website'`);
spalteSicherstellen('projects', 'freigabe_webhook_url', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'meta_ad_account_id', `TEXT NOT NULL DEFAULT ''`);
spalteSicherstellen('projects', 'meta_konto_name', `TEXT NOT NULL DEFAULT ''`);

// Fehlende Kennzahlen-Tokens nachziehen (jedes Projekt braucht ein eigenes)
for (const p of db.prepare(`SELECT id FROM projects WHERE metrics_token = '' OR metrics_token IS NULL`).all()) {
  db.prepare(`UPDATE projects SET metrics_token = ? WHERE id = ?`).run(neuesToken(), p.id);
}

// Alte is_admin-Nutzer sind Geschäftsführer (owner)
db.prepare(`UPDATE users SET role = 'owner' WHERE is_admin = 1 AND role != 'owner'`).run();
db.prepare(`UPDATE users SET is_admin = 1 WHERE role = 'owner' AND is_admin = 0`).run();

// Abgelaufene Sessions gelegentlich aufräumen
db.prepare(`DELETE FROM sessions WHERE expires_at < datetime('now')`).run();

export function audit(userId, projectId, aktion, details = '') {
  db.prepare(
    `INSERT INTO audit_log (user_id, project_id, aktion, details) VALUES (?, ?, ?, ?)`
  ).run(userId ?? null, projectId ?? null, aktion, details);
}
