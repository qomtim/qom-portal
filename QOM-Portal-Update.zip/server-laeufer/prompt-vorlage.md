Du baust eine vollständige, moderne Website für einen Kunden der Agentur QOM.

KUNDE: {{NAME}}
BESTEHENDE/ALTE SEITE (falls vorhanden, als Referenz): {{ALTE_SEITE}}
GOOGLE-DRIVE-ORDNER (Bilder, Dokumente, Kick-off, Meetings): {{DRIVE}}
BEMERKUNGEN / WÜNSCHE: {{BEMERKUNGEN}}

AUFGABE:
1. Baue eine komplette Astro-Website (statischer Output) im Unterordner ./site.
   Modernes, sauberes Design, mobil-first, schnell. Inhalte auf Deutsch (CH-Hochdeutsch, ss statt ß).
2. Verdrahte die Seite mit dem QOM-Portal, damit der Kunde Texte/Bilder später selbst ändern kann:
   - Hol die Inhalte zur Build-Zeit von:
     {{PORTAL_URL}}/api/v1/projects/{{SLUG}}/content?token={{API_TOKEN}}
   - Baue die Live-Vorschau ein (Skript aus website-integration/preview.js), das den
     Entwurfs-Stand mit ?preview={{PREVIEW_TOKEN}} lädt.
   - Markiere die bearbeitbaren Stellen mit data-qom="feldkey" und Bereiche mit data-qom-bereich="key".
3. Lege die bearbeitbaren Inhalte im Portal an, indem du sie an diesen Endpunkt schickst
   (POST JSON, Header x-runner-token: <RUNNER_TOKEN>):
     {{PORTAL_URL}}/api/v1/jobs/{{SLUG}}/content
   Format:
     { "felder": [ {"key":"startseite_titel","label":"Titel","group":"Startseite","type":"text","value":"…"}, … ],
       "bereiche": [ {"key":"team","label":"Team-Bereich"}, … ] }
   So erscheinen die Texte sofort im Editor des Kunden.

Wichtig: Verwende NUR Inhalte aus dem Drive/den Bemerkungen bzw. sinnvolle Platzhalter.
Erfinde keine Fakten (Preise, Referenzen, Zahlen), wenn sie nicht gegeben sind.
