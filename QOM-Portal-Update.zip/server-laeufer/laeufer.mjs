// QOM Generierungs-Läufer
// -----------------------------------------------------------------------------
// Läuft auf EUREM Server (nicht auf Infomaniak, nicht auf dem Kunden-Portal).
// Holt regelmässig offene Generierungs-Aufträge vom Portal ab und ruft für
// jeden Auftrag euer Generierungs-Skript (generiere.sh) auf – dort steckt der
// eigentliche Claude-Lauf + das Ausspielen der fertigen Website.
//
// Nur Node-Bordmittel, keine Abhängigkeiten. Node 22+.
//
// Konfiguration über Umgebungsvariablen (siehe .env.laeufer.beispiel):
//   PORTAL_URL       z.B. https://portal.quitordinarymarketing.ch
//   RUNNER_TOKEN     dasselbe Token wie RUNNER_TOKEN im Portal
//   ARBEITS_DIR      Arbeitsordner (Standard: ./arbeit)
//   GENERIERUNG_CMD  Befehl je Auftrag (Standard: ./generiere.sh)
//   INTERVALL_SEK    Abfrage-Intervall in Sekunden (Standard: 30)
//
// Start:  node --env-file-if-exists=.env.laeufer laeufer.mjs
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const PORTAL = (process.env.PORTAL_URL || '').replace(/\/+$/, '');
const TOKEN = process.env.RUNNER_TOKEN || '';
const ARBEIT = path.resolve(process.env.ARBEITS_DIR || './arbeit');
const CMD = process.env.GENERIERUNG_CMD || './generiere.sh';
const INTERVALL = Math.max(10, Number(process.env.INTERVALL_SEK || 30)) * 1000;

if (!PORTAL || !TOKEN) {
  console.error('Bitte PORTAL_URL und RUNNER_TOKEN setzen (z.B. in .env.laeufer).');
  process.exit(1);
}
fs.mkdirSync(ARBEIT, { recursive: true });

function log(...a) { console.log(new Date().toISOString(), ...a); }

async function jobsHolen() {
  const res = await fetch(`${PORTAL}/api/v1/jobs?token=${encodeURIComponent(TOKEN)}`, { signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(`Jobs abrufen: HTTP ${res.status}`);
  const data = await res.json();
  return Array.isArray(data.jobs) ? data.jobs : [];
}

async function statusMelden(slug, status, meldung = '') {
  try {
    await fetch(`${PORTAL}/api/v1/jobs/${encodeURIComponent(slug)}/status?token=${encodeURIComponent(TOKEN)}`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ status, meldung }), signal: AbortSignal.timeout(20000),
    });
  } catch (e) { log('Status-Meldung fehlgeschlagen:', e.message); }
}

function befehlAusfuehren(cmd, args, cwd, env) {
  return new Promise((resolve) => {
    const kind = spawn(cmd, args, { cwd, env: { ...process.env, ...env }, shell: true });
    let ausgabe = '';
    kind.stdout.on('data', (d) => { ausgabe += d; process.stdout.write(d); });
    kind.stderr.on('data', (d) => { ausgabe += d; process.stderr.write(d); });
    kind.on('close', (code) => resolve({ code, ausgabe }));
    kind.on('error', (err) => resolve({ code: 1, ausgabe: String(err) }));
  });
}

async function jobBearbeiten(job) {
  log(`Auftrag "${job.slug}" (${job.name}) gestartet.`);
  await statusMelden(job.slug, 'in_arbeit');

  const dir = path.join(ARBEIT, job.slug);
  fs.mkdirSync(dir, { recursive: true });
  // Auftrag als Datei ablegen, damit generiere.sh alles hat
  fs.writeFileSync(path.join(dir, 'auftrag.json'), JSON.stringify(job, null, 2));

  const env = {
    QOM_PORTAL_URL: PORTAL,
    QOM_RUNNER_TOKEN: TOKEN,
    QOM_SLUG: job.slug,
    QOM_NAME: job.name,
    QOM_TYP: job.projekt_typ,
    QOM_ALTE_SEITE: job.alte_seite_url || '',
    QOM_DRIVE: job.google_drive_url || '',
    QOM_BEMERKUNGEN: job.bemerkungen || '',
    QOM_AENDERUNG: job.aenderungswunsch || '',
    QOM_META_KONTO: job.meta_ad_account_id || '',
    QOM_API_TOKEN: job.api_token || '',
    QOM_PREVIEW_TOKEN: job.preview_token || '',
    QOM_WEBSITE_URL: job.website_url || '',
  };

  const { code, ausgabe } = await befehlAusfuehren(CMD, [job.slug, path.join(dir, 'auftrag.json')], dir, env);
  if (code === 0) {
    log(`Auftrag "${job.slug}" fertig.`);
    await statusMelden(job.slug, 'fertig', 'Website generiert.');
  } else {
    const tail = ausgabe.split('\n').slice(-8).join(' ').slice(0, 280);
    log(`Auftrag "${job.slug}" fehlgeschlagen (Code ${code}).`);
    await statusMelden(job.slug, 'fehler', tail);
  }
}

let laeuft = false;
async function durchlauf() {
  if (laeuft) return; // nie zwei Läufe parallel
  laeuft = true;
  try {
    const jobs = await jobsHolen();
    if (jobs.length) log(`${jobs.length} offene(r) Auftrag/Aufträge.`);
    for (const job of jobs) {
      try { await jobBearbeiten(job); }
      catch (e) { log('Fehler im Auftrag:', e.message); await statusMelden(job.slug, 'fehler', e.message); }
    }
  } catch (e) {
    log('Durchlauf-Fehler:', e.message);
  } finally {
    laeuft = false;
  }
}

log(`QOM Generierungs-Läufer gestartet. Portal: ${PORTAL} · Intervall: ${INTERVALL / 1000}s`);
durchlauf();
setInterval(durchlauf, INTERVALL);
