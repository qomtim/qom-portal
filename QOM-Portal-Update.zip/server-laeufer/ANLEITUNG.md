# Generierungs-Läufer – Einrichtung auf eurem Server

Der Läufer verbindet den Portal-Knopf „An Claude senden" mit dem echten Website-Bau.
Er läuft auf **eurem** always-on-Server (nicht auf Infomaniak, nicht im Kunden-Portal).

## Wie es zusammenspielt

1. Im Portal klickt QOM bei einem Projekt auf **„An Claude senden"** → der Auftrag steht auf `bereit`.
2. Der **Läufer** (dieses Verzeichnis) fragt das Portal alle 30 Sek: „gibt's offene Aufträge?"
3. Für jeden Auftrag ruft er **`generiere.sh`** auf → dort läuft **Claude** und baut die Website + spielt sie aus.
4. Der Läufer meldet den Status zurück (`in_arbeit` → `fertig` / `fehler`) – sichtbar im Portal.

## Voraussetzungen auf dem Server

- Node.js 22+
- Claude Code installiert **und mit eurem Konto angemeldet** (für den Abo-Weg) – ODER euer eigener Generierungs-Ablauf.
- Euer bestehendes Deploy-Werkzeug (z.B. Git + Astro-Build + FTP wie bei `qom-website`).

## Einrichtung (einmalig)

1. Diesen Ordner `server-laeufer/` auf den Server kopieren.
2. Ein **Läufer-Token** erzeugen:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"
   ```
   Diesen Wert an ZWEI Stellen eintragen:
   - hier in `.env.laeufer` als `RUNNER_TOKEN`
   - im **Portal** in der `.env` als `RUNNER_TOKEN` (danach Portal neu starten).
3. `.env.laeufer.beispiel` → `.env.laeufer` kopieren und ausfüllen.
4. In **`generiere.sh`** die zwei markierten Stellen einbauen:
   - den **Claude-Aufruf** (z.B. `claude -p "$(cat prompt.txt)" --dangerously-skip-permissions`),
   - das **Ausspielen** der fertigen Seite (euer Deploy).
5. Testlauf:
   ```bash
   chmod +x generiere.sh
   node --env-file-if-exists=.env.laeufer laeufer.mjs
   ```
   Im Portal ein Projekt anlegen und „An Claude senden" drücken – der Läufer sollte den Auftrag abholen.

## Dauerbetrieb

Als Dienst laufen lassen, damit er nicht stirbt – z.B. mit `pm2`:
```bash
pm2 start "node --env-file-if-exists=.env.laeufer laeufer.mjs" --name qom-laeufer
pm2 save
```
oder per `systemd`-Service.

## Hinweis zum Abo vs. API

Claude Code über euer **Abo** headless als Server-Dienst zu betreiben, kann an Nutzungslimits stossen und
läuft möglicherweise gegen die Abo-Nutzungsbedingungen (die **API** ist der dafür vorgesehene, stabile Weg).
Für kleine Stückzahlen ist der Abo-Weg praktikabel; bei mehr Volumen die API erwägen. Der Läufer funktioniert
mit beidem – der Unterschied steckt nur in `generiere.sh`.
