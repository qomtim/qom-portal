#!/usr/bin/env bash
# QOM Generierungs-Skript – wird vom Läufer pro Auftrag aufgerufen.
# HIER steckt euer eigentlicher Ablauf. Passt die markierten Stellen an.
#
# Der Läufer setzt diese Umgebungsvariablen:
#   QOM_PORTAL_URL, QOM_RUNNER_TOKEN, QOM_SLUG, QOM_NAME, QOM_TYP,
#   QOM_ALTE_SEITE, QOM_DRIVE, QOM_BEMERKUNGEN, QOM_META_KONTO,
#   QOM_API_TOKEN, QOM_PREVIEW_TOKEN, QOM_WEBSITE_URL
# Arbeitsverzeichnis ist bereits der Auftragsordner; auftrag.json liegt hier.
set -euo pipefail

echo "== Generierung für ${QOM_NAME} (${QOM_SLUG}) =="

# --- 1) Prompt für Claude aus der Vorlage bauen -----------------------------
PROMPT_VORLAGE="$(dirname "$0")/prompt-vorlage.md"
PROMPT="$(sed \
  -e "s|{{NAME}}|${QOM_NAME}|g" \
  -e "s|{{SLUG}}|${QOM_SLUG}|g" \
  -e "s|{{ALTE_SEITE}}|${QOM_ALTE_SEITE}|g" \
  -e "s|{{DRIVE}}|${QOM_DRIVE}|g" \
  -e "s|{{BEMERKUNGEN}}|${QOM_BEMERKUNGEN}|g" \
  -e "s|{{PORTAL_URL}}|${QOM_PORTAL_URL}|g" \
  -e "s|{{API_TOKEN}}|${QOM_API_TOKEN}|g" \
  -e "s|{{PREVIEW_TOKEN}}|${QOM_PREVIEW_TOKEN}|g" \
  "$PROMPT_VORLAGE")"

# --- 2) Claude laufen lassen -------------------------------------------------
# ANPASSEN: So startest du Claude Code headless (nutzt dein Abo, wenn Claude Code
# auf diesem Server mit deinem Konto angemeldet ist). Alternativ euren eigenen Ablauf.
#
#   claude -p "$PROMPT" --dangerously-skip-permissions
#
# Wichtig: Claude soll die Website in einem Unterordner ./site bauen und die
# Start-Inhalte per Portal-API einspielen (Details in prompt-vorlage.md).

echo "$PROMPT" > prompt.txt
echo "TODO: Claude-Aufruf hier einbauen (siehe prompt.txt). Beispiel:"
echo "  claude -p \"\$(cat prompt.txt)\" --dangerously-skip-permissions"

# --- 3) Fertige Seite ausspielen --------------------------------------------
# ANPASSEN: euren bestehenden Deploy nutzen (z.B. git push + Astro-Build + FTP,
# wie bei qom-website mit scripts/deploy-ftp.mjs).
#
#   (cd site && npm ci && npm run build && node scripts/deploy-ftp.mjs)

echo "== Fertig (Platzhalter). Baue Schritt 2 und 3 ein, dann läuft es echt. =="
