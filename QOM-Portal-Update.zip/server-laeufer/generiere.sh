#!/usr/bin/env bash
# QOM Website-Generierung: baut/überarbeitet eine Astro-Website mit Claude
# und spielt sie auf dem Test-Server aus. Wird vom Läufer (laeufer.mjs) pro
# Auftrag aufgerufen; cwd = Arbeitsordner des Auftrags (mit auftrag.json).
set -uo pipefail
SLUG="${QOM_SLUG:?}"; NAME="${QOM_NAME:-$SLUG}"
IP="187.124.170.89"; PORT="48080"; BASE="/$SLUG/"
TESTURL="http://$IP:$PORT$BASE"; WEBROOT="/var/www/qom-test/$SLUG"
ALT="${QOM_ALTE_SEITE:-}"; DRIVE="${QOM_DRIVE:-}"; BEM="${QOM_BEMERKUNGEN:-}"

# Bild-Ablage aus dem Auftrag lesen (vom Portal befüllt, absolute URLs).
BILDER=""
if [ -f auftrag.json ]; then
  BILDER=$(node -e 'let fs=require("fs"),j={};try{j=JSON.parse(fs.readFileSync("./auftrag.json","utf8"))}catch(e){}const b=(j.bilder||[]);console.log(b.map(x=>"- "+x.url+(x.beschreibung?"  (Verwendung: "+x.beschreibung+")":"")).join("\n"))' 2>/dev/null)
fi
if [ -n "$BILDER" ]; then
  BILD_ANWEISUNG="ECHTE KUNDENBILDER — verwende GENAU diese Bilder (absolute URLs direkt im <img src>, loading=\"lazy\") und baue die Sektionen PASSEND dazu: Logo -> Kopf/Header, Team-Fotos -> Team-Block, Referenz-/Produktbilder -> Galerie/Referenzen, ein grosses Bild -> Hero. Nutze die Beschriftung als Hinweis. Wenn fuer eine Sektion zu wenige Bilder da sind, ergaenze dezent via https://loremflickr.com/<breite>/<hoehe>/<stichwort>. Bilder:
$BILDER"
else
  BILD_ANWEISUNG="Keine Kundenbilder hinterlegt. Nutze professionelle, thematisch passende Platzhalter-Fotos via https://loremflickr.com/<breite>/<hoehe>/<stichwort> (branchen-passende englische Stichworte, absolute URLs, loading=\"lazy\"). MINDESTENS 5-6 Bilder ueber die Seite verteilt."
fi

if [ -d site ] && [ -f site/package.json ]; then MODUS="ueberarbeiten"; else MODUS="neu"; rm -rf site; fi
echo "== $MODUS: Website fuer $NAME ($SLUG) =="

if [ "$MODUS" = "neu" ]; then
read -r -d '' PROMPT <<PROMPT_END || true
Baue eine vollstaendige, moderne, sehr professionelle Astro-Website (statischer Output) fuer den Kunden "$NAME".

QUELLEN: Alte Website ${ALT:-keine} (falls URL: mit WebFetch echte Inhalte/Ton uebernehmen, keine erfundenen Fakten). Bemerkungen/Wuensche: ${BEM:-keine}.

BILDER: $BILD_ANWEISUNG

STRUKTUR:
1) Astro-Projekt in ./site, astro.config.mjs output:'static', base:'$BASE', Assets ueber import.meta.env.BASE_URL.
2) Startseite: Hero mit grossem Bild, Leistungen (mit Bildern), Ueber uns/USP, Referenzen/Galerie (Bilder), Kontakt mit Formular (nur Optik).
3) PFLICHT-Unterseiten src/pages/impressum.astro und src/pages/datenschutz.astro (uebliche CH-Pflichtangaben als Platzhalter), im Footer verlinkt.
4) Hochwertiges, responsives Design (mobil-first), viel Weissraum, CH-Hochdeutsch (ss statt scharfem s).
5) Wichtige Texte mit data-qom="key" markieren. Rein statisch, kein Backend. Baue jetzt alles in ./site.
PROMPT_END
else
read -r -d '' PROMPT <<PROMPT_END || true
Die bestehende Astro-Website liegt in ./site. Lies sie und UEBERARBEITE sie gemaess: ${BEM:-Design und Inhalte dezent verbessern.} . Behalte Struktur, base:'$BASE' und statischen Output.
BILDER: $BILD_ANWEISUNG
Keine erfundenen Fakten. CH-Hochdeutsch (ss). Danach muss "npm run build" in ./site sauber durchlaufen.
PROMPT_END
fi

claude -p "$PROMPT" --dangerously-skip-permissions < /dev/null 2>&1
if [ ! -f site/package.json ]; then echo "FEHLER: kein ./site erzeugt"; exit 1; fi
echo "== Baue die Seite =="
( cd site && npm install --no-audit --no-fund >/dev/null 2>&1; (npm run build || npx astro build) 2>&1 | tail -20 )
if [ ! -d site/dist ]; then echo "FEHLER: Build fehlgeschlagen (site/dist fehlt)"; exit 1; fi
mkdir -p "$WEBROOT"; rm -rf "${WEBROOT:?}/"*; cp -r site/dist/* "$WEBROOT"/
echo "TESTURL=$TESTURL"; echo "== FERTIG ($MODUS): $TESTURL =="
