// Zentrale Konfiguration. Werte kommen aus Umgebungsvariablen (.env),
// mit sicheren Standardwerten für die lokale Entwicklung.
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const projektWurzel = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export const config = {
  env: process.env.NODE_ENV || 'development',
  istProduktion: (process.env.NODE_ENV || 'development') === 'production',

  host: process.env.HOST || '127.0.0.1',
  port: Number(process.env.PORT || 3000),

  // Proxy-Vertrauen: NUR aktivieren, wenn hinter einem bekannten Reverse-Proxy.
  // Pauschal 'true' würde erlauben, die eigene IP per X-Forwarded-For zu fälschen
  // und so das Login-Ratenlimit auszuhebeln. Standard: aus (false).
  // Mögliche Werte: 'true' | 'false' | Anzahl Hops (z.B. '1') | Proxy-IP/Subnetz.
  get trustProxy() {
    const wert = process.env.TRUST_PROXY;
    if (wert == null || wert === '' || wert === 'false') return false;
    if (wert === 'true') return true;
    if (/^\d+$/.test(wert)) return Number(wert);
    return wert;
  },

  // Öffentliche Basis-URL des CMS (für Links in E-Mails)
  baseUrl: process.env.BASE_URL || `http://127.0.0.1:${process.env.PORT || 3000}`,

  datenVerzeichnis: process.env.DATA_DIR || path.join(projektWurzel, 'data'),
  get dbPfad() {
    return process.env.DB_PATH || path.join(this.datenVerzeichnis, 'qom-cms.db');
  },
  get uploadsVerzeichnis() {
    return process.env.UPLOADS_DIR || path.join(this.datenVerzeichnis, 'uploads');
  },

  // Session-Laufzeit: 14 Tage, Einladungen: 7 Tage, Passwort-Reset: 2 Stunden
  sessionDauerMs: 14 * 24 * 60 * 60 * 1000,
  einladungDauerMs: 7 * 24 * 60 * 60 * 1000,
  resetDauerMs: 2 * 60 * 60 * 1000,

  uploadMaxBytes: 15 * 1024 * 1024, // 15 MB pro Bild (vor der Optimierung)
  bildMaxPixel: 2400,

  // Standard-Webhook, der eine neue Website von Claude generieren lässt
  // (z.B. ein n8n-Workflow). Pro Projekt überschreibbar.
  generierungWebhookUrl: process.env.GENERIERUNG_WEBHOOK_URL || '',

  smtp: {
    host: process.env.SMTP_HOST || '',
    port: Number(process.env.SMTP_PORT || 465),
    secure: process.env.SMTP_SECURE !== 'false',
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    absender: process.env.SMTP_FROM || 'QOM Editor <editor@quitordinarymarketing.ch>',
  },
};
