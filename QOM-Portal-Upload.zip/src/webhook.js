// Ruft externe Webhooks auf: (1) den Deploy-Webhook nach dem Veröffentlichen,
// (2) den Generierungs-Webhook, der eine neue Website von Claude bauen lässt.
// Fehler dürfen die Bedienung nie blockieren – sie werden nur gemeldet.
import { db, audit } from './db.js';
import { config } from './config.js';
import { mailSenden } from './mailer.js';

export async function deployAusloesen(projekt, userId) {
  if (!projekt.deploy_webhook_url) {
    // Kundenfreundlich formuliert, ohne Fachbegriffe
    return { ok: false, meldung: 'Deine Änderungen sind gespeichert. Die Website wird noch nicht automatisch neu gebaut – QOM richtet das ein.' };
  }
  try {
    const antwort = await fetch(projekt.deploy_webhook_url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        quelle: 'qom-editor',
        projekt: projekt.slug,
        zeitpunkt: new Date().toISOString(),
      }),
      signal: AbortSignal.timeout(15000),
    });
    audit(userId, projekt.id, 'deploy_webhook', antwort.ok ? `HTTP ${antwort.status}` : `FEHLER HTTP ${antwort.status}`);
    return antwort.ok
      ? { ok: true, meldung: 'Deine Änderungen sind in ca. 2 Minuten online.' }
      : { ok: false, meldung: 'Deine Änderungen sind gespeichert. Das automatische Aktualisieren hat gerade nicht geklappt – QOM kümmert sich darum.' };
  } catch (fehler) {
    audit(userId, projekt.id, 'deploy_webhook', `FEHLER ${fehler.message}`);
    return { ok: false, meldung: 'Deine Änderungen sind gespeichert. Die Website konnte gerade nicht aktualisiert werden – QOM prüft das.' };
  }
}

// Schickt einen Auftrag an den Generierungs-Workflow (z.B. n8n), der auf einem
// Server Claude anstösst, um die Website zu erstellen/zu aktualisieren.
export async function generierungAusloesen(projekt, nutzer) {
  const ziel = projekt.generierung_webhook_url || config.generierungWebhookUrl;
  if (!ziel) {
    return { ok: false, meldung: 'Es ist noch kein Generierungs-Dienst hinterlegt. Trag den n8n-Webhook in den Projekteinstellungen (oder als GENERIERUNG_WEBHOOK_URL) ein.' };
  }
  const nutzlast = {
    quelle: 'qom-editor',
    aktion: 'website-generieren',
    projekt: { slug: projekt.slug, name: projekt.name },
    kunde: projekt.name,
    alte_seite_url: projekt.alte_seite_url || '',
    google_drive_url: projekt.google_drive_url || '',
    bemerkungen: projekt.bemerkungen || '',
    api_token: projekt.api_token,
    zeitpunkt: new Date().toISOString(),
    ausgeloest_von: nutzer ? { name: nutzer.name, email: nutzer.email } : null,
  };
  try {
    const antwort = await fetch(ziel, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(nutzlast),
      signal: AbortSignal.timeout(20000),
    });
    const ok = antwort.ok;
    const status = ok ? 'gesendet' : `fehler-http-${antwort.status}`;
    db.prepare(`UPDATE projects SET generierung_status = ?, generierung_am = datetime('now') WHERE id = ?`)
      .run(status, projekt.id);
    audit(nutzer?.id, projekt.id, 'generierung_ausgeloest', ok ? 'gesendet' : `HTTP ${antwort.status}`);
    return ok
      ? { ok: true, meldung: 'Auftrag gesendet – Claude erstellt die Website im Hintergrund. Das dauert je nach Umfang einige Minuten.' }
      : { ok: false, meldung: `Der Generierungs-Dienst antwortete mit Status ${antwort.status}.` };
  } catch (fehler) {
    db.prepare(`UPDATE projects SET generierung_status = ?, generierung_am = datetime('now') WHERE id = ?`)
      .run(`fehler: ${fehler.message}`.slice(0, 120), projekt.id);
    audit(nutzer?.id, projekt.id, 'generierung_ausgeloest', `FEHLER ${fehler.message}`);
    return { ok: false, meldung: 'Der Generierungs-Dienst war nicht erreichbar. Bitte prüfe den n8n-Webhook.' };
  }
}

// Meldet QOM, wenn ein Kunde ein Video freigibt oder eine Änderung wünscht:
// E-Mail an alle Geschäftsführer + optionaler Freigabe-Webhook (n8n).
export async function freigabeMelden(projekt, video, nutzer) {
  const statusText = video.status === 'freigegeben' ? 'FREIGEGEBEN' : 'ÄNDERUNG GEWÜNSCHT';
  // 1) E-Mail an alle Geschäftsführer
  try {
    const owner = db.prepare(`SELECT email, name FROM users WHERE role = 'owner'`).all();
    for (const person of owner) {
      await mailSenden({
        an: person.email,
        betreff: `Video ${statusText}: ${projekt.name} – ${video.titel || 'Video'}`,
        text: `${nutzer?.name || 'Ein Kunde'} hat im QOM-Portal ein Video als "${statusText}" markiert.\n\n`
          + `Projekt: ${projekt.name}\nVideo: ${video.titel || video.drive_url}\nLink: ${video.drive_url}\n`
          + `Rückmeldung: ${video.kommentar || '(keine)'}\n`,
      });
    }
  } catch (fehler) {
    audit(nutzer?.id, projekt.id, 'freigabe_mail_fehler', fehler.message);
  }
  // 2) Optionaler Webhook (z.B. n8n) für die Weiterverarbeitung
  const ziel = projekt.freigabe_webhook_url;
  if (ziel) {
    try {
      await fetch(ziel, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          quelle: 'qom-editor',
          aktion: 'video-freigabe',
          projekt: { slug: projekt.slug, name: projekt.name },
          video: { id: video.id, titel: video.titel, drive_url: video.drive_url, status: video.status, kommentar: video.kommentar },
          von: nutzer ? { name: nutzer.name, email: nutzer.email } : null,
          zeitpunkt: new Date().toISOString(),
        }),
        signal: AbortSignal.timeout(15000),
      });
    } catch (fehler) {
      audit(nutzer?.id, projekt.id, 'freigabe_webhook_fehler', fehler.message);
    }
  }
}
