// Login, Logout, Einladungen und Passwort-Reset.
import { db, audit } from '../db.js';
import { config } from '../config.js';
import { passwortHashen, passwortPruefen, neuesToken, sqliteZeitStempel } from '../security.js';
import { sessionErstellen, sessionBeenden, projekteDesNutzers } from '../auth.js';
import { mailSenden } from '../mailer.js';

const loginRateLimit = {
  config: {
    rateLimit: { max: 10, timeWindow: '1 minute' },
  },
};

// Kontobezogener Brute-Force-Schutz (zusätzlich zum IP-Ratenlimit):
// zählt Fehlversuche pro E-Mail und sperrt nach zu vielen kurz.
const loginFehlversuche = new Map(); // email -> { anzahl, gesperrtBis }
const MAX_FEHLVERSUCHE = 8;
const SPERRE_MS = 15 * 60 * 1000;

function loginGesperrt(email) {
  const e = loginFehlversuche.get(String(email).toLowerCase());
  return e && e.gesperrtBis && e.gesperrtBis > Date.now();
}
function loginFehlgeschlagen(email) {
  const key = String(email).toLowerCase();
  const e = loginFehlversuche.get(key) || { anzahl: 0, gesperrtBis: 0 };
  e.anzahl += 1;
  if (e.anzahl >= MAX_FEHLVERSUCHE) {
    e.gesperrtBis = Date.now() + SPERRE_MS;
    e.anzahl = 0;
  }
  loginFehlversuche.set(key, e);
}
function loginErfolgreich(email) {
  loginFehlversuche.delete(String(email).toLowerCase());
}

export async function authRouten(app) {
  app.get('/', async (request, reply) => {
    if (!request.nutzer) return reply.redirect('/login');
    return reply.redirect('/projekte');
  });

  app.get('/login', async (request, reply) => {
    if (request.nutzer) return reply.redirect('/projekte');
    return reply.view('login.njk', { csrf: request.csrfToken });
  });

  app.post('/login', loginRateLimit, async (request, reply) => {
    const { email, passwort } = request.body || {};
    const emailNorm = String(email || '').trim();

    if (loginGesperrt(emailNorm)) {
      return reply.view('login.njk', {
        csrf: request.csrfToken,
        fehler: 'Zu viele Fehlversuche. Bitte versuche es in einigen Minuten erneut oder setze dein Passwort zurück.',
        email: emailNorm,
      });
    }

    const nutzer = db.prepare(`SELECT * FROM users WHERE email = ?`).get(emailNorm);
    const ok = nutzer && await passwortPruefen(nutzer.pw_hash, String(passwort || ''));
    if (!ok) {
      // Auch bei unbekannter E-Mail einen Hash prüfen, damit die Antwortzeit
      // nicht verrät, ob die Adresse existiert.
      if (!nutzer) await passwortPruefen('$argon2id$v=19$m=65536,t=3,p=4$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA', 'x');
      loginFehlgeschlagen(emailNorm);
      return reply.view('login.njk', {
        csrf: request.csrfToken,
        fehler: 'E-Mail oder Passwort stimmt nicht.',
        email: emailNorm,
      });
    }
    loginErfolgreich(emailNorm);
    sessionErstellen(reply, nutzer.id);
    audit(nutzer.id, null, 'login', '');
    return reply.redirect('/projekte');
  });

  app.post('/logout', async (request, reply) => {
    sessionBeenden(request, reply);
    return reply.redirect('/login');
  });

  // Übersicht: welche Projekte darf ich bearbeiten?
  app.get('/projekte', async (request, reply) => {
    if (!request.nutzer) return reply.redirect('/login');
    const projekte = projekteDesNutzers(request.nutzer);
    if (projekte.length === 1 && !request.nutzer.is_admin) {
      return reply.redirect(`/projekt/${projekte[0].slug}`);
    }
    return reply.view('projekte.njk', {
      nutzer: request.nutzer,
      projekte,
      csrf: request.csrfToken,
    });
  });

  // ---- Einladung annehmen ----------------------------------------------

  function gueltigeEinladung(token) {
    return db.prepare(
      `SELECT i.*, p.name AS projekt_name, p.slug AS projekt_slug
         FROM invites i JOIN projects p ON p.id = i.project_id
        WHERE i.token = ? AND i.used_at IS NULL AND i.expires_at > datetime('now')`
    ).get(token);
  }

  app.get('/einladung/:token', async (request, reply) => {
    const einladung = gueltigeEinladung(request.params.token);
    if (!einladung) {
      return reply.view('fehler.njk', {
        titel: 'Einladung nicht mehr gültig',
        meldung: 'Dieser Einladungs-Link ist abgelaufen oder wurde schon verwendet. Bitte melde dich bei QOM für einen neuen Link.',
      });
    }
    const bestehend = db.prepare(`SELECT id FROM users WHERE email = ?`).get(einladung.email);
    return reply.view('einladung.njk', {
      csrf: request.csrfToken,
      einladung,
      nutzerExistiert: Boolean(bestehend),
    });
  });

  app.post('/einladung/:token', loginRateLimit, async (request, reply) => {
    const einladung = gueltigeEinladung(request.params.token);
    if (!einladung) return reply.redirect(`/einladung/${request.params.token}`);

    const { name, passwort } = request.body || {};
    let nutzer = db.prepare(`SELECT * FROM users WHERE email = ?`).get(einladung.email);

    if (!nutzer) {
      if (!name || String(passwort || '').length < 10) {
        return reply.view('einladung.njk', {
          csrf: request.csrfToken,
          einladung,
          nutzerExistiert: false,
          fehler: 'Bitte gib deinen Namen an und wähle ein Passwort mit mindestens 10 Zeichen.',
        });
      }
      const hash = await passwortHashen(String(passwort));
      const rolle = einladung.neue_rolle === 'staff' ? 'staff' : 'customer';
      const ergebnis = db.prepare(
        `INSERT INTO users (email, pw_hash, name, role, is_admin) VALUES (?, ?, ?, ?, 0)`
      ).run(einladung.email, hash, String(name).trim(), rolle);
      nutzer = { id: ergebnis.lastInsertRowid };
    } else {
      // Bestehendes Konto: NIEMALS ohne Passwort-Nachweis einloggen/freischalten,
      // sonst könnte jeder mit dem Einladungslink das fremde Konto übernehmen.
      const ok = await passwortPruefen(nutzer.pw_hash, String(passwort || ''));
      if (!ok) {
        return reply.view('einladung.njk', {
          csrf: request.csrfToken,
          einladung,
          nutzerExistiert: true,
          fehler: 'Bitte gib das Passwort deines bestehenden Kontos ein.',
        });
      }
    }

    db.prepare(
      `INSERT OR IGNORE INTO memberships (user_id, project_id, role) VALUES (?, ?, ?)`
    ).run(nutzer.id, einladung.project_id, einladung.role);
    db.prepare(`UPDATE invites SET used_at = datetime('now') WHERE id = ?`).run(einladung.id);
    audit(nutzer.id, einladung.project_id, 'einladung_angenommen', einladung.email);

    sessionErstellen(reply, nutzer.id);
    return reply.redirect(`/projekt/${einladung.projekt_slug}`);
  });

  // ---- Passwort vergessen ----------------------------------------------

  app.get('/passwort-vergessen', async (request, reply) => {
    return reply.view('passwort-vergessen.njk', { csrf: request.csrfToken });
  });

  app.post('/passwort-vergessen', loginRateLimit, async (request, reply) => {
    const email = String(request.body?.email || '').trim();
    const nutzer = db.prepare(`SELECT * FROM users WHERE email = ?`).get(email);
    if (nutzer) {
      const token = neuesToken();
      const ablauf = sqliteZeitStempel(config.resetDauerMs);
      db.prepare(
        `INSERT INTO password_resets (token, user_id, expires_at) VALUES (?, ?, ?)`
      ).run(token, nutzer.id, ablauf);
      const link = `${config.baseUrl}/passwort-zuruecksetzen/${token}`;
      await mailSenden({
        an: email,
        betreff: 'QOM Editor – Passwort zurücksetzen',
        text: `Hallo ${nutzer.name}\n\nMit diesem Link kannst du ein neues Passwort setzen (gültig für 2 Stunden):\n${link}\n\nFalls du das nicht angefordert hast, kannst du diese Mail ignorieren.\n\nDein QOM-Team`,
      });
    }
    // Immer dieselbe Antwort, egal ob die Adresse existiert
    return reply.view('passwort-vergessen.njk', {
      csrf: request.csrfToken,
      gesendet: true,
    });
  });

  function gueltigerReset(token) {
    return db.prepare(
      `SELECT * FROM password_resets WHERE token = ? AND used_at IS NULL AND expires_at > datetime('now')`
    ).get(token);
  }

  app.get('/passwort-zuruecksetzen/:token', async (request, reply) => {
    const reset = gueltigerReset(request.params.token);
    if (!reset) {
      return reply.view('fehler.njk', {
        titel: 'Link nicht mehr gültig',
        meldung: 'Dieser Link ist abgelaufen. Bitte fordere unter "Passwort vergessen" einen neuen an.',
      });
    }
    return reply.view('passwort-reset.njk', { csrf: request.csrfToken, token: request.params.token });
  });

  app.post('/passwort-zuruecksetzen/:token', loginRateLimit, async (request, reply) => {
    const reset = gueltigerReset(request.params.token);
    if (!reset) return reply.redirect(`/passwort-zuruecksetzen/${request.params.token}`);
    const passwort = String(request.body?.passwort || '');
    if (passwort.length < 10) {
      return reply.view('passwort-reset.njk', {
        csrf: request.csrfToken,
        token: request.params.token,
        fehler: 'Das Passwort muss mindestens 10 Zeichen lang sein.',
      });
    }
    const hash = await passwortHashen(passwort);
    db.prepare(`UPDATE users SET pw_hash = ? WHERE id = ?`).run(hash, reset.user_id);
    db.prepare(`UPDATE password_resets SET used_at = datetime('now') WHERE id = ?`).run(reset.id);
    db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(reset.user_id);
    audit(reset.user_id, null, 'passwort_zurueckgesetzt', '');
    sessionErstellen(reply, reset.user_id);
    return reply.redirect('/projekte');
  });
}
