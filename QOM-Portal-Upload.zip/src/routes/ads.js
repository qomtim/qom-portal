// Meta-Ads-Portal: Kennzahlen-Dashboard + Video-Freigabe.
// Zugriff wie im Editor: nur wer Zugriff aufs Projekt hat, sieht dessen Ads-Daten.
import { db, audit } from '../db.js';
import { freigabeMelden } from '../webhook.js';
import { zugriffPruefen } from './editor.js';

function letzteKennzahlen(projektId) {
  return db.prepare(`SELECT * FROM ad_metrics WHERE project_id = ? ORDER BY tag DESC LIMIT 1`).get(projektId);
}

function trend(projektId, tage = 14) {
  // Älteste zuerst, für die Mini-Grafik
  return db.prepare(
    `SELECT tag, spend, purchases, results FROM ad_metrics WHERE project_id = ? ORDER BY tag DESC LIMIT ?`
  ).all(projektId, tage).reverse();
}

function videos(projektId) {
  return db.prepare(
    `SELECT v.*, u.name AS entschieden_name FROM ad_videos v
       LEFT JOIN users u ON u.id = v.entschieden_von
      WHERE v.project_id = ? ORDER BY v.sort, v.id`
  ).all(projektId);
}

export async function adsRouten(app) {
  // Dashboard
  app.get('/projekt/:slug/ads', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt, zugriff } = kontext;
    if (projekt.projekt_typ === 'website') {
      return reply.code(404).view('fehler.njk', {
        titel: 'Seite nicht gefunden', meldung: 'Für dieses Projekt gibt es kein Ads-Portal.', nutzer: request.nutzer,
      });
    }
    const verlauf = trend(projekt.id);
    const maxSpend = Math.max(1, ...verlauf.map((t) => t.spend || 0));
    const trendBalken = verlauf.map((t) => ({
      tag: t.tag, spend: t.spend, purchases: t.purchases,
      hoehe: Math.round(((t.spend || 0) / maxSpend) * 100),
    }));
    return reply.view('ads-dashboard.njk', {
      nutzer: request.nutzer,
      projekt,
      zugriff,
      kennzahlen: letzteKennzahlen(projekt.id),
      trendBalken,
      videos: videos(projekt.id),
      csrf: request.csrfToken,
      gespeichert: request.query.gespeichert === '1',
      entschieden: request.query.entschieden || '',
    });
  });

  // Kunde (oder QOM) entscheidet über ein Video: freigeben / Änderung gewünscht
  app.post('/projekt/:slug/video/:id/entscheidung', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    const { projekt } = kontext;
    const video = db.prepare(`SELECT * FROM ad_videos WHERE id = ? AND project_id = ?`)
      .get(Number(request.params.id), projekt.id);
    if (!video) return reply.code(404).send({ fehler: 'Video nicht gefunden.' });

    const status = request.body?.status === 'freigegeben' ? 'freigegeben'
      : request.body?.status === 'aenderung_gewuenscht' ? 'aenderung_gewuenscht' : null;
    if (!status) return reply.code(400).send({ fehler: 'Ungültige Auswahl.' });
    const kommentar = String(request.body?.kommentar || '').slice(0, 2000);

    db.prepare(
      `UPDATE ad_videos SET status = ?, kommentar = ?, entschieden_am = datetime('now'), entschieden_von = ? WHERE id = ?`
    ).run(status, kommentar, request.nutzer.id, video.id);
    audit(request.nutzer.id, projekt.id, 'video_entscheidung', `${video.id}=${status}`);

    // QOM benachrichtigen (E-Mail + optionaler Webhook). Fehler blockieren nicht;
    // wir warten die Meldung ab (mit internen Timeouts), damit nichts unbemerkt
    // im Hintergrund weiterläuft.
    const aktualisiert = db.prepare(`SELECT * FROM ad_videos WHERE id = ?`).get(video.id);
    await freigabeMelden(projekt, aktualisiert, request.nutzer).catch(() => {});

    if (request.headers['x-requested-with'] === 'fetch') return reply.send({ ok: true, status });
    return reply.redirect(`/projekt/${projekt.slug}/ads?entschieden=${status}`);
  });

  // ---- Video-Verwaltung (nur QOM: Geschäftsführer/Mitarbeiter) ----------

  function nurQom(kontext, reply) {
    if (!kontext.zugriff.darfAlles) {
      reply.code(403).send({ fehler: 'Nur QOM darf Videos verwalten.' });
      return false;
    }
    return true;
  }

  app.post('/projekt/:slug/ads/videos/neu', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    if (!nurQom(kontext, reply)) return reply;
    const { projekt } = kontext;
    const maxSort = db.prepare(`SELECT COALESCE(MAX(sort),0) AS m FROM ad_videos WHERE project_id = ?`).get(projekt.id).m;
    db.prepare(
      `INSERT INTO ad_videos (project_id, titel, drive_url, thumbnail_url, notiz, sort) VALUES (?, ?, ?, ?, ?, ?)`
    ).run(
      projekt.id,
      String(request.body?.titel || '').slice(0, 200),
      String(request.body?.drive_url || '').slice(0, 1000),
      String(request.body?.thumbnail_url || '').slice(0, 1000),
      String(request.body?.notiz || '').slice(0, 2000),
      maxSort + 1,
    );
    audit(request.nutzer.id, projekt.id, 'video_hinzugefuegt', String(request.body?.titel || ''));
    return reply.redirect(`/projekt/${projekt.slug}/ads?gespeichert=1`);
  });

  app.post('/projekt/:slug/ads/videos/:id', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    if (!nurQom(kontext, reply)) return reply;
    const { projekt } = kontext;
    const video = db.prepare(`SELECT * FROM ad_videos WHERE id = ? AND project_id = ?`)
      .get(Number(request.params.id), projekt.id);
    if (!video) return reply.redirect(`/projekt/${projekt.slug}/ads`);
    // Wenn QOM Titel/Link ändert, Freigabe zurücksetzen (neuer Stand)
    const zuruecksetzen = request.body?.zuruecksetzen ? 1 : 0;
    db.prepare(
      `UPDATE ad_videos SET titel = ?, drive_url = ?, thumbnail_url = ?, notiz = ?, sort = ?
        ${zuruecksetzen ? `, status = 'neu', kommentar = '', entschieden_am = NULL, entschieden_von = NULL` : ''}
        WHERE id = ?`
    ).run(
      String(request.body?.titel ?? video.titel).slice(0, 200),
      String(request.body?.drive_url ?? video.drive_url).slice(0, 1000),
      String(request.body?.thumbnail_url ?? video.thumbnail_url).slice(0, 1000),
      String(request.body?.notiz ?? video.notiz).slice(0, 2000),
      Number(request.body?.sort ?? video.sort) || video.sort,
      video.id,
    );
    audit(request.nutzer.id, projekt.id, 'video_geaendert', String(video.id));
    return reply.redirect(`/projekt/${projekt.slug}/ads?gespeichert=1`);
  });

  app.post('/projekt/:slug/ads/videos/:id/loeschen', async (request, reply) => {
    const kontext = zugriffPruefen(request, reply);
    if (!kontext) return reply;
    if (!nurQom(kontext, reply)) return reply;
    const { projekt } = kontext;
    db.prepare(`DELETE FROM ad_videos WHERE id = ? AND project_id = ?`).run(Number(request.params.id), projekt.id);
    audit(request.nutzer.id, projekt.id, 'video_geloescht', String(request.params.id));
    return reply.redirect(`/projekt/${projekt.slug}/ads`);
  });
}
