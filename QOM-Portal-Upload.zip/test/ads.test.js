// Tests: Meta-Ads-Portal – Kennzahlen-Ingest, Dashboard, Video-Freigabe, Isolation.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, anmelden, ajaxPost } from './helfer.js';

umgebungVorbereiten('qom-test-ads-');

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');

const PW = 'sicheres-test-passwort-1';
const hash = await passwortHashen(PW);

const ownerId = db.prepare(`INSERT INTO users (email, pw_hash, name, role, is_admin) VALUES (?, ?, ?, 'owner', 1)`)
  .run('chef@example.com', hash, 'Chef').lastInsertRowid;
const kundeId = db.prepare(`INSERT INTO users (email, pw_hash, name, role) VALUES (?, ?, ?, 'customer')`)
  .run('adkunde@example.com', hash, 'Ad Kunde').lastInsertRowid;

function projekt(slug, typ) {
  return db.prepare(
    `INSERT INTO projects (slug, name, api_token, preview_token, metrics_token, projekt_typ)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(slug, slug, `api-${slug}-x`, `prev-${slug}-x`, `metrics-${slug}-geheim-0123456789`, typ).lastInsertRowid;
}
const adsId = projekt('ads-kunde', 'ads');
const webId = projekt('web-only', 'website');
projekt('ads-fremd', 'ads'); // Projekt, zu dem der Kunde KEINEN Zugriff hat
db.prepare(`INSERT INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`).run(kundeId, adsId);
const videoId = db.prepare(`INSERT INTO ad_videos (project_id, titel, drive_url, sort) VALUES (?, 'V1', 'https://drive.google.com/x', 1)`)
  .run(adsId).lastInsertRowid;

const app = appErstellen();
after(async () => { await app.close(); });

const METRICS_TOKEN = 'metrics-ads-kunde-geheim-0123456789';

const kunde = await anmelden(app, 'adkunde@example.com', PW);
const owner = await anmelden(app, 'chef@example.com', PW);
assert.ok(kunde.sid && owner.sid, 'Logins müssen klappen');

test('Kennzahlen-Ingest: richtiges Token speichert & berechnet abgeleitete Werte', async () => {
  const antwort = await app.inject({
    method: 'POST',
    url: `/api/v1/projects/ads-kunde/metrics?token=${METRICS_TOKEN}`,
    headers: { 'content-type': 'application/json' },
    payload: { tag: '2026-08-10', spend: 1000, impressions: 100000, clicks: 2000, purchases: 50 },
  });
  assert.equal(antwort.statusCode, 200);
  const row = db.prepare(`SELECT * FROM ad_metrics WHERE project_id = ? AND tag = '2026-08-10'`).get(adsId);
  assert.ok(row, 'Kennzahlen-Zeile muss existieren');
  assert.equal(Math.round(row.cpm * 100) / 100, 10);      // 1000/100000*1000
  assert.equal(Math.round(row.ctr * 100) / 100, 2);       // 2000/100000*100
  assert.equal(Math.round(row.cpc * 100) / 100, 0.5);     // 1000/2000
  assert.equal(Math.round(row.cost_per_purchase), 20);    // 1000/50
});

test('Kennzahlen-Ingest: falsches Token -> 401, kein Schreiben', async () => {
  const antwort = await app.inject({
    method: 'POST',
    url: `/api/v1/projects/ads-kunde/metrics?token=falsch`,
    headers: { 'content-type': 'application/json' },
    payload: { tag: '2026-08-11', spend: 999 },
  });
  assert.equal(antwort.statusCode, 401);
  const row = db.prepare(`SELECT 1 FROM ad_metrics WHERE project_id = ? AND tag = '2026-08-11'`).get(adsId);
  assert.ok(!row, 'Mit falschem Token darf nichts geschrieben werden');
});

test('Kunde sieht sein Ads-Dashboard (KPIs), aber keine QOM-Verwaltung', async () => {
  const antwort = await app.inject({ method: 'GET', url: '/projekt/ads-kunde/ads', headers: { cookie: kunde.cookie } });
  assert.equal(antwort.statusCode, 200);
  assert.match(antwort.body, /Kosten pro Kauf/);
  assert.match(antwort.body, /Freigeben/);
  assert.ok(!antwort.body.includes('Video hinzufügen'), 'Kunde darf die Verwaltung nicht sehen');
});

test('Reines Website-Projekt hat kein Ads-Portal (404)', async () => {
  const antwort = await app.inject({ method: 'GET', url: '/projekt/web-only/ads', headers: { cookie: owner.cookie } });
  assert.equal(antwort.statusCode, 404);
});

test('Isolation: Kunde erreicht fremdes Ads-Projekt nicht (404)', async () => {
  const antwort = await app.inject({ method: 'GET', url: '/projekt/ads-fremd/ads', headers: { cookie: kunde.cookie } });
  assert.equal(antwort.statusCode, 404);
});

test('Kunde darf entscheiden, aber keine Videos verwalten', async () => {
  const entscheidung = await ajaxPost(app, kunde, `/projekt/ads-kunde/video/${videoId}/entscheidung`, {
    status: 'freigegeben', kommentar: 'Passt',
  });
  assert.equal(entscheidung.statusCode, 200);
  const v = db.prepare(`SELECT status, kommentar FROM ad_videos WHERE id = ?`).get(videoId);
  assert.equal(v.status, 'freigegeben');
  assert.equal(v.kommentar, 'Passt');

  const verwalten = await ajaxPost(app, kunde, '/projekt/ads-kunde/ads/videos/neu', { titel: 'Hack', drive_url: 'http://x' });
  assert.equal(verwalten.statusCode, 403);
});

test('QOM (owner) darf Videos verwalten', async () => {
  const anlegen = await ajaxPost(app, owner, '/projekt/ads-kunde/ads/videos/neu', { titel: 'Neu von QOM', drive_url: 'https://drive.google.com/y' });
  // Redirect (302) nach Erfolg
  assert.equal(anlegen.statusCode, 302);
  const anzahl = db.prepare(`SELECT COUNT(*) AS n FROM ad_videos WHERE project_id = ?`).get(adsId).n;
  assert.ok(anzahl >= 2, 'Owner-Video muss angelegt sein');
});
