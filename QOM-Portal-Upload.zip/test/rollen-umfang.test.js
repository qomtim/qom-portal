// Tests: Rollen (Mitarbeiter/Kunde), Kunden-Umfang und Bereiche ein-/ausblenden.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { umgebungVorbereiten, anmelden, ajaxPost } from './helfer.js';

umgebungVorbereiten('qom-test-rollen-');

const { appErstellen } = await import('../src/server.js');
const { db } = await import('../src/db.js');
const { passwortHashen } = await import('../src/security.js');
const { generierungAusloesen } = await import('../src/webhook.js');

const PASSWORT = 'sicheres-test-passwort-1';
const hash = await passwortHashen(PASSWORT);

function nutzer(email, name, rolle) {
  return db.prepare(`INSERT INTO users (email, pw_hash, name, role, is_admin) VALUES (?, ?, ?, ?, ?)`)
    .run(email, hash, name, rolle, rolle === 'owner' ? 1 : 0).lastInsertRowid;
}
const ownerId = nutzer('owner@example.com', 'Owner', 'owner');
const staffId = nutzer('staff@example.com', 'Mitarbeiter', 'staff');
const kundeId = nutzer('kunde@example.com', 'Kunde', 'customer');

function projekt(slug, extra = {}) {
  const s = { bilder: 1, sammlungen: 1, seiten: 1, ...extra };
  return db.prepare(
    `INSERT INTO projects (slug, name, api_token, preview_token, kunde_darf_bilder, kunde_darf_sammlungen, kunde_darf_seiten_schalten)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(slug, slug, `api-${slug}-0123456789`, `prev-${slug}-0123456789`, s.bilder, s.sammlungen, s.seiten).lastInsertRowid;
}
// P1: "nur Texte" (keine Bilder, keine Sammlungen, kein Seiten-Schalten)
const p1 = projekt('nur-texte', { bilder: 0, sammlungen: 0, seiten: 0 });
// P2: "alles"
const p2 = projekt('alles', { bilder: 1, sammlungen: 1, seiten: 1 });

const feld = db.prepare(`INSERT INTO fields (project_id, key, group_label, field_label, type, editable_by_editor, sort) VALUES (?, ?, 'A', ?, ?, 1, ?)`);
feld.run(p1, 'titel', 'Titel', 'text', 1);
feld.run(p1, 'bild', 'Bild', 'image', 2);
feld.run(p1, 'geheim', 'Geheim', 'text', 3);
db.prepare(`UPDATE fields SET editable_by_editor = 0 WHERE project_id = ? AND key = 'geheim'`).run(p1);
feld.run(p2, 'titel2', 'Titel', 'text', 1);

db.prepare(`INSERT INTO collections (project_id, key, label, item_schema, editable_by_editor, sort) VALUES (?, 'team', 'Team', '[]', 1, 1)`).run(p1);
db.prepare(`INSERT INTO sections (project_id, key, label, editor_darf_schalten, sort) VALUES (?, 'team', 'Team-Bereich', 1, 1)`).run(p1);
db.prepare(`INSERT INTO sections (project_id, key, label, editor_darf_schalten, sort) VALUES (?, 'team', 'Team-Bereich', 1, 1)`).run(p2);

for (const pid of [p1, p2]) {
  db.prepare(`INSERT INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`).run(staffId, pid);
  db.prepare(`INSERT INTO memberships (user_id, project_id, role) VALUES (?, ?, 'editor')`).run(kundeId, pid);
}

const app = appErstellen();
after(async () => { await app.close(); });

const staff = await anmelden(app, 'staff@example.com', PASSWORT);
const kunde = await anmelden(app, 'kunde@example.com', PASSWORT);
assert.ok(staff.sid && kunde.sid, 'Logins müssen klappen');

test('Mitarbeiter darf zugewiesene Projekte voll bearbeiten (auch gesperrte Felder)', async () => {
  const seite = await app.inject({ method: 'GET', url: '/projekt/nur-texte', headers: { cookie: staff.cookie } });
  assert.equal(seite.statusCode, 200);
  assert.match(seite.body, /data-feld="geheim"/, 'Mitarbeiter sieht gesperrtes Feld');
  const speichern = await ajaxPost(app, staff, '/projekt/nur-texte/feld', { key: 'geheim', wert: 'ok' });
  assert.equal(speichern.statusCode, 200);
});

test('Mitarbeiter hat keinen Adminzugriff', async () => {
  const admin = await app.inject({ method: 'GET', url: '/admin', headers: { cookie: staff.cookie } });
  assert.equal(admin.statusCode, 404);
});

test('Kunde mit "nur Texte": keine Bilder, keine Listen, keine Bereiche sichtbar', async () => {
  const seite = await app.inject({ method: 'GET', url: '/projekt/nur-texte', headers: { cookie: kunde.cookie } });
  assert.equal(seite.statusCode, 200);
  assert.match(seite.body, /data-feld="titel"/, 'Textfeld sichtbar');
  assert.ok(!seite.body.includes('data-feld="bild"'), 'Bildfeld darf nicht sichtbar sein');
  assert.ok(!seite.body.includes('data-feld="geheim"'), 'Gesperrtes Feld nicht sichtbar');
  assert.ok(!seite.body.includes('data-sammlung="team"'), 'Sammlung nicht sichtbar');
  assert.ok(!seite.body.includes('Bereiche ein- und ausblenden'), 'Bereiche-Sektion nicht sichtbar');
});

test('Kunde mit "nur Texte": Bild speichern und Bereich schalten sind gesperrt (403)', async () => {
  const bild = await ajaxPost(app, kunde, '/projekt/nur-texte/feld', { key: 'bild', wert: '/x.png' });
  assert.equal(bild.statusCode, 403);
  const bereich = await ajaxPost(app, kunde, '/projekt/nur-texte/bereich/team/sichtbarkeit', { sichtbar: false });
  assert.equal(bereich.statusCode, 403);
});

test('Kunde mit "alles": Bereich sichtbar und schaltbar', async () => {
  const seite = await app.inject({ method: 'GET', url: '/projekt/alles', headers: { cookie: kunde.cookie } });
  assert.match(seite.body, /Bereiche ein- und ausblenden/);
  const schalten = await ajaxPost(app, kunde, '/projekt/alles/bereich/team/sichtbarkeit', { sichtbar: false });
  assert.equal(schalten.statusCode, 200);
  const zeile = db.prepare(`SELECT sichtbar_draft FROM sections WHERE project_id = ? AND key = 'team'`).get(p2);
  assert.equal(zeile.sichtbar_draft, 0);
});

test('Generierung ohne Webhook gibt eine freundliche Fehlermeldung statt zu werfen', async () => {
  const projektZeile = db.prepare(`SELECT * FROM projects WHERE slug = 'alles'`).get();
  const ergebnis = await generierungAusloesen(projektZeile, { id: ownerId, name: 'Owner', email: 'owner@example.com' });
  assert.equal(ergebnis.ok, false);
  assert.match(ergebnis.meldung, /Generierungs-Dienst|Webhook/);
});
